# Changelog

Semua perubahan penting pada project ini akan didokumentasikan di file ini.

Format berdasarkan [Keep a Changelog](https://keepachangelog.com/id-ID/1.0.0/).

---

## [Unreleased]

### Planned
- [ ] Fitur yang akan datang

---

## [2.9a] - Blackjack Update

### Added
- **[Actor]** Actor robbery sekarang cooldown sampai jam 23:00 ingame time sesudah actor tangannya turun / robbery
- **[Rope]** Penambahan cmd `/tie` dan `/untie` untuk "Rope Roleplay" - tidak perlu item, yang penting angkat tangan orangnya
- **[ELM]** Command untuk menyalakan ELM (Faction) `/elm`
- **[Siren]** Penambahan entitas siren `/togsiren` dengan opsi: `roof`, `mid`, `dashboard`, dan `off`
- **[Blackjack]** Blackjack score color
- **[Blackjack]** Max bet system

### Changed
- **[Weapon]** Weaponscrap hanya bisa di blackmarket
- **[Vehicle Registration]** Vehicle Registration bisa tanpa masuk ke dalam kendaraan

---

## [2.0] - Major Release

### Added
- Modular script structure
- MySQL database integration
- YSI Library integration
- NEX-AC Anti-cheat system
- Discord logging system
- Email verification system
- VIP & Coins system
- Complete faction system
- Job system (Farmer, Mechanic, Lumber)
- Dynamic entity system (Actor, Gate, Vehicle, etc.)
- Custom models support (SA-MP 0.3.DL)
- Real-time clock system
- Economy system

### Technical
- Script refactoring for better performance
- Memory optimization dengan `#pragma dynamic`
- Modular include system
- Improved error handling

---

## [1.0] - Initial Release

### Added
- Base script dari South Central Roleplay
- Basic roleplay features
- Initial database schema

---

## Version History

| Version | Release Date | Description |
|---------|--------------|-------------|
| 2.9a | TBD | Blackjack Update |
| 2.0 | 2020 | Major Rewrite |
| 1.0 | - | Initial Release |

---

## Legend

- **Added** - Fitur baru
- **Changed** - Perubahan pada fitur existing
- **Deprecated** - Fitur yang akan dihapus di versi mendatang
- **Removed** - Fitur yang dihapus
- **Fixed** - Bug fixes
- **Security** - Perbaikan keamanan
