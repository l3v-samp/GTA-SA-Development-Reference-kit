#define FILTERSCRIPT

#include <a_samp>
//#include <env>



static bool:no_redirect_download;
static string:base_url[128];



public OnFilterScriptInit()
{
  no_redirect_download = true;

  return 1;
}

public OnPlayerRequestDownload(playerid, type, crc)
{
  if (IsPlayerNPC(playerid))
  {
    return 0;
  }

  if (!IsPlayerConnected(playerid))
  {
    return 0;
  }

  if (no_redirect_download)
  {
    return 1;
  }

  return 0;
}
