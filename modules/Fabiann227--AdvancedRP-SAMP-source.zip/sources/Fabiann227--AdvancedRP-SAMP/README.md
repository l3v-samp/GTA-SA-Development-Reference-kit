# 🎮 Advanced Roleplay - SA-MP Server

<div align="center">

![SA-MP](https://img.shields.io/badge/SA--MP-0.3.DL--R1-orange)
![Pawn](https://img.shields.io/badge/Language-Pawn-blue)
![MySQL](https://img.shields.io/badge/Database-MySQL%2FMariaDB-green)
![License](https://img.shields.io/badge/License-All%20Rights%20Reserved-red)

**Advanced Roleplay** adalah server roleplay San Andreas Multiplayer (SA-MP) yang dikembangkan dengan bahasa **Pawn**.

</div>

---

## 📋 Daftar Isi

- [Tentang Project](#-tentang-project)
- [Fitur Utama](#-fitur-utama)
- [Struktur Project](#-struktur-project)
- [Requirements](#-requirements)
- [Instalasi](#-instalasi)
- [Konfigurasi Database](#-konfigurasi-database)
- [Kompilasi/Build](#-kompilasibuild)
- [Menjalankan Server](#-menjalankan-server)
- [Plugins](#-plugins)
- [Modul System](#-modul-system)
- [Credits](#-credits)
- [Lisensi](#-lisensi)

---

## 📖 Tentang Project

**Advanced Roleplay** adalah gamemode roleplay berbasis script **South Central Roleplay** yang telah dimodifikasi dan dikembangkan lebih lanjut. Server ini menyediakan pengalaman roleplay yang realistis dengan berbagai sistem dan fitur yang lengkap.

### Informasi Script
- **Versi**: V2.0+
- **Base Script**: South Central Roleplay
- **Developer**: Leynardo Yosef (Revelt) & Rachmad Setiawan (sheenidgs)

---

## ✨ Fitur Utama

### 🏢 Sistem Dinamis
- **Actor System** - NPC interaktif untuk robbery dan lainnya
- **Apartment System** - Sistem apartemen
- **ATM System** - Mesin ATM tersebar di map
- **Business System** - Sistem bisnis dengan employee management
- **Gate System** - Gerbang dinamis
- **Vehicle System** - Sistem kendaraan lengkap dengan gunrack, vkeys, speedradar
- **Market System** - Sistem pasar/toko
- **Gas Pump System** - SPBU
- **Cargo System** - Sistem kargo
- **Dealer System** - Sistem dealer kendaraan
- **Plant System** - Sistem pertanian/tanaman
- **Tutorial System** - Tutorial untuk pemain baru

### 👤 Sistem Player
- **Faction System** - Sistem fraksi (LSPD, Gang, dll)
- **Weapon System** - Sistem senjata lengkap
- **VIP System** - Sistem VIP dengan berbagai benefit
- **Coins System** - Mata uang virtual
- **Report System** - Sistem laporan player
- **Wardrobe System** - Sistem pakaian
- **Animation System** - Ratusan animasi
- **Gambling System** - Blackjack dan game lainnya
- **Items/Inventory** - Sistem item (Boombox, dll)
- **Blacklist System** - Sistem blacklist

### 💼 Sistem Pekerjaan
- **Farmer** - Pekerjaan petani
- **Mechanic** - Pekerjaan mekanik
- **Job Skills** - Sistem skill untuk setiap pekerjaan
- **Lumber** - Pekerjaan penebang kayu

### 🛡️ Sistem Admin
- **Admin Activities** - Log aktivitas admin
- **Admin Duty Times** - Pelacakan waktu duty admin
- **Admin Event** - Sistem event admin
- **Admin Commands** - Command admin lengkap

### 🔒 Sistem Keamanan
- **Anti-Cheat (NEX-AC)** - Sistem anti-cheat terintegrasi
- **Aimbot Detection** - Deteksi aimbot
- **Anti-Spam** - Proteksi spam
- **Crash Detection** - Deteksi dan logging crash

### 🌍 Mapping
- Custom Interiors & Exteriors
- Bank, LSPD, Jail, Mechanic Shop
- Newbie School, DMV
- Dan banyak lagi...

### 🔧 Fitur Lainnya
- **Real-time Clock** - Jam real-time
- **Weather System** - Sistem cuaca dinamis
- **Economy System** - Sistem ekonomi server
- **Discord Integration** - Logging ke Discord
- **Email Verification** - Verifikasi email saat registrasi

---

## 📁 Struktur Project

```
Advanced Roleplay/
├── 📂 db/                      # Database SQL files
│   └── advanced.sql            # Main database schema
├── 📂 filterscripts/           # Filterscripts
│   ├── CustomExteriors.pwn     # Custom exterior objects
│   ├── CustomInteriors.pwn     # Custom interior objects
│   ├── StaticLocations.amx     # Static map locations
│   └── FastDL.amx              # Fast download system
├── 📂 gamemodes/               # Main gamemode
│   ├── main.pwn                # Entry point script
│   └── 📂 modules/             # Modular scripts
│       ├── 📂 admin/           # Admin systems
│       ├── 📂 api/             # API integrations
│       ├── 📂 core/            # Core functions & defines
│       ├── 📂 demo/            # Login/Register system
│       ├── 📂 dynamic/         # Dynamic entities
│       ├── 📂 jobs/            # Job systems
│       ├── 📂 mapping/         # Custom maps
│       ├── 📂 misc/            # Miscellaneous features
│       ├── 📂 player/          # Player systems
│       ├── 📂 server/          # Server-wide systems
│       └── 📂 vehicle/         # Vehicle systems
├── 📂 models/                  # Custom .dff dan .txd files
├── 📂 pawno/                   # Pawn compiler & includes
│   └── 📂 include/             # Library includes
├── 📂 plugins/                 # Server plugins (.dll/.so)
├── 📂 scriptfiles/             # Data files
├── 📂 logs/                    # Log files
├── server.cfg                  # Server configuration
├── mysql.ini                   # MySQL configuration
├── example.mysql.ini           # Example MySQL config
└── compile.sh                  # Build script (Docker)
```

---

## 💻 Requirements

### Software
- **SA-MP Server** 0.3.DL-R1
- **MySQL/MariaDB** 10.4+ atau MySQL 5.7+
- **Pawn Compiler** (tersedia di folder `pawno/`)

### Plugins (Sudah Include)
Semua plugin yang diperlukan sudah tersedia di folder `plugins/`:

| Plugin | Deskripsi |
|--------|-----------|
| `mysql` | Koneksi database MySQL |
| `streamer` | Object/Pickup/3DText streaming |
| `sscanf` | String parsing |
| `crashdetect` | Crash detection & debugging |
| `gvar` | Global variables |
| `chrono` | Date/Time functions |
| `pawnraknet` | RakNet functions |
| `mapandreas` | Map height functions |
| `samp-compat` | SA-MP compatibility |

---

## 🔧 Instalasi

### 1. Clone Repository
```bash
git clone https://github.com/username/advanced-roleplay.git
cd advanced-roleplay
```

### 2. Install SA-MP Server
Download SA-MP Server 0.3.DL-R1 dari [sa-mp.com](https://sa-mp.com) atau sumber terpercaya lainnya.

### 3. Setup Database
Lihat bagian [Konfigurasi Database](#-konfigurasi-database).

### 4. Kompilasi Gamemode
Lihat bagian [Kompilasi/Build](#-kompilasibuild).

### 5. Jalankan Server
Lihat bagian [Menjalankan Server](#-menjalankan-server).

---

## 🗄️ Konfigurasi Database

### 1. Buat Database
```sql
CREATE DATABASE adv CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
```

### 2. Import Schema
```bash
mysql -u root -p adv < db/advanced.sql
```

Atau melalui phpMyAdmin:
1. Buka phpMyAdmin
2. Pilih database `adv`
3. Klik tab "Import"
4. Pilih file `db/advanced.sql`
5. Klik "Go"

### 3. Konfigurasi Koneksi
Edit file `mysql.ini`:
```ini
hostname = 127.0.0.1
username = root
password = your_password
database = adv
auto_reconnect = true
pool_size = 10
server_port = 3306
```

> **Note**: Jangan lupa ganti `your_password` dengan password MySQL Anda.

---

## 🔨 Kompilasi/Build

### Metode 1: Menggunakan Pawno (Windows)

1. Buka folder `pawno/`
2. Jalankan `pawno.exe`
3. Buka file `gamemodes/main.pwn`
4. Tekan `F5` atau klik **Build > Compile**
5. File `main.amx` akan terbuat di folder `gamemodes/`

### Metode 2: Command Line (Windows)

```batch
cd pawno
pawncc.exe ../gamemodes/main.pwn -o../gamemodes/main.amx -d3 -;+ -(+
```

### Metode 3: Docker (Linux/macOS)

```bash
chmod +x compile.sh
./compile.sh
```

Script ini menggunakan Docker image `sheenidgs/samp_pawncc_win32:0.3.DL-R1`.

### Metode 4: Menggunakan sampctl

Jika Anda menggunakan [sampctl](https://github.com/Southclaws/sampctl):

```bash
sampctl package build
```

### Compiler Flags

| Flag | Deskripsi |
|------|-----------|
| `-d3` | Debug level 3 (maximum debugging) |
| `-;+` | Require semicolons |
| `-(+` | Require parentheses in function calls |
| `-o` | Output file path |

---

## 🚀 Menjalankan Server

### Windows

1. Double-click `samp-server.exe`

Atau melalui Command Prompt:
```batch
samp-server.exe
```

### Linux

```bash
./samp03svr
```

> **Note**: Pastikan file memiliki permission executable:
> ```bash
> chmod +x samp03svr
> ```

### Konfigurasi Server

Edit `server.cfg` untuk mengkustomisasi server:

```properties
gamemode0 main
filterscripts CustomExteriors StaticLocations
plugins crashdetect streamer mysql sscanf gvar chrono pawnraknet mapandreas samp-compat
rcon_password your_secure_password
port 7777
hostname Advanced Roleplay | Your Server Name
maxplayers 100
language English
useartwork 1
```

### Port yang Digunakan

| Port | Protocol | Deskripsi |
|------|----------|-----------|
| 7777 | UDP | SA-MP Game Port |
| 3306 | TCP | MySQL Database |

---

## 📦 Plugins

### Plugin Files

#### Windows (.dll)
```
plugins/
├── chrono.dll
├── crashdetect.dll
├── gvar.dll
├── mapandreas.dll
├── mysql.dll
├── pawnraknet.dll
├── samp-compat.dll
├── sscanf.dll
└── streamer.dll
```

#### Linux (.so)
```
plugins/
├── chrono.so
├── crashdetect.so
├── gvar.so
├── mapandreas.so
├── mysql.so
├── pawnraknet.so
├── samp-compat.so
├── sscanf.so
└── streamer.so
```

### Dokumentasi Plugin

| Plugin | Repository |
|--------|------------|
| MySQL | [pBlueG/SA-MP-MySQL](https://github.com/pBlueG/SA-MP-MySQL) |
| Streamer | [samp-incognito/samp-streamer-plugin](https://github.com/samp-incognito/samp-streamer-plugin) |
| sscanf | [Y-Less/sscanf](https://github.com/Y-Less/sscanf) |
| crashdetect | [Zeex/samp-plugin-crashdetect](https://github.com/Zeex/samp-plugin-crashdetect) |
| YSI | [pawn-lang/YSI-Includes](https://github.com/pawn-lang/YSI-Includes) |

---

## 📚 Modul System

### Core Modules (`modules/core/`)
| File | Deskripsi |
|------|-----------|
| `defined.pwn` | Konstanta dan definisi |
| `enums.pwn` | Enumerasi data structures |
| `variable.pwn` | Variabel global |
| `functions.pwn` | Fungsi utilitas |
| `macros.pwn` | Macro definitions |
| `logger.pwn` | Logging system |

### Player Modules (`modules/player/`)
| Folder/File | Deskripsi |
|-------------|-----------|
| `animation/` | Sistem animasi |
| `faction/` | Sistem fraksi |
| `weapon/` | Sistem senjata |
| `items/` | Sistem item/inventory |
| `vip/` | Sistem VIP |
| `coins/` | Sistem mata uang |
| `gambling/` | Sistem gambling |
| `wardrobe.pwn` | Sistem pakaian |

### Dynamic Modules (`modules/dynamic/`)
| Folder | Deskripsi |
|--------|-----------|
| `actor/` | NPC System |
| `apartment/` | Apartemen |
| `atm/` | ATM System |
| `gate/` | Gate System |
| `veh/` | Vehicle System |
| `market/` | Market/Store |
| `pump/` | Gas Station |
| `cargo/` | Cargo System |

### Server Modules (`modules/server/`)
| File | Deskripsi |
|------|-----------|
| `database.pwn` | Database handler |
| `economy.pwn` | Sistem ekonomi |
| `weather.pwn` | Sistem cuaca |
| `salary.pwn` | Sistem gaji |
| `dmv.pwn` | DMV (SIM) System |

---

## 🛠️ Development

### Mengaktifkan Debug Mode

Uncomment baris berikut di `main.pwn`:
```pawn
#define DEBUG_MODE
```

### Logging

Server log tersimpan di:
- `server_log.txt` - Main server log
- `logs/plugins/` - Plugin-specific logs
- `crashinfo.txt` - Crash information

### Coding Standards

- Gunakan **camelCase** untuk nama fungsi
- Gunakan **UPPER_CASE** untuk konstanta
- Gunakan **PascalCase** untuk enum
- Comment kode dalam Bahasa Indonesia/Inggris

---

## 🤝 Contributing

1. Fork repository ini
2. Buat branch fitur (`git checkout -b feature/AmazingFeature`)
3. Commit perubahan (`git commit -m 'Add some AmazingFeature'`)
4. Push ke branch (`git push origin feature/AmazingFeature`)
5. Buat Pull Request

---

## 👏 Credits

### Developers
- **Leynardo Yosef (Revelt)** - Lead Developer
- **Rachmad Setiawan (sheenidgs)** - Lead Developer

### Special Thanks
- **Kalcor (Kye)** - SA-MP Developer
- **Y_Less** - sscanf, YSI Library
- **BlueG & maddinat0r** - MySQL Plugin
- **Southclaw** - Progressbar2, chrono
- **Emmet_** - Original Base Script, easyDialog, etc.
- **JustMichael** - Performance Improvements
- **Incognito** - Streamer Plugin
- **Zeex** - crashdetect, ZCMD

---

## ⚠️ Disclaimer

- Script ini untuk keperluan **educational** dan **development**.
- Pastikan untuk mengubah semua password default sebelum deployment.
- Backup database secara berkala.
- Server ini membutuhkan **SA-MP 0.3.DL-R1** untuk custom models.

---

## 📄 Lisensi

```
Copyright (c) 2020 Leynardo Yosef (Revelt) & Rachmad Setiawan (sheenidgs)
All rights reserved.
```

---

<div align="center">

**Made with ❤️ for SA-MP Community**

[⬆ Kembali ke atas](#-advanced-roleplay---sa-mp-server)

</div>
