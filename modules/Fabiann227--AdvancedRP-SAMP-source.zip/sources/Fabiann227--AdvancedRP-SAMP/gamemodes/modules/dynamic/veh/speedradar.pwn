#include <YSI\y_hooks>

new Vehicle_RadarObjectID[MAX_DYNAMIC_VEHICLES];
new bool:Player_RadarToggle[MAX_PLAYERS];
new bool:Vehicle_RadarToggle[MAX_DYNAMIC_VEHICLES];
new Timer:Vehicle_CheckingSpeed[MAX_DYNAMIC_VEHICLES];
new Player_OldVehicleID[MAX_PLAYERS];
new 
  PlayerText:RadarBOX[MAX_PLAYERS],
  PlayerText:SpeedRadarTD[MAX_PLAYERS],
  PlayerText:SpeedTextTD[MAX_PLAYERS],
  PlayerText:ModelTextTD[MAX_PLAYERS],
  PlayerText:PlateTextTD[MAX_PLAYERS],
  PlayerText:SeparatorTD[MAX_PLAYERS],
  PlayerText:ModelTD[MAX_PLAYERS],
  PlayerText:SpeedTD[MAX_PLAYERS],
  PlayerText:PlateTD[MAX_PLAYERS];

SpeedRadar_Init(playerid)
{
    RadarBOX[playerid] = CreatePlayerTextDraw(playerid, 557.000000, 121.000000, "_");
    PlayerTextDrawFont(playerid, RadarBOX[playerid], 1);
    PlayerTextDrawLetterSize(playerid, RadarBOX[playerid], 0.600000, 5.899997);
    PlayerTextDrawTextSize(playerid, RadarBOX[playerid], 298.500000, 106.000000);
    PlayerTextDrawSetOutline(playerid, RadarBOX[playerid], 1);
    PlayerTextDrawSetShadow(playerid, RadarBOX[playerid], 0);
    PlayerTextDrawAlignment(playerid, RadarBOX[playerid], 2);
    PlayerTextDrawColor(playerid, RadarBOX[playerid], -1);
    PlayerTextDrawBackgroundColor(playerid, RadarBOX[playerid], 255);
    PlayerTextDrawBoxColor(playerid, RadarBOX[playerid], 100);
    PlayerTextDrawUseBox(playerid, RadarBOX[playerid], 1);
    PlayerTextDrawSetProportional(playerid, RadarBOX[playerid], 1);
    PlayerTextDrawSetSelectable(playerid, RadarBOX[playerid], 0);

    SpeedRadarTD[playerid] = CreatePlayerTextDraw(playerid, 533.000000, 119.000000, "Speed Radar");
    PlayerTextDrawFont(playerid, SpeedRadarTD[playerid], 1);
    PlayerTextDrawLetterSize(playerid, SpeedRadarTD[playerid], 0.212500, 1.000000);
    PlayerTextDrawTextSize(playerid, SpeedRadarTD[playerid], 620.000000, 15.500000);
    PlayerTextDrawSetOutline(playerid, SpeedRadarTD[playerid], 1);
    PlayerTextDrawSetShadow(playerid, SpeedRadarTD[playerid], 0);
    PlayerTextDrawAlignment(playerid, SpeedRadarTD[playerid], 1);
    PlayerTextDrawColor(playerid, SpeedRadarTD[playerid], -1);
    PlayerTextDrawBackgroundColor(playerid, SpeedRadarTD[playerid], 255);
    PlayerTextDrawBoxColor(playerid, SpeedRadarTD[playerid], 50);
    PlayerTextDrawUseBox(playerid, SpeedRadarTD[playerid], 0);
    PlayerTextDrawSetProportional(playerid, SpeedRadarTD[playerid], 1);
    PlayerTextDrawSetSelectable(playerid, SpeedRadarTD[playerid], 0);

    SpeedTextTD[playerid] = CreatePlayerTextDraw(playerid, 509.000000, 146.000000, "Speed");
    PlayerTextDrawFont(playerid, SpeedTextTD[playerid], 1);
    PlayerTextDrawLetterSize(playerid, SpeedTextTD[playerid], 0.225000, 1.100000);
    PlayerTextDrawTextSize(playerid, SpeedTextTD[playerid], 620.000000, 15.500000);
    PlayerTextDrawSetOutline(playerid, SpeedTextTD[playerid], 1);
    PlayerTextDrawSetShadow(playerid, SpeedTextTD[playerid], 0);
    PlayerTextDrawAlignment(playerid, SpeedTextTD[playerid], 1);
    PlayerTextDrawColor(playerid, SpeedTextTD[playerid], 16777215);
    PlayerTextDrawBackgroundColor(playerid, SpeedTextTD[playerid], 255);
    PlayerTextDrawBoxColor(playerid, SpeedTextTD[playerid], 50);
    PlayerTextDrawUseBox(playerid, SpeedTextTD[playerid], 0);
    PlayerTextDrawSetProportional(playerid, SpeedTextTD[playerid], 1);
    PlayerTextDrawSetSelectable(playerid, SpeedTextTD[playerid], 0);

    ModelTextTD[playerid] = CreatePlayerTextDraw(playerid, 509.000000, 132.000000, "Model");
    PlayerTextDrawFont(playerid, ModelTextTD[playerid], 1);
    PlayerTextDrawLetterSize(playerid, ModelTextTD[playerid], 0.225000, 1.100000);
    PlayerTextDrawTextSize(playerid, ModelTextTD[playerid], 620.000000, 15.500000);
    PlayerTextDrawSetOutline(playerid, ModelTextTD[playerid], 1);
    PlayerTextDrawSetShadow(playerid, ModelTextTD[playerid], 0);
    PlayerTextDrawAlignment(playerid, ModelTextTD[playerid], 1);
    PlayerTextDrawColor(playerid, ModelTextTD[playerid], 16777215);
    PlayerTextDrawBackgroundColor(playerid, ModelTextTD[playerid], 255);
    PlayerTextDrawBoxColor(playerid, ModelTextTD[playerid], 50);
    PlayerTextDrawUseBox(playerid, ModelTextTD[playerid], 0);
    PlayerTextDrawSetProportional(playerid, ModelTextTD[playerid], 1);
    PlayerTextDrawSetSelectable(playerid, ModelTextTD[playerid], 0);

    PlateTextTD[playerid] = CreatePlayerTextDraw(playerid, 509.500000, 161.000000, "Plate");
    PlayerTextDrawFont(playerid, PlateTextTD[playerid], 1);
    PlayerTextDrawLetterSize(playerid, PlateTextTD[playerid], 0.225000, 1.100000);
    PlayerTextDrawTextSize(playerid, PlateTextTD[playerid], 620.000000, 15.500000);
    PlayerTextDrawSetOutline(playerid, PlateTextTD[playerid], 1);
    PlayerTextDrawSetShadow(playerid, PlateTextTD[playerid], 0);
    PlayerTextDrawAlignment(playerid, PlateTextTD[playerid], 1);
    PlayerTextDrawColor(playerid, PlateTextTD[playerid], 16777215);
    PlayerTextDrawBackgroundColor(playerid, PlateTextTD[playerid], 255);
    PlayerTextDrawBoxColor(playerid, PlateTextTD[playerid], 50);
    PlayerTextDrawUseBox(playerid, PlateTextTD[playerid], 0);
    PlayerTextDrawSetProportional(playerid, PlateTextTD[playerid], 1);
    PlayerTextDrawSetSelectable(playerid, PlateTextTD[playerid], 0);

    SeparatorTD[playerid] = CreatePlayerTextDraw(playerid, 538.000000, 127.000000, ":~n~:~n~:");
    PlayerTextDrawFont(playerid, SeparatorTD[playerid], 1);
    PlayerTextDrawLetterSize(playerid, SeparatorTD[playerid], 0.316666, 1.650002);
    PlayerTextDrawTextSize(playerid, SeparatorTD[playerid], 620.000000, 15.500000);
    PlayerTextDrawSetOutline(playerid, SeparatorTD[playerid], 1);
    PlayerTextDrawSetShadow(playerid, SeparatorTD[playerid], 0);
    PlayerTextDrawAlignment(playerid, SeparatorTD[playerid], 1);
    PlayerTextDrawColor(playerid, SeparatorTD[playerid], -1);
    PlayerTextDrawBackgroundColor(playerid, SeparatorTD[playerid], 255);
    PlayerTextDrawBoxColor(playerid, SeparatorTD[playerid], 50);
    PlayerTextDrawUseBox(playerid, SeparatorTD[playerid], 0);
    PlayerTextDrawSetProportional(playerid, SeparatorTD[playerid], 1);
    PlayerTextDrawSetSelectable(playerid, SeparatorTD[playerid], 0);

    ModelTD[playerid] = CreatePlayerTextDraw(playerid, 548.000000, 132.000000, "N/A");
    PlayerTextDrawFont(playerid, ModelTD[playerid], 1);
    PlayerTextDrawLetterSize(playerid, ModelTD[playerid], 0.204165, 0.949998);
    PlayerTextDrawTextSize(playerid, ModelTD[playerid], 614.500000, 17.000000);
    PlayerTextDrawSetOutline(playerid, ModelTD[playerid], 1);
    PlayerTextDrawSetShadow(playerid, ModelTD[playerid], 0);
    PlayerTextDrawAlignment(playerid, ModelTD[playerid], 1);
    PlayerTextDrawColor(playerid, ModelTD[playerid], -1);
    PlayerTextDrawBackgroundColor(playerid, ModelTD[playerid], 255);
    PlayerTextDrawBoxColor(playerid, ModelTD[playerid], 50);
    PlayerTextDrawUseBox(playerid, ModelTD[playerid], 0);
    PlayerTextDrawSetProportional(playerid, ModelTD[playerid], 1);
    PlayerTextDrawSetSelectable(playerid, ModelTD[playerid], 0);

    SpeedTD[playerid] = CreatePlayerTextDraw(playerid, 548.000000, 147.000000, "N/A");
    PlayerTextDrawFont(playerid, SpeedTD[playerid], 1);
    PlayerTextDrawLetterSize(playerid, SpeedTD[playerid], 0.204165, 0.949998);
    PlayerTextDrawTextSize(playerid, SpeedTD[playerid], 614.500000, 17.000000);
    PlayerTextDrawSetOutline(playerid, SpeedTD[playerid], 1);
    PlayerTextDrawSetShadow(playerid, SpeedTD[playerid], 0);
    PlayerTextDrawAlignment(playerid, SpeedTD[playerid], 1);
    PlayerTextDrawColor(playerid, SpeedTD[playerid], -1);
    PlayerTextDrawBackgroundColor(playerid, SpeedTD[playerid], 255);
    PlayerTextDrawBoxColor(playerid, SpeedTD[playerid], 50);
    PlayerTextDrawUseBox(playerid, SpeedTD[playerid], 0);
    PlayerTextDrawSetProportional(playerid, SpeedTD[playerid], 1);
    PlayerTextDrawSetSelectable(playerid, SpeedTD[playerid], 0);

    PlateTD[playerid] = CreatePlayerTextDraw(playerid, 548.000000, 162.000000, "N/A");
    PlayerTextDrawFont(playerid, PlateTD[playerid], 1);
    PlayerTextDrawLetterSize(playerid, PlateTD[playerid], 0.204165, 0.949998);
    PlayerTextDrawTextSize(playerid, PlateTD[playerid], 614.500000, 17.000000);
    PlayerTextDrawSetOutline(playerid, PlateTD[playerid], 1);
    PlayerTextDrawSetShadow(playerid, PlateTD[playerid], 0);
    PlayerTextDrawAlignment(playerid, PlateTD[playerid], 1);
    PlayerTextDrawColor(playerid, PlateTD[playerid], -1);
    PlayerTextDrawBackgroundColor(playerid, PlateTD[playerid], 255);
    PlayerTextDrawBoxColor(playerid, PlateTD[playerid], 50);
    PlayerTextDrawUseBox(playerid, PlateTD[playerid], 0);
    PlayerTextDrawSetProportional(playerid, PlateTD[playerid], 1);
    PlayerTextDrawSetSelectable(playerid, PlateTD[playerid], 0);
    return 1;
}


EnableSpeedRadar(playerid)
{
    PlayerTextDrawShow(playerid, RadarBOX[playerid]);
    PlayerTextDrawShow(playerid, SpeedRadarTD[playerid]);
    PlayerTextDrawShow(playerid, SpeedTextTD[playerid]);
    PlayerTextDrawShow(playerid, ModelTextTD[playerid]);
    PlayerTextDrawShow(playerid, PlateTextTD[playerid]);
    PlayerTextDrawShow(playerid, SeparatorTD[playerid]);
    PlayerTextDrawShow(playerid, ModelTD[playerid]);
    PlayerTextDrawShow(playerid, SpeedTD[playerid]);
    PlayerTextDrawShow(playerid, PlateTD[playerid]);
    Player_RadarToggle[playerid] = true;
    return 1;
}

DisableSpeedRadar(playerid)
{
    PlayerTextDrawHide(playerid, RadarBOX[playerid]);
    PlayerTextDrawHide(playerid, SpeedRadarTD[playerid]);
    PlayerTextDrawHide(playerid, SpeedTextTD[playerid]);
    PlayerTextDrawHide(playerid, ModelTextTD[playerid]);
    PlayerTextDrawHide(playerid, PlateTextTD[playerid]);
    PlayerTextDrawHide(playerid, SeparatorTD[playerid]);
    PlayerTextDrawHide(playerid, ModelTD[playerid]);
    PlayerTextDrawHide(playerid, SpeedTD[playerid]);
    PlayerTextDrawHide(playerid, PlateTD[playerid]);
    Player_RadarToggle[playerid] = false;
    return 1;
}

CMD:speedradar(playerid, params[])
{
	if(IsPlayerInAnyVehicle(playerid) && GetFactionType(playerid) == FACTION_POLICE)
	{
		new vehicleid = GetPlayerVehicleID(playerid),
			Float: x, Float: y, Float: z, Float: a;

		if(Vehicle_GetExtraID(vehicleid) != GetPlayerFactionID(playerid))
			return SendErrorMessage(playerid, "This is not your faction vehicle!");

		if(!IsFourWheelVehicle(vehicleid))
			return SendErrorMessage(playerid, "You need to be inside a car to use speed radar!");

		if(!Vehicle_RadarToggle[vehicleid]) 
		{
			Vehicle_RadarToggle[vehicleid] = true;
			Player_RadarToggle[playerid] = true;
			
			GetVehiclePos (vehicleid, x, y, z);
			GetVehicleZAngle (vehicleid, a);
			SendServerMessage(playerid, "Vehicle speed-radar has been turned on.");
			Vehicle_CheckingSpeed[vehicleid] = repeat Vehicle_CheckSpeed(vehicleid);
		
			if(!IsValidDynamicObject(Vehicle_RadarObjectID[vehicleid]))
			{
				Vehicle_RadarObjectID[vehicleid] = CreateDynamicObject (367, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0);
				AttachDynamicObjectToVehicle (Vehicle_RadarObjectID[vehicleid], vehicleid, 0.2, 0.50, 0.3, 0.0, 0.0, 90.0);
			}
			foreach(new i : Player) if (IsPlayerInVehicle (i, vehicleid))
			{
				EnableSpeedRadar(i);
			}
		}
		else
		{
			if(IsValidDynamicObject(Vehicle_RadarObjectID[vehicleid]))
				DestroyDynamicObject(Vehicle_RadarObjectID[vehicleid]);
			
			Vehicle_RadarObjectID[vehicleid] = INVALID_STREAMER_ID;
			Vehicle_RadarToggle[vehicleid] = false;
			Player_RadarToggle[playerid] = false;
			stop Vehicle_CheckingSpeed[vehicleid];

			SendServerMessage(playerid, "Vehicle speed-radar has been turned off.");
			foreach(new i : Player) if (IsPlayerInVehicle (i, vehicleid))
			{
				DisableSpeedRadar(i);
			}
			
		}
	}
	else SendErrorMessage(playerid, "You are not a police officer that inside a vehicle!");
	return 1;
}

Vehicle_GetFrontID(vehid)
{
    new Float: temp = 7.0;
	new j = 0;
	foreach(new i : Vehicle)
	{
	    new Float: a, Float: x1, Float: y1, Float: z1, Float: x2, Float: y2, Float: z2;
    	GetVehiclePos (vehid, x1, y1, z1);
    	GetVehicleZAngle (vehid, a);
 		if (i != vehid)
 		{
	 		if (GetVehiclePos (i, x2, y2, z2))
			{
				new Float: distance = floatsqroot (floatpower ((x1 - x2), 2) + floatpower ((y1 - y2), 2) + floatpower ((z1 - z2), 2));
				GetVehicleZAngle (vehid, a);
				
				if (distance < 300.0)
				{
    				x1 = x1 + (distance * floatsin(-a, degrees));
					y1 = y1 + (distance * floatcos(-a, degrees));

					distance = floatsqroot ((floatpower ((x1 - x2), 2)) + (floatpower ((y1 - y2), 2)));

					if (temp > distance)
					{
						temp = distance;
						j = i;
					}
				}
			}
		}
	}
	if (temp < 7.0) return j;
	return -1;
}

timer Vehicle_CheckSpeed[1000](vehicleid)
{
	if(Vehicle_RadarToggle[vehicleid])
	{
		new vehid = Vehicle_GetFrontID(vehicleid);
		if (vehid == -1)
		{
			foreach(new i : Player) if(IsPlayerInVehicle (i, vehicleid))
			{
				PlayerTextDrawSetString(i, ModelTD[i], "N/A");
				PlayerTextDrawSetString(i, SpeedTD[i], "N/A");
				PlayerTextDrawSetString(i, PlateTD[i], "N/A");
			}
		}
		else
		{
			foreach(new i : Player) if(IsPlayerInVehicle (i, vehicleid))
			{
				new speed = floatround(GetVehicleSpeed(vehid));
				PlayerTextDrawSetString(i, ModelTD[i], sprintf("%s", GetVehicleNameByVehicle(vehid)));
				PlayerTextDrawSetString(i, SpeedTD[i], sprintf("%d KMH", speed));
				PlayerTextDrawSetString(i, PlateTD[i], sprintf("%s", VehicleData[vehid][vehPlate]));
			}
		}
	}
	return 1;
}

hook OnPlayerStateChange(playerid, newstate, oldstate)
{
	if((oldstate == PLAYER_STATE_ONFOOT) && (newstate == PLAYER_STATE_PASSENGER || newstate == PLAYER_STATE_DRIVER))
	{
	    Player_OldVehicleID[playerid] = GetPlayerVehicleID(playerid);
		new vehicleid = Player_OldVehicleID[playerid];
		if(vehicleid != -1)
		{
			if(Vehicle_RadarToggle[vehicleid])
			{
				EnableSpeedRadar(playerid);
			}
		}
	}

	if((oldstate == PLAYER_STATE_DRIVER || oldstate == PLAYER_STATE_PASSENGER) && (newstate == PLAYER_STATE_ONFOOT))
	{
	    new vehicleid = Player_OldVehicleID[playerid];
		if(vehicleid != -1)
		{
			if(Vehicle_RadarToggle[vehicleid])
			{
				DisableSpeedRadar(playerid);
			}
		}
	}
}

hook OnVehicleDeath(vehicleid)
{
	if(IsValidDynamicObject(Vehicle_RadarObjectID[vehicleid]))
	{
		DestroyDynamicObject(Vehicle_RadarObjectID[vehicleid]);
		Vehicle_RadarObjectID[vehicleid] = INVALID_STREAMER_ID;
	}
	if(Vehicle_RadarToggle[vehicleid])
	{
		stop Vehicle_CheckingSpeed[vehicleid];
		Vehicle_RadarToggle[vehicleid] = false;
		foreach(new i : Player)
		{
			if (IsPlayerInVehicle (i, vehicleid))
			{
				DisableSpeedRadar(i);
			}
		}
	}
}