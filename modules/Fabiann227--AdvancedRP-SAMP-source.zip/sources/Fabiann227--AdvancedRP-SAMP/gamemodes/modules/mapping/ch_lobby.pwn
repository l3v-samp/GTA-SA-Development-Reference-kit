#include <YSI\y_hooks>

hook OnGameModeInit()
{
    new tmpobjid;
    tmpobjid = CreateDynamicObjectEx(19465, 1466.269897, -1798.349731, 2997.189941, 0.019999, 0.039999, 0.039999, 300.00, 300.00);

    SetDynamicObjectMaterial(tmpobjid, 0, 1736, "cj_ammo", "CJ_Black_metal", 0x00000000);

    SetDynamicObjectMaterial(tmpobjid, 1, 15041, "bigsfsave", "carp11S", 0x00000000);

    tmpobjid = CreateDynamicObjectEx(2263, 1481.520019, -1803.760009, 2995.409912, 8.000000, 0.000000, 200.000000, 300.00, 300.00);

    SetDynamicObjectMaterial(tmpobjid, 0, 1736, "cj_ammo", "CJ_Black_metal", 0x00000000);

    tmpobjid = CreateDynamicObjectEx(19579, 1481.650024, -1804.189941, 2995.219970, 0.000000, 0.000000, 20.000000, 300.00, 300.00);

    SetDynamicObjectMaterial(tmpobjid, 0, 1736, "cj_ammo", "CJ_Black_metal", 0x00000000);

    tmpobjid = CreateDynamicObjectEx(19610, 1481.660034, -1804.209960, 2995.459960, 276.000000, 0.000000, 30.000000, 300.00, 300.00);

    SetDynamicObjectMaterial(tmpobjid, 0, 1736, "cj_ammo", "CJ_Black_metal", 0x00000000);

    tmpobjid = CreateDynamicObjectEx(19453, 1472.099975, -1802.469970, 2994.560058, 0.000000, 90.000000, 90.000000, 300.00, 300.00);

    SetDynamicObjectMaterial(tmpobjid, 0, 19517, "noncolored", "gen_white", 0x00000000);

    tmpobjid = CreateDynamicObjectEx(19089, 1481.250000, -1803.560058, 3002.669921, 0.000000, 0.000000, 0.000000, 300.00, 300.00);

    SetDynamicObjectMaterial(tmpobjid, 0, 1736, "cj_ammo", "CJ_Black_metal", 0x00000000);

    tmpobjid = CreateDynamicObjectEx(19089, 1483.479980, -1803.560058, 3002.669921, 0.000000, 0.000000, 0.000000, 300.00, 300.00);

    SetDynamicObjectMaterial(tmpobjid, 0, 1736, "cj_ammo", "CJ_Black_metal", 0x00000000);

    tmpobjid = CreateDynamicObjectEx(19453, 1492.569946, -1802.469970, 2994.560058, 0.000000, 90.000000, 90.000000, 300.00, 300.00);

    SetDynamicObjectMaterial(tmpobjid, 0, 19517, "noncolored", "gen_white", 0x00000000);

    tmpobjid = CreateDynamicObjectEx(2263, 1481.819946, -1804.699951, 2995.550048, 352.000000, 0.000000, 20.000000, 300.00, 300.00);

    SetDynamicObjectMaterial(tmpobjid, 0, 14392, "dr_gsstudio", "monitors_128", 0x00000000);

    tmpobjid = CreateDynamicObjectEx(19089, 1479.540039, -1804.989990, 3002.669921, 0.000000, 0.000000, 0.000000, 300.00, 300.00);

    SetDynamicObjectMaterial(tmpobjid, 0, 1736, "cj_ammo", "CJ_Black_metal", 0x00000000);

    tmpobjid = CreateDynamicObjectEx(19089, 1485.189941, -1805.000000, 3002.669921, 0.000000, 0.000000, 0.000000, 300.00, 300.00);

    SetDynamicObjectMaterial(tmpobjid, 0, 1736, "cj_ammo", "CJ_Black_metal", 0x00000000);

    tmpobjid = CreateDynamicObjectEx(19089, 1479.140014, -1807.199951, 3002.669921, 0.000000, 0.000000, 0.000000, 300.00, 300.00);

    SetDynamicObjectMaterial(tmpobjid, 0, 1736, "cj_ammo", "CJ_Black_metal", 0x00000000);

    tmpobjid = CreateDynamicObjectEx(19089, 1485.599975, -1807.189941, 3002.669921, 0.000000, 0.000000, 0.000000, 300.00, 300.00);

    SetDynamicObjectMaterial(tmpobjid, 0, 1736, "cj_ammo", "CJ_Black_metal", 0x00000000);

    tmpobjid = CreateDynamicObjectEx(19089, 1475.750000, -1807.189941, 3002.669921, 0.000000, 0.000000, 0.000000, 300.00, 300.00);

    SetDynamicObjectMaterial(tmpobjid, 0, 1736, "cj_ammo", "CJ_Black_metal", 0x00000000);

    tmpobjid = CreateDynamicObjectEx(19089, 1488.810058, -1807.189941, 3002.669921, 0.000000, 0.000000, 0.000000, 300.00, 300.00);

    SetDynamicObjectMaterial(tmpobjid, 0, 1736, "cj_ammo", "CJ_Black_metal", 0x00000000);

    tmpobjid = CreateDynamicObjectEx(19089, 1472.489990, -1807.189941, 3002.669921, 0.000000, 0.000000, 0.000000, 300.00, 300.00);

    SetDynamicObjectMaterial(tmpobjid, 0, 1736, "cj_ammo", "CJ_Black_metal", 0x00000000);

    tmpobjid = CreateDynamicObjectEx(19089, 1492.229980, -1807.199951, 3002.669921, 0.000000, 0.000000, 0.000000, 300.00, 300.00);

    SetDynamicObjectMaterial(tmpobjid, 0, 1736, "cj_ammo", "CJ_Black_metal", 0x00000000);

    tmpobjid = CreateDynamicObjectEx(19089, 1469.430053, -1807.189941, 3002.669921, 0.000000, 0.000000, 0.000000, 300.00, 300.00);

    SetDynamicObjectMaterial(tmpobjid, 0, 1736, "cj_ammo", "CJ_Black_metal", 0x00000000);

    tmpobjid = CreateDynamicObjectEx(19089, 1494.959960, -1807.199951, 3002.669921, 0.000000, 0.000000, 0.000000, 300.00, 300.00);

    SetDynamicObjectMaterial(tmpobjid, 0, 1736, "cj_ammo", "CJ_Black_metal", 0x00000000);

    tmpobjid = CreateDynamicObjectEx(19089, 1466.489990, -1807.199951, 3002.669921, 0.000000, 0.000000, 0.000000, 300.00, 300.00);

    SetDynamicObjectMaterial(tmpobjid, 0, 1736, "cj_ammo", "CJ_Black_metal", 0x00000000);

    tmpobjid = CreateDynamicObjectEx(19089, 1497.829956, -1807.189941, 3002.669921, 0.000000, 0.000000, 0.000000, 300.00, 300.00);

    SetDynamicObjectMaterial(tmpobjid, 0, 1736, "cj_ammo", "CJ_Black_metal", 0x00000000);

    tmpobjid = CreateDynamicObjectEx(1742, 1445.800048, -1795.420043, 2995.419921, 0.000000, 0.000000, -0.200000, 300.00, 300.00);

    SetDynamicObjectMaterial(tmpobjid, 2, 1736, "cj_ammo", "CJ_Black_metal", 0x00000000);

    tmpobjid = CreateDynamicObjectEx(1742, 1444.369995, -1795.410034, 2996.209960, 0.000000, 0.000000, -0.200000, 300.00, 300.00);

    SetDynamicObjectMaterial(tmpobjid, 2, 1736, "cj_ammo", "CJ_Black_metal", 0x00000000);

    tmpobjid = CreateDynamicObjectEx(1742, 1444.369995, -1795.410034, 2994.570068, 0.000000, 0.000000, -0.200000, 300.00, 300.00);

    SetDynamicObjectMaterial(tmpobjid, 2, 1736, "cj_ammo", "CJ_Black_metal", 0x00000000);

    tmpobjid = CreateDynamicObjectEx(1742, 1442.930053, -1795.400024, 2995.419921, 0.000000, 0.000000, -0.200000, 300.00, 300.00);

    SetDynamicObjectMaterial(tmpobjid, 2, 1736, "cj_ammo", "CJ_Black_metal", 0x00000000);

    tmpobjid = CreateDynamicObjectEx(1742, 1445.780029, -1801.530029, 2995.419921, 0.000000, 0.000000, 179.990005, 300.00, 300.00);

    SetDynamicObjectMaterial(tmpobjid, 2, 1736, "cj_ammo", "CJ_Black_metal", 0x00000000);

    tmpobjid = CreateDynamicObjectEx(1742, 1444.339965, -1801.530029, 2996.209960, 0.000000, 0.000000, 179.990005, 300.00, 300.00);

    SetDynamicObjectMaterial(tmpobjid, 2, 1736, "cj_ammo", "CJ_Black_metal", 0x00000000);

    tmpobjid = CreateDynamicObjectEx(1742, 1444.339965, -1801.530029, 2994.570068, 0.000000, 0.000000, 180.000000, 300.00, 300.00);

    SetDynamicObjectMaterial(tmpobjid, 2, 1736, "cj_ammo", "CJ_Black_metal", 0x00000000);

    tmpobjid = CreateDynamicObjectEx(1742, 1442.910034, -1801.530029, 2995.419921, 0.000000, 0.000000, 179.990005, 300.00, 300.00);

    SetDynamicObjectMaterial(tmpobjid, 2, 1736, "cj_ammo", "CJ_Black_metal", 0x00000000);

    tmpobjid = CreateDynamicObjectEx(14602, 1482.079956, -1788.099975, 3000.000000, 0.019999, -0.019999, 91.000000, 300.00, 300.00);

    SetDynamicObjectMaterial(tmpobjid, 0, 1736, "cj_ammo", "CJ_Black_metal", 0x00000000);

    SetDynamicObjectMaterial(tmpobjid, 2, 1736, "cj_ammo", "CJ_Black_metal", 0x00000000);

    SetDynamicObjectMaterial(tmpobjid, 3, 1736, "cj_ammo", "CJ_Black_metal", 0x00000000);

    SetDynamicObjectMaterial(tmpobjid, 4, 15041, "bigsfsave", "carp11S", 0x00000000);

    SetDynamicObjectMaterial(tmpobjid, 5, 1736, "cj_ammo", "CJ_Black_metal", 0x00000000);

    SetDynamicObjectMaterial(tmpobjid, 6, 15041, "bigsfsave", "carp11S", 0x00000000);

    SetDynamicObjectMaterial(tmpobjid, 8, 15041, "bigsfsave", "carp11S", 0x00000000);

    SetDynamicObjectMaterial(tmpobjid, 10, 16640, "a51", "ws_stationfloor", 0x00000000);

    SetDynamicObjectMaterial(tmpobjid, 11, 1736, "cj_ammo", "CJ_Black_metal", 0x00000000);

    SetDynamicObjectMaterial(tmpobjid, 12, 15041, "bigsfsave", "carp11S", 0x00000000);

    SetDynamicObjectMaterial(tmpobjid, 13, 1736, "cj_ammo", "CJ_Black_metal", 0x00000000);

    SetDynamicObjectMaterial(tmpobjid, 14, 1736, "cj_ammo", "CJ_Black_metal", 0x00000000);

    tmpobjid = CreateDynamicObjectEx(14597, 1452.969970, -1798.479980, 2996.639892, 0.000000, 0.000000, 0.000000, 300.00, 300.00);

    SetDynamicObjectMaterial(tmpobjid, 1, 1736, "cj_ammo", "CJ_Black_metal", 0x00000000);

    SetDynamicObjectMaterial(tmpobjid, 2, 1736, "cj_ammo", "CJ_Black_metal", 0x00000000);

    SetDynamicObjectMaterial(tmpobjid, 3, 15041, "bigsfsave", "carp11S", 0x00000000);

    SetDynamicObjectMaterial(tmpobjid, 4, 15041, "bigsfsave", "carp11S", 0x00000000);

    SetDynamicObjectMaterial(tmpobjid, 5, 1736, "cj_ammo", "CJ_Black_metal", 0x00000000);

    SetDynamicObjectMaterial(tmpobjid, 6, 1736, "cj_ammo", "CJ_Black_metal", 0x00000000);

    SetDynamicObjectMaterial(tmpobjid, 8, 15041, "bigsfsave", "carp11S", 0x00000000);

    tmpobjid = CreateDynamicObjectEx(19327, 1481.834350, -1803.531005, 2997.808349, 0.000000, 0.000000, -179.199981, 300.00, 300.00);

    SetDynamicObjectMaterialText(tmpobjid, 0, "CITYHALL", 50, "Calibri", 27, 1, 0xFFFFFFFF, 0x00000000, 0);

    tmpobjid = CreateDynamicObjectEx(19327, 1481.183715, -1803.540161, 2998.078857, 0.000000, 0.000000, -179.199981, 300.00, 300.00);

    SetDynamicObjectMaterialText(tmpobjid, 0, "To", 50, "Engravers MT", 17, 1, 0xFFFFFFFF, 0x00000000, 0);

    tmpobjid = CreateDynamicObjectEx(19327, 1481.994384, -1803.539184, 2998.518554, 0.000000, 0.000000, -179.199981, 300.00, 300.00);

    SetDynamicObjectMaterialText(tmpobjid, 0, "WELCOME", 50, "Calibri", 27, 1, 0xFFFFFFFF, 0x00000000, 0);

    tmpobjid = CreateDynamicObjectEx(19327, 1481.594360, -1803.534057, 2999.488769, 0.000000, 0.000000, -179.199981, 300.00, 300.00);

    SetDynamicObjectMaterialText(tmpobjid, 0, "G", 50, "Webdings", 50, 1, 0xFFFFFFFF, 0x00000000, 0);

    tmpobjid = CreateDynamicObjectEx(19327, 1440.087036, -1798.358642, 2997.294189, 0.000000, 0.000000, 92.500015, 300.00, 300.00);

    SetDynamicObjectMaterial(tmpobjid, 0, 4003, "cityhall_tr_lan", "mc_flags1", 0x00000000);

    CreateObject(1569, 362.11929, 189.40559, 1007.36353,   0.00000, 0.00000, 0.00000);

    CreateObject(19335, 1763.87073, -934.23877, 96.71983,   0.00000, 0.00000, 13.44328);

    /////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    /////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    /////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    tmpobjid = CreateDynamicObjectEx(19859, 1481.040039, -1773.410034, 2995.889892, 0.000000, 0.000000, 0.000000, 300.00, 300.00);

    tmpobjid = CreateDynamicObjectEx(1721, 1476.150024, -1788.989990, 2994.639892, 0.000000, 0.000000, 89.980003, 300.00, 300.00);

    tmpobjid = CreateDynamicObjectEx(19787, 1473.510009, -1787.329956, 2997.070068, 0.000000, 0.000000, 0.000000, 300.00, 300.00);

    tmpobjid = CreateDynamicObjectEx(19325, 1476.400024, -1789.890014, 2995.840087, 0.000000, 0.000000, 180.000000, 300.00, 300.00);

    tmpobjid = CreateDynamicObjectEx(1721, 1476.140014, -1789.969970, 2994.639892, 0.000000, 0.000000, 89.989997, 300.00, 300.00);

    tmpobjid = CreateDynamicObjectEx(1721, 1473.880004, -1788.989990, 2994.639892, 0.000000, 0.000000, 269.980010, 300.00, 300.00);

    tmpobjid = CreateDynamicObjectEx(19787, 1471.510009, -1787.430053, 2997.070068, 0.000000, 0.000000, 0.000000, 300.00, 300.00);

    tmpobjid = CreateDynamicObjectEx(2119, 1474.569946, -1789.959960, 2994.639892, 0.000000, 0.000000, 90.000000, 300.00, 300.00);

    tmpobjid = CreateDynamicObjectEx(1721, 1473.920043, -1789.839965, 2994.639892, 0.000000, 0.000000, 269.980010, 300.00, 300.00);

    tmpobjid = CreateDynamicObjectEx(1721, 1472.510009, -1789.099975, 2994.639892, 0.000000, 0.000000, 89.980003, 300.00, 300.00);

    tmpobjid = CreateDynamicObjectEx(1721, 1472.540039, -1789.939941, 2994.639892, 0.000000, 0.000000, 89.980003, 300.00, 300.00);

    tmpobjid = CreateDynamicObjectEx(19787, 1469.550048, -1787.489990, 2997.070068, 0.000000, 0.000000, 0.000000, 300.00, 300.00);

    tmpobjid = CreateDynamicObjectEx(19859, 1489.180053, -1791.750000, 2995.889892, 0.000000, 0.000000, 270.000000, 300.00, 300.00);

    tmpobjid = CreateDynamicObjectEx(1721, 1470.819946, -1789.079956, 2994.639892, 0.000000, 0.000000, 269.980010, 300.00, 300.00);

    tmpobjid = CreateDynamicObjectEx(2119, 1471.719970, -1789.959960, 2994.639892, 0.000000, 0.000000, 90.000000, 300.00, 300.00);

    tmpobjid = CreateDynamicObjectEx(1721, 1470.130004, -1788.959960, 2994.639892, 0.000000, 0.000000, 103.970001, 300.00, 300.00);

    tmpobjid = CreateDynamicObjectEx(1721, 1470.859985, -1789.930053, 2994.639892, 0.000000, 0.000000, 271.970001, 300.00, 300.00);

    tmpobjid = CreateDynamicObjectEx(1721, 1470.079956, -1790.119995, 2994.639892, 0.000000, 0.000000, 83.970001, 300.00, 300.00);

    tmpobjid = CreateDynamicObjectEx(1721, 1473.439941, -1793.170043, 2994.639892, 0.000000, 0.000000, 89.989997, 300.00, 300.00);

    tmpobjid = CreateDynamicObjectEx(2119, 1468.859985, -1789.959960, 2994.639892, 0.000000, 0.000000, 90.000000, 300.00, 300.00);

    tmpobjid = CreateDynamicObjectEx(1721, 1473.439941, -1793.949951, 2994.639892, 0.000000, 0.000000, 89.989997, 300.00, 300.00);

    tmpobjid = CreateDynamicObjectEx(1721, 1467.209960, -1788.829956, 2994.639892, 0.000000, 0.000000, 263.959991, 300.00, 300.00);

    tmpobjid = CreateDynamicObjectEx(1721, 1467.319946, -1790.170043, 2994.639892, 0.000000, 0.000000, 273.959991, 300.00, 300.00);

    tmpobjid = CreateDynamicObjectEx(2119, 1471.739990, -1794.060058, 2994.639892, 0.000000, 0.000000, 90.000000, 300.00, 300.00);

    tmpobjid = CreateDynamicObjectEx(1721, 1470.099975, -1793.109985, 2994.639892, 0.000000, 0.000000, 270.000000, 300.00, 300.00);

    tmpobjid = CreateDynamicObjectEx(1721, 1471.109985, -1794.060058, 2994.639892, 0.000000, 0.000000, 270.000000, 300.00, 300.00);

    tmpobjid = CreateDynamicObjectEx(1721, 1469.540039, -1793.030029, 2994.639892, 0.000000, 0.000000, 90.000000, 300.00, 300.00);

    tmpobjid = CreateDynamicObjectEx(19325, 1473.020019, -1795.760009, 2995.860107, 0.159999, 0.000000, 90.019996, 300.00, 300.00);

    tmpobjid = CreateDynamicObjectEx(1721, 1469.550048, -1793.979980, 2994.639892, 0.000000, 0.000000, 90.000000, 300.00, 300.00);

    tmpobjid = CreateDynamicObjectEx(1808, 1466.650024, -1791.489990, 2994.639892, 0.000000, 0.000000, 90.000000, 300.00, 300.00);

    tmpobjid = CreateDynamicObjectEx(2119, 1468.859985, -1794.060058, 2994.639892, 0.000000, 0.000000, 90.000000, 300.00, 300.00);

    tmpobjid = CreateDynamicObjectEx(1721, 1467.550048, -1793.000000, 2994.639892, 0.000000, 0.000000, 270.000000, 300.00, 300.00);

    tmpobjid = CreateDynamicObjectEx(19325, 1469.979980, -1795.770019, 2995.840087, 0.000000, 0.000000, 90.000000, 300.00, 300.00);

    tmpobjid = CreateDynamicObjectEx(14598, 1462.339965, -1786.680053, 2992.790039, 0.000000, 0.000000, 0.000000, 300.00, 300.00);

    tmpobjid = CreateDynamicObjectEx(1721, 1467.560058, -1794.000000, 2994.639892, 0.000000, 0.000000, 270.000000, 300.00, 300.00);

    tmpobjid = CreateDynamicObjectEx(1715, 1462.479980, -1788.459960, 2994.639892, 0.000000, 0.000000, 269.989990, 300.00, 300.00);

    tmpobjid = CreateDynamicObjectEx(19786, 1460.630004, -1784.859985, 2996.899902, 0.000000, 0.000000, 0.000000, 300.00, 300.00);

    tmpobjid = CreateDynamicObjectEx(2206, 1461.530029, -1787.160034, 2994.639892, 0.000000, 0.000000, 179.990005, 300.00, 300.00);

    tmpobjid = CreateDynamicObjectEx(1714, 1460.670043, -1785.449951, 2994.639892, 0.000000, 0.000000, 0.000000, 300.00, 300.00);

    tmpobjid = CreateDynamicObjectEx(1715, 1462.469970, -1789.689941, 2994.639892, 0.000000, 0.000000, 269.989990, 300.00, 300.00);

    tmpobjid = CreateDynamicObjectEx(1715, 1462.469970, -1791.020019, 2994.639892, 0.000000, 0.000000, 269.989990, 300.00, 300.00);

    tmpobjid = CreateDynamicObjectEx(2357, 1460.579956, -1789.670043, 2995.040039, 0.000000, 0.000000, 90.000000, 300.00, 300.00);

    tmpobjid = CreateDynamicObjectEx(19859, 1497.920043, -1797.040039, 2995.889892, 0.000000, 0.000000, 270.000000, 300.00, 300.00);

    tmpobjid = CreateDynamicObjectEx(1726, 1474.349975, -1801.819946, 2994.629882, 0.000000, 0.000000, 180.000000, 300.00, 300.00);

    tmpobjid = CreateDynamicObjectEx(2854, 1475.189941, -1802.270019, 2995.139892, 0.000000, 0.000000, -40.000000, 300.00, 300.00);

    tmpobjid = CreateDynamicObjectEx(1715, 1458.680053, -1788.520019, 2994.639892, 0.000000, 0.000000, 90.000000, 300.00, 300.00);

    tmpobjid = CreateDynamicObjectEx(2855, 1489.640014, -1802.390014, 2995.139892, 0.000000, 0.000000, 10.000000, 300.00, 300.00);

    tmpobjid = CreateDynamicObjectEx(19466, 1482.359985, -1803.550048, 2996.939941, 0.000000, 0.000000, 269.989990, 300.00, 300.00);

    tmpobjid = CreateDynamicObjectEx(19466, 1482.359985, -1803.550048, 2998.030029, 0.000000, 0.000000, 269.989990, 300.00, 300.00);

    tmpobjid = CreateDynamicObjectEx(19483, 1482.369995, -1803.560058, 2998.010009, 0.000000, 0.000000, 88.400001, 300.00, 300.00);

    tmpobjid = CreateDynamicObjectEx(2126, 1475.619995, -1802.839965, 2994.629882, 0.000000, 0.000000, 90.000000, 300.00, 300.00);

    tmpobjid = CreateDynamicObjectEx(19483, 1482.369995, -1803.560058, 2998.350097, 0.000000, 0.000000, 88.400001, 300.00, 300.00);

    tmpobjid = CreateDynamicObjectEx(19483, 1482.369995, -1803.560058, 2998.679931, 0.000000, 0.000000, 88.400001, 300.00, 300.00);

    tmpobjid = CreateDynamicObjectEx(19466, 1482.359985, -1803.550048, 2998.879882, 0.000000, 0.000000, 269.989990, 300.00, 300.00);

    tmpobjid = CreateDynamicObjectEx(19483, 1482.369995, -1803.560058, 2999.419921, 0.000000, 0.000000, 88.400001, 300.00, 300.00);

    tmpobjid = CreateDynamicObjectEx(1726, 1492.380004, -1801.829956, 2994.629882, 0.000000, 0.000000, 179.990005, 300.00, 300.00);

    tmpobjid = CreateDynamicObjectEx(1726, 1471.910034, -1801.829956, 2994.629882, 0.000000, 0.000000, 179.990005, 300.00, 300.00);

    tmpobjid = CreateDynamicObjectEx(1715, 1458.680053, -1789.689941, 2994.639892, 0.000000, 0.000000, 90.000000, 300.00, 300.00);

    tmpobjid = CreateDynamicObjectEx(19466, 1482.359985, -1803.550048, 3000.810058, 0.000000, 0.000000, 269.989990, 300.00, 300.00);

    tmpobjid = CreateDynamicObjectEx(2126, 1490.109985, -1802.900024, 2994.629882, 0.000000, 0.000000, 90.000000, 300.00, 300.00);

    tmpobjid = CreateDynamicObjectEx(1726, 1490.369995, -1802.910034, 2994.629882, 0.000000, 0.000000, 0.000000, 300.00, 300.00);

    tmpobjid = CreateDynamicObjectEx(19859, 1466.289672, -1799.110107, 2995.869873, 0.000000, 0.000000, 0.000000, 300.00, 300.00);

    tmpobjid = CreateDynamicObjectEx(19466, 1480.390014, -1804.270019, 2996.939941, 0.000000, 0.000000, 309.980010, 300.00, 300.00);

    tmpobjid = CreateDynamicObjectEx(19466, 1484.339965, -1804.270019, 2996.939941, 0.000000, 0.000000, 50.009998, 300.00, 300.00);

    tmpobjid = CreateDynamicObjectEx(2164, 1456.369995, -1785.349975, 2994.639892, 0.000000, 0.000000, 269.989990, 300.00, 300.00);

    tmpobjid = CreateDynamicObjectEx(19808, 1481.959960, -1804.420043, 2995.379882, 0.000000, 0.000000, 16.000000, 300.00, 300.00);

    tmpobjid = CreateDynamicObjectEx(19466, 1480.390014, -1804.270019, 2998.030029, 0.000000, 0.000000, 309.980010, 300.00, 300.00);

    tmpobjid = CreateDynamicObjectEx(19466, 1484.339965, -1804.270019, 2998.030029, 0.000000, 0.000000, 50.009998, 300.00, 300.00);

    tmpobjid = CreateDynamicObjectEx(19807, 1483.439941, -1804.459960, 2995.439941, 0.000000, 0.000000, 330.000000, 300.00, 300.00);

    tmpobjid = CreateDynamicObjectEx(1715, 1458.680053, -1790.900024, 2994.639892, 0.000000, 0.000000, 90.000000, 300.00, 300.00);

    tmpobjid = CreateDynamicObjectEx(19466, 1480.390014, -1804.270019, 2998.879882, 0.000000, 0.000000, 309.980010, 300.00, 300.00);

    tmpobjid = CreateDynamicObjectEx(19466, 1484.339965, -1804.270019, 2998.879882, 0.000000, 0.000000, 50.009998, 300.00, 300.00);

    tmpobjid = CreateDynamicObjectEx(2200, 1456.890014, -1787.790039, 2994.639892, 0.000000, 0.000000, 90.000000, 300.00, 300.00);

    tmpobjid = CreateDynamicObjectEx(1726, 1472.339965, -1802.910034, 2994.629882, 0.000000, 0.000000, 0.000000, 300.00, 300.00);

    tmpobjid = CreateDynamicObjectEx(19466, 1480.390014, -1804.270019, 3000.810058, 0.000000, 0.000000, 309.980010, 300.00, 300.00);

    tmpobjid = CreateDynamicObjectEx(19466, 1484.339965, -1804.270019, 3000.810058, 0.000000, 0.000000, 50.009998, 300.00, 300.00);

    tmpobjid = CreateDynamicObjectEx(1726, 1494.819946, -1801.819946, 2994.629882, 0.000000, 0.000000, 180.000000, 300.00, 300.00);

    tmpobjid = CreateDynamicObjectEx(2164, 1456.369995, -1787.130004, 2994.639892, 0.000000, 0.000000, 269.989990, 300.00, 300.00);

    tmpobjid = CreateDynamicObjectEx(1726, 1492.810058, -1802.910034, 2994.629882, 0.000000, 0.000000, 0.000000, 300.00, 300.00);

    tmpobjid = CreateDynamicObjectEx(2162, 1456.760009, -1789.329956, 2994.570068, 0.000000, 0.000000, 97.989997, 300.00, 300.00);

    tmpobjid = CreateDynamicObjectEx(2855, 1469.170043, -1802.390014, 2995.139892, 0.000000, 0.000000, 10.000000, 300.00, 300.00);

    tmpobjid = CreateDynamicObjectEx(19786, 1456.790039, -1789.670043, 2996.899902, 0.000000, 0.000000, 90.000000, 300.00, 300.00);

    tmpobjid = CreateDynamicObjectEx(2163, 1456.380004, -1788.900024, 2994.639892, 0.000000, 0.000000, 269.989990, 300.00, 300.00);

    tmpobjid = CreateDynamicObjectEx(2854, 1495.670043, -1802.270019, 2995.139892, 0.000000, 0.000000, 320.000000, 300.00, 300.00);

    tmpobjid = CreateDynamicObjectEx(1726, 1469.900024, -1802.910034, 2994.629882, 0.000000, 0.000000, 0.000000, 300.00, 300.00);

    tmpobjid = CreateDynamicObjectEx(2126, 1469.640014, -1802.900024, 2994.629882, 0.000000, 0.000000, 90.000000, 300.00, 300.00);

    tmpobjid = CreateDynamicObjectEx(1714, 1482.290039, -1805.849975, 2994.639892, 0.000000, 0.000000, 180.000000, 300.00, 300.00);

    tmpobjid = CreateDynamicObjectEx(2162, 1456.819946, -1790.349975, 2994.570068, 0.000000, 0.000000, 89.989997, 300.00, 300.00);

    tmpobjid = CreateDynamicObjectEx(2208, 1456.880004, -1790.989990, 2994.639892, 0.000000, 0.000000, 90.000000, 300.00, 300.00);

    tmpobjid = CreateDynamicObjectEx(19786, 1456.439941, -1790.119995, 2996.899902, 0.000000, 0.000000, 270.000000, 300.00, 300.00);

    tmpobjid = CreateDynamicObjectEx(19466, 1479.329956, -1806.089965, 2996.939941, 0.000000, 0.000000, 349.980010, 300.00, 300.00);

    tmpobjid = CreateDynamicObjectEx(19466, 1485.390014, -1806.089965, 2996.939941, 0.000000, 0.000000, 10.010000, 300.00, 300.00);

    tmpobjid = CreateDynamicObjectEx(19466, 1479.329956, -1806.089965, 2998.030029, 0.000000, 0.000000, 349.980010, 300.00, 300.00);

    tmpobjid = CreateDynamicObjectEx(19466, 1485.390014, -1806.089965, 2998.030029, 0.000000, 0.000000, 10.010000, 300.00, 300.00);

    tmpobjid = CreateDynamicObjectEx(2162, 1456.400024, -1790.670043, 2994.639892, 0.000000, 0.000000, 269.989990, 300.00, 300.00);

    tmpobjid = CreateDynamicObjectEx(19466, 1479.329956, -1806.089965, 2998.879882, 0.000000, 0.000000, 349.980010, 300.00, 300.00);

    tmpobjid = CreateDynamicObjectEx(2126, 1496.089965, -1802.839965, 2994.629882, 0.000000, 0.000000, 90.000000, 300.00, 300.00);

    tmpobjid = CreateDynamicObjectEx(19466, 1485.390014, -1806.089965, 2998.879882, 0.000000, 0.000000, 10.010000, 300.00, 300.00);

    tmpobjid = CreateDynamicObjectEx(19466, 1479.329956, -1806.089965, 3000.810058, 0.000000, 0.000000, 349.980010, 300.00, 300.00);

    tmpobjid = CreateDynamicObjectEx(19466, 1485.390014, -1806.089965, 3000.810058, 0.000000, 0.000000, 10.010000, 300.00, 300.00);

    tmpobjid = CreateDynamicObjectEx(2162, 1484.420043, -1806.829956, 2994.620117, 0.000000, 0.000000, 270.000000, 300.00, 300.00);

    tmpobjid = CreateDynamicObjectEx(2200, 1456.890014, -1792.790039, 2994.639892, 0.000000, 0.000000, 90.000000, 300.00, 300.00);

    tmpobjid = CreateDynamicObjectEx(2206, 1453.579956, -1787.160034, 2994.639892, 0.000000, 0.000000, 179.990005, 300.00, 300.00);

    tmpobjid = CreateDynamicObjectEx(2162, 1480.219970, -1807.630004, 2994.620117, 0.000000, 0.000000, 90.000000, 300.00, 300.00);

    tmpobjid = CreateDynamicObjectEx(2614, 1452.699951, -1784.910034, 2996.969970, 0.000000, 0.000000, 0.000000, 300.00, 300.00);

    tmpobjid = CreateDynamicObjectEx(1999, 1477.010009, -1807.540039, 2994.729980, 0.000000, 0.000000, 0.000000, 300.00, 300.00);

    tmpobjid = CreateDynamicObjectEx(1714, 1452.699951, -1785.410034, 2994.639892, 0.000000, 0.000000, 0.000000, 300.00, 300.00);

    tmpobjid = CreateDynamicObjectEx(19325, 1475.810058, -1807.189941, 2998.040039, 0.000000, 0.000000, 90.000000, 300.00, 300.00);

    tmpobjid = CreateDynamicObjectEx(1999, 1486.670043, -1807.419799, 2994.729980, 0.000000, 0.000000, 0.000000, 300.00, 300.00);

    tmpobjid = CreateDynamicObjectEx(19325, 1488.910034, -1807.189941, 2998.040039, 0.000000, 0.000000, 90.000000, 300.00, 300.00);

    tmpobjid = CreateDynamicObjectEx(1726, 1454.170043, -1789.859985, 2994.639892, 0.000000, 0.000000, 270.000000, 300.00, 300.00);

    tmpobjid = CreateDynamicObjectEx(2162, 1489.420043, -1807.329833, 2994.620117, 0.000000, 0.000000, 0.000000, 300.00, 300.00);

    tmpobjid = CreateDynamicObjectEx(1999, 1473.549926, -1807.530029, 2994.729980, 0.000000, 0.000000, 0.000000, 300.00, 300.00);

    tmpobjid = CreateDynamicObjectEx(1999, 1490.139892, -1807.359741, 2994.729980, 0.000000, 0.000000, 0.000000, 300.00, 300.00);

    tmpobjid = CreateDynamicObjectEx(1715, 1477.650024, -1809.089965, 2994.629882, 0.000000, 0.000000, 170.000000, 300.00, 300.00);

    tmpobjid = CreateDynamicObjectEx(1715, 1487.689941, -1809.050048, 2994.629882, 0.000000, 0.000000, 189.990005, 300.00, 300.00);

    tmpobjid = CreateDynamicObjectEx(1999, 1470.120117, -1807.530029, 2994.729980, 0.000000, 0.000000, 0.000000, 300.00, 300.00);

    tmpobjid = CreateDynamicObjectEx(2126, 1453.150024, -1791.339965, 2994.639892, 0.000000, 0.000000, 90.000000, 300.00, 300.00);

    tmpobjid = CreateDynamicObjectEx(1999, 1493.039672, -1807.349731, 2994.729980, 0.000000, 0.000000, 0.000000, 300.00, 300.00);

    tmpobjid = CreateDynamicObjectEx(2853, 1452.680053, -1790.920043, 2995.149902, 0.000000, 0.000000, 0.000000, 300.00, 300.00);

    tmpobjid = CreateDynamicObjectEx(19325, 1469.170043, -1807.189941, 2998.040039, 0.000000, 0.000000, 90.000000, 300.00, 300.00);

    tmpobjid = CreateDynamicObjectEx(19325, 1495.550048, -1807.189941, 2998.040039, 0.000000, 0.000000, 90.000000, 300.00, 300.00);

    tmpobjid = CreateDynamicObjectEx(1715, 1473.959960, -1809.140014, 2994.629882, 0.000000, 0.000000, 179.990005, 300.00, 300.00);

    tmpobjid = CreateDynamicObjectEx(1715, 1490.709960, -1809.160034, 2994.629882, 0.000000, 0.000000, 179.990005, 300.00, 300.00);

    tmpobjid = CreateDynamicObjectEx(1999, 1496.039794, -1807.289672, 2994.729980, 0.000000, 0.000000, 0.000000, 300.00, 300.00);

    tmpobjid = CreateDynamicObjectEx(1999, 1467.080200, -1807.530029, 2994.729980, 0.000000, 0.000000, 0.000000, 300.00, 300.00);

    tmpobjid = CreateDynamicObjectEx(2162, 1464.209960, -1805.810058, 2994.639892, 0.000000, 0.000000, 269.989990, 300.00, 300.00);

    tmpobjid = CreateDynamicObjectEx(1715, 1493.599975, -1809.140014, 2994.629882, 0.000000, 0.000000, 179.990005, 300.00, 300.00);

    tmpobjid = CreateDynamicObjectEx(1715, 1470.660034, -1809.170043, 2994.629882, 0.000000, 0.000000, 179.990005, 300.00, 300.00);

    tmpobjid = CreateDynamicObjectEx(2164, 1482.359985, -1811.229980, 2994.629882, 0.000000, 0.000000, 179.990005, 300.00, 300.00);

    tmpobjid = CreateDynamicObjectEx(2163, 1480.589965, -1811.239990, 2994.629882, 0.000000, 0.000000, 179.990005, 300.00, 300.00);

    tmpobjid = CreateDynamicObjectEx(2163, 1484.140014, -1811.239990, 2994.629882, 0.000000, 0.000000, 180.000000, 300.00, 300.00);

    tmpobjid = CreateDynamicObjectEx(2164, 1449.020019, -1786.140014, 2994.639892, 0.000000, 0.000000, 89.989997, 300.00, 300.00);

    tmpobjid = CreateDynamicObjectEx(1726, 1451.079956, -1791.880004, 2994.639892, 0.000000, 0.000000, 90.000000, 300.00, 300.00);

    tmpobjid = CreateDynamicObjectEx(1726, 1451.079956, -1791.880004, 2994.639892, 0.000000, 0.000000, 90.000000, 300.00, 300.00);

    tmpobjid = CreateDynamicObjectEx(19859, 1476.680053, -1811.260009, 2995.889892, 0.000000, 0.000000, 179.990005, 300.00, 300.00);

    tmpobjid = CreateDynamicObjectEx(19859, 1488.640014, -1811.260009, 2995.889892, 0.000000, 0.000000, 180.000000, 300.00, 300.00);

    tmpobjid = CreateDynamicObjectEx(1715, 1496.209960, -1809.119995, 2994.629882, 0.000000, 0.000000, 179.990005, 300.00, 300.00);

    tmpobjid = CreateDynamicObjectEx(2164, 1449.030029, -1787.920043, 2994.639892, 0.000000, 0.000000, 89.989997, 300.00, 300.00);

    tmpobjid = CreateDynamicObjectEx(1715, 1467.949951, -1809.180053, 2994.629882, 0.000000, 0.000000, 179.990005, 300.00, 300.00);

    tmpobjid = CreateDynamicObjectEx(2356, 1462.560058, -1806.229980, 2994.639892, 0.000000, 0.000000, 90.000000, 300.00, 300.00);

    tmpobjid = CreateDynamicObjectEx(2164, 1464.189941, -1807.579956, 2994.639892, 0.000000, 0.000000, 269.989990, 300.00, 300.00);

    tmpobjid = CreateDynamicObjectEx(2162, 1449.000000, -1789.689941, 2994.639892, 0.000000, 0.000000, 89.989997, 300.00, 300.00);

    tmpobjid = CreateDynamicObjectEx(2163, 1471.359985, -1811.270019, 2994.629882, 0.000000, 0.000000, 179.990005, 300.00, 300.00);

    tmpobjid = CreateDynamicObjectEx(2163, 1493.170043, -1811.229980, 2994.629882, 0.000000, 0.000000, 180.000000, 300.00, 300.00);

    tmpobjid = CreateDynamicObjectEx(19786, 1448.890014, -1790.140014, 2996.899902, 0.000000, 0.000000, 90.000000, 300.00, 300.00);

    tmpobjid = CreateDynamicObjectEx(2163, 1449.020019, -1791.459960, 2994.639892, 0.000000, 0.000000, 90.000000, 300.00, 300.00);

    tmpobjid = CreateDynamicObjectEx(2162, 1469.579956, -1811.280029, 2994.629882, 0.000000, 0.000000, 179.990005, 300.00, 300.00);

    tmpobjid = CreateDynamicObjectEx(2162, 1494.939941, -1811.250000, 2994.629882, 0.000000, 0.000000, 179.990005, 300.00, 300.00);

    tmpobjid = CreateDynamicObjectEx(2356, 1462.650024, -1808.160034, 2994.639892, 0.000000, 0.000000, 60.000000, 300.00, 300.00);

    tmpobjid = CreateDynamicObjectEx(2356, 1458.410034, -1806.189941, 2994.639892, 0.000000, 0.000000, 269.989990, 300.00, 300.00);

    tmpobjid = CreateDynamicObjectEx(2183, 1461.130004, -1808.609985, 2994.639892, 0.000000, 0.000000, 90.000000, 300.00, 300.00);

    tmpobjid = CreateDynamicObjectEx(2356, 1462.760009, -1810.000000, 2994.639892, 0.000000, 0.000000, 219.990005, 300.00, 300.00);

    tmpobjid = CreateDynamicObjectEx(2166, 1463.750000, -1810.619995, 2994.639892, 0.000000, 0.000000, 179.990005, 300.00, 300.00);

    tmpobjid = CreateDynamicObjectEx(2356, 1458.479980, -1807.939941, 2994.639892, 0.000000, 0.000000, 279.989990, 300.00, 300.00);

    tmpobjid = CreateDynamicObjectEx(2172, 1454.719970, -1804.650024, 2994.639892, 0.000000, 0.000000, 179.990005, 300.00, 300.00);

    tmpobjid = CreateDynamicObjectEx(2162, 1456.819946, -1806.739990, 2994.639892, 0.000000, 0.000000, 90.000000, 300.00, 300.00);

    tmpobjid = CreateDynamicObjectEx(2356, 1453.750000, -1804.109985, 2994.639892, 0.000000, 0.000000, 209.979995, 300.00, 300.00);

    tmpobjid = CreateDynamicObjectEx(19786, 1456.410034, -1807.800048, 2997.020019, 0.000000, 0.000000, 270.000000, 300.00, 300.00);

    tmpobjid = CreateDynamicObjectEx(2193, 1453.709960, -1805.619995, 2994.639892, 0.000000, 0.000000, 269.989990, 300.00, 300.00);

    tmpobjid = CreateDynamicObjectEx(2163, 1456.829956, -1808.510009, 2994.639892, 0.000000, 0.000000, 90.000000, 300.00, 300.00);

    tmpobjid = CreateDynamicObjectEx(2356, 1460.250000, -1811.030029, 2994.639892, 0.000000, 0.000000, 189.990005, 300.00, 300.00);

    tmpobjid = CreateDynamicObjectEx(2165, 1461.020019, -1811.609985, 2994.649902, 0.000000, 0.000000, 180.000000, 300.00, 300.00);

    tmpobjid = CreateDynamicObjectEx(2356, 1453.729980, -1806.160034, 2994.639892, 0.000000, 0.000000, 269.980010, 300.00, 300.00);

    tmpobjid = CreateDynamicObjectEx(2356, 1457.550048, -1809.689941, 2994.639892, 0.000000, 0.000000, 189.990005, 300.00, 300.00);

    tmpobjid = CreateDynamicObjectEx(2172, 1451.839965, -1804.650024, 2994.639892, 0.000000, 0.000000, 180.000000, 300.00, 300.00);

    tmpobjid = CreateDynamicObjectEx(2356, 1450.930053, -1803.849975, 2994.639892, 0.000000, 0.000000, 289.980010, 300.00, 300.00);

    tmpobjid = CreateDynamicObjectEx(2174, 1458.270019, -1811.619995, 2994.639892, 0.000000, 0.000000, 180.000000, 300.00, 300.00);

    tmpobjid = CreateDynamicObjectEx(2193, 1454.699951, -1808.869995, 2994.639892, 0.000000, 0.000000, 180.000000, 300.00, 300.00);

    tmpobjid = CreateDynamicObjectEx(2356, 1451.630004, -1806.430053, 2994.639892, 0.000000, 0.000000, 29.979999, 300.00, 300.00);

    tmpobjid = CreateDynamicObjectEx(2356, 1453.540039, -1808.939941, 2994.639892, 0.000000, 0.000000, 279.989990, 300.00, 300.00);

    tmpobjid = CreateDynamicObjectEx(2193, 1450.829956, -1806.630004, 2994.639892, 0.000000, 0.000000, 359.989990, 300.00, 300.00);

    tmpobjid = CreateDynamicObjectEx(2825, 1444.800048, -1798.550048, 2995.129882, 0.000000, 0.000000, 18.000000, 300.00, 300.00);

    tmpobjid = CreateDynamicObjectEx(2571, 1443.939941, -1796.979980, 2994.639892, 0.000000, 0.000000, 270.000000, 300.00, 300.00);

    tmpobjid = CreateDynamicObjectEx(2356, 1452.290039, -1808.680053, 2994.639892, 0.000000, 0.000000, 109.989997, 300.00, 300.00);

    tmpobjid = CreateDynamicObjectEx(2193, 1451.780029, -1809.900024, 2994.639892, 0.000000, 0.000000, 90.000000, 300.00, 300.00);

    tmpobjid = CreateDynamicObjectEx(2206, 1442.060058, -1797.520019, 2994.639892, 0.000000, 0.000000, 270.000000, 300.00, 300.00);

    tmpobjid = CreateDynamicObjectEx(19786, 1448.979980, -1807.699951, 2997.020019, 0.000000, 0.000000, 90.000000, 300.00, 300.00);

    tmpobjid = CreateDynamicObjectEx(2894, 1441.859985, -1798.390014, 2995.580078, 0.000000, 0.000000, 276.000000, 300.00, 300.00);

    tmpobjid = CreateDynamicObjectEx(1714, 1440.369995, -1798.650024, 2994.649902, 0.000000, 0.000000, 110.000000, 300.00, 300.00);

    tmpobjid = CreateDynamicObjectEx(19619, 1439.859985, -1798.849975, 2995.520019, 0.000000, 0.000000, 90.000000, 300.00, 300.00);

} 
