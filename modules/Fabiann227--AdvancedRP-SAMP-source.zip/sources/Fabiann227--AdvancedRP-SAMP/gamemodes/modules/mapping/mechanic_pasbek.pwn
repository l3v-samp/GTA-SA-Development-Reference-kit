#include <YSI\y_hooks>


hook OnGameModeInit()
{
	new tmpobjid;
	tmpobjid = CreateDynamicObject(19377, 323.891632, -1822.218994, 3.304260, 0.000000, 90.000000, 0.000000, -1, -1, -1, 300.00, 300.00);
	SetDynamicObjectMaterial(tmpobjid, 0, 9514, "711_sfw", "ws_carpark2", 0x00000000);
	tmpobjid = CreateDynamicObject(19377, 344.678009, -1822.270385, 3.304260, 0.000000, 90.000000, 0.000000, -1, -1, -1, 300.00, 300.00);
	SetDynamicObjectMaterial(tmpobjid, 0, 9514, "711_sfw", "ws_carpark2", 0x00000000);
	tmpobjid = CreateDynamicObject(19377, 344.637756, -1831.800537, 3.304260, 0.000000, 90.000000, 0.000000, -1, -1, -1, 300.00, 300.00);
	SetDynamicObjectMaterial(tmpobjid, 0, 9514, "711_sfw", "ws_carpark2", 0x00000000);
	tmpobjid = CreateDynamicObject(19377, 334.278411, -1831.782836, 3.304260, 0.000000, 90.000000, 0.000000, -1, -1, -1, 300.00, 300.00);
	SetDynamicObjectMaterial(tmpobjid, 0, 9514, "711_sfw", "ws_carpark2", 0x00000000);
	tmpobjid = CreateDynamicObject(19377, 323.938232, -1831.747802, 3.304260, 0.000000, 90.000000, 0.000000, -1, -1, -1, 300.00, 300.00);
	SetDynamicObjectMaterial(tmpobjid, 0, 9514, "711_sfw", "ws_carpark2", 0x00000000);
	tmpobjid = CreateDynamicObject(19456, 318.613922, -1822.314453, 4.972980, 0.000000, 0.000000, 0.000000, -1, -1, -1, 300.00, 300.00);
	SetDynamicObjectMaterial(tmpobjid, 0, 10101, "2notherbuildsfe", "sl_vicwall02", 0x00000000);
	tmpobjid = CreateDynamicObject(19456, 318.643005, -1831.719604, 4.972980, 0.000000, 0.000000, 0.000000, -1, -1, -1, 300.00, 300.00);
	SetDynamicObjectMaterial(tmpobjid, 0, 10101, "2notherbuildsfe", "sl_vicwall02", 0x00000000);
	tmpobjid = CreateDynamicObject(19456, 349.861541, -1831.826416, 4.972980, 0.000000, 0.000000, 0.000000, -1, -1, -1, 300.00, 300.00);
	SetDynamicObjectMaterial(tmpobjid, 0, 10101, "2notherbuildsfe", "sl_vicwall02", 0x00000000);
	tmpobjid = CreateDynamicObject(19456, 349.863952, -1822.316528, 4.972980, 0.000000, 0.000000, 0.000000, -1, -1, -1, 300.00, 300.00);
	SetDynamicObjectMaterial(tmpobjid, 0, 10101, "2notherbuildsfe", "sl_vicwall02", 0x00000000);
	tmpobjid = CreateDynamicObject(19456, 345.036987, -1836.587036, 4.973000, 0.000000, 0.000000, 90.000000, -1, -1, -1, 300.00, 300.00);
	SetDynamicObjectMaterial(tmpobjid, 0, 10101, "2notherbuildsfe", "sl_vicwall02", 0x00000000);
	tmpobjid = CreateDynamicObject(19456, 335.525939, -1836.586425, 4.973000, 0.000000, 0.000000, 90.000000, -1, -1, -1, 300.00, 300.00);
	SetDynamicObjectMaterial(tmpobjid, 0, 10101, "2notherbuildsfe", "sl_vicwall02", 0x00000000);
	tmpobjid = CreateDynamicObject(19377, 323.822814, -1841.352416, 3.304260, 0.000000, 90.000000, 0.000000, -1, -1, -1, 300.00, 300.00);
	SetDynamicObjectMaterial(tmpobjid, 0, 9514, "711_sfw", "ws_carpark2", 0x00000000);
	tmpobjid = CreateDynamicObject(19456, 318.651519, -1841.353515, 4.972980, 0.000000, 0.000000, 0.000000, -1, -1, -1, 300.00, 300.00);
	SetDynamicObjectMaterial(tmpobjid, 0, 10101, "2notherbuildsfe", "sl_vicwall02", 0x00000000);
	tmpobjid = CreateDynamicObject(19456, 329.009246, -1841.324584, 4.972980, 0.000000, 0.000000, 0.000000, -1, -1, -1, 300.00, 300.00);
	SetDynamicObjectMaterial(tmpobjid, 0, 10101, "2notherbuildsfe", "sl_vicwall02", 0x00000000);
	tmpobjid = CreateDynamicObject(19456, 324.239807, -1846.108520, 1.728179, 0.000000, 0.000000, 90.000000, -1, -1, -1, 300.00, 300.00);
	SetDynamicObjectMaterial(tmpobjid, 0, 10101, "2notherbuildsfe", "sl_vicwall02", 0x00000000);
	tmpobjid = CreateDynamicObject(19456, 323.394378, -1846.129638, 1.728179, 0.000000, 0.000000, 90.000000, -1, -1, -1, 300.00, 300.00);
	SetDynamicObjectMaterial(tmpobjid, 0, 10101, "2notherbuildsfe", "sl_vicwall02", 0x00000000);
	tmpobjid = CreateDynamicObject(19456, 318.636535, -1841.396728, 1.608199, 0.000000, 0.000000, 0.000000, -1, -1, -1, 300.00, 300.00);
	SetDynamicObjectMaterial(tmpobjid, 0, 10101, "2notherbuildsfe", "sl_vicwall02", 0x00000000);
	tmpobjid = CreateDynamicObject(19456, 318.617462, -1831.816284, 1.608199, 0.000000, 0.000000, 0.000000, -1, -1, -1, 300.00, 300.00);
	SetDynamicObjectMaterial(tmpobjid, 0, 10101, "2notherbuildsfe", "sl_vicwall02", 0x00000000);
	tmpobjid = CreateDynamicObject(19456, 318.603881, -1822.253295, 1.608199, 0.000000, 0.000000, 0.000000, -1, -1, -1, 300.00, 300.00);
	SetDynamicObjectMaterial(tmpobjid, 0, 10101, "2notherbuildsfe", "sl_vicwall02", 0x00000000);
	tmpobjid = CreateDynamicObject(19456, 329.001129, -1841.381103, 1.738199, 0.000000, 0.000000, 0.000000, -1, -1, -1, 300.00, 300.00);
	SetDynamicObjectMaterial(tmpobjid, 0, 10101, "2notherbuildsfe", "sl_vicwall02", 0x00000000);
	tmpobjid = CreateDynamicObject(19456, 333.890838, -1836.568847, 1.608180, 0.000000, 0.000000, 90.000000, -1, -1, -1, 300.00, 300.00);
	SetDynamicObjectMaterial(tmpobjid, 0, 10101, "2notherbuildsfe", "sl_vicwall02", 0x00000000);
	tmpobjid = CreateDynamicObject(19456, 343.525878, -1836.554931, 1.608180, 0.000000, 0.000000, 90.000000, -1, -1, -1, 300.00, 300.00);
	SetDynamicObjectMaterial(tmpobjid, 0, 10101, "2notherbuildsfe", "sl_vicwall02", 0x00000000);
	tmpobjid = CreateDynamicObject(19456, 345.123870, -1836.560180, 1.608180, 0.000000, 0.000000, 90.000000, -1, -1, -1, 300.00, 300.00);
	SetDynamicObjectMaterial(tmpobjid, 0, 10101, "2notherbuildsfe", "sl_vicwall02", 0x00000000);
	tmpobjid = CreateDynamicObject(19456, 349.852355, -1831.711791, 1.608199, 0.000000, 0.000000, 0.000000, -1, -1, -1, 300.00, 300.00);
	SetDynamicObjectMaterial(tmpobjid, 0, 10101, "2notherbuildsfe", "sl_vicwall02", 0x00000000);
	tmpobjid = CreateDynamicObject(19456, 349.842468, -1822.375488, 1.608199, 0.000000, 0.000000, 0.000000, -1, -1, -1, 300.00, 300.00);
	SetDynamicObjectMaterial(tmpobjid, 0, 10101, "2notherbuildsfe", "sl_vicwall02", 0x00000000);
	tmpobjid = CreateDynamicObject(19456, 345.099578, -1817.477783, 4.973000, 0.000000, 0.000000, 90.000000, -1, -1, -1, 300.00, 300.00);
	SetDynamicObjectMaterial(tmpobjid, 0, 10101, "2notherbuildsfe", "sl_vicwall02", 0x00000000);
	tmpobjid = CreateDynamicObject(19456, 323.393035, -1817.568481, 4.973000, 0.000000, 0.000000, 90.000000, -1, -1, -1, 300.00, 300.00);
	SetDynamicObjectMaterial(tmpobjid, 0, 10101, "2notherbuildsfe", "sl_vicwall02", 0x00000000);
	tmpobjid = CreateDynamicObject(19410, 329.218994, -1817.574340, 4.960730, 0.000000, 0.000000, 90.000000, -1, -1, -1, 300.00, 300.00);
	SetDynamicObjectMaterial(tmpobjid, 0, 10101, "2notherbuildsfe", "sl_vicwall02", 0x00000000);
	tmpobjid = CreateDynamicObject(19410, 339.067169, -1817.478759, 4.960730, 0.000000, 0.000000, 90.000000, -1, -1, -1, 300.00, 300.00);
	SetDynamicObjectMaterial(tmpobjid, 0, 10101, "2notherbuildsfe", "sl_vicwall02", 0x00000000);
	tmpobjid = CreateDynamicObject(19393, 320.389221, -1836.594604, 4.984039, 0.000000, 0.000000, 90.000000, -1, -1, -1, 300.00, 300.00);
	SetDynamicObjectMaterial(tmpobjid, 0, 10101, "2notherbuildsfe", "sl_vicwall02", 0x00000000);
	tmpobjid = CreateDynamicObject(19364, 320.222930, -1846.113037, 4.959030, 0.000000, 0.000000, 90.000000, -1, -1, -1, 300.00, 300.00);
	SetDynamicObjectMaterial(tmpobjid, 0, 10101, "2notherbuildsfe", "sl_vicwall02", 0x00000000);
	tmpobjid = CreateDynamicObject(19364, 327.488372, -1846.080078, 4.959030, 0.000000, 0.000000, 90.000000, -1, -1, -1, 300.00, 300.00);
	SetDynamicObjectMaterial(tmpobjid, 0, 10101, "2notherbuildsfe", "sl_vicwall02", 0x00000000);
	tmpobjid = CreateDynamicObject(19378, 323.825256, -1841.350952, 3.383500, 0.000000, 90.000000, 0.000000, -1, -1, -1, 300.00, 300.00);
	SetDynamicObjectMaterial(tmpobjid, 0, 4828, "airport3_las", "brwall_128", 0x00000000);
	tmpobjid = CreateDynamicObject(19436, 336.475860, -1800.070434, 3.157740, 0.000000, 0.000000, 0.000000, -1, -1, -1, 300.00, 300.00);
	SetDynamicObjectMaterial(tmpobjid, 0, 10101, "2notherbuildsfe", "ws_rooftarmac1", 0x00000000);
	tmpobjid = CreateDynamicObject(19436, 336.475860, -1800.070434, 6.622670, 0.000000, 0.000000, 0.000000, -1, -1, -1, 300.00, 300.00);
	SetDynamicObjectMaterial(tmpobjid, 0, 10101, "2notherbuildsfe", "ws_rooftarmac1", 0x00000000);
	tmpobjid = CreateDynamicObject(19436, 316.197479, -1800.026733, 3.157740, 0.000000, 0.000000, 0.000000, -1, -1, -1, 300.00, 300.00);
	SetDynamicObjectMaterial(tmpobjid, 0, 10101, "2notherbuildsfe", "ws_rooftarmac1", 0x00000000);
	tmpobjid = CreateDynamicObject(19436, 316.191894, -1800.038330, 6.622670, 0.000000, 0.000000, 0.000000, -1, -1, -1, 300.00, 300.00);
	SetDynamicObjectMaterial(tmpobjid, 0, 10101, "2notherbuildsfe", "ws_rooftarmac1", 0x00000000);
	tmpobjid = CreateDynamicObject(19377, 321.134277, -1800.231811, 8.308670, 0.000000, 90.000000, 0.000000, -1, -1, -1, 300.00, 300.00);
	SetDynamicObjectMaterial(tmpobjid, 0, 9514, "711_sfw", "ws_carpark2", 0x00000000);
	tmpobjid = CreateDynamicObject(19377, 331.595947, -1800.248901, 8.308670, 0.000000, 90.000000, 0.000000, -1, -1, -1, 300.00, 300.00);
	SetDynamicObjectMaterial(tmpobjid, 0, 9514, "711_sfw", "ws_carpark2", 0x00000000);
	tmpobjid = CreateDynamicObject(19436, 316.955749, -1800.767089, 3.157700, 0.000000, 0.000000, 90.000000, -1, -1, -1, 300.00, 300.00);
	SetDynamicObjectMaterial(tmpobjid, 0, 10101, "2notherbuildsfe", "ws_rooftarmac1", 0x00000000);
	tmpobjid = CreateDynamicObject(19436, 317.011291, -1799.327392, 3.157700, 0.000000, 0.000000, 90.000000, -1, -1, -1, 300.00, 300.00);
	SetDynamicObjectMaterial(tmpobjid, 0, 10101, "2notherbuildsfe", "ws_rooftarmac1", 0x00000000);
	tmpobjid = CreateDynamicObject(19436, 317.719116, -1800.072021, 3.157740, 0.000000, 0.000000, 0.000000, -1, -1, -1, 300.00, 300.00);
	SetDynamicObjectMaterial(tmpobjid, 0, 10101, "2notherbuildsfe", "ws_rooftarmac1", 0x00000000);
	tmpobjid = CreateDynamicObject(19436, 317.016418, -1800.799682, 6.622700, 0.000000, 0.000000, 90.000000, -1, -1, -1, 300.00, 300.00);
	SetDynamicObjectMaterial(tmpobjid, 0, 10101, "2notherbuildsfe", "ws_rooftarmac1", 0x00000000);
	tmpobjid = CreateDynamicObject(19436, 317.006408, -1799.347778, 6.622700, 0.000000, 0.000000, 90.000000, -1, -1, -1, 300.00, 300.00);
	SetDynamicObjectMaterial(tmpobjid, 0, 10101, "2notherbuildsfe", "ws_rooftarmac1", 0x00000000);
	tmpobjid = CreateDynamicObject(19436, 317.713562, -1800.083496, 6.622670, 0.000000, 0.000000, 0.000000, -1, -1, -1, 300.00, 300.00);
	SetDynamicObjectMaterial(tmpobjid, 0, 10101, "2notherbuildsfe", "ws_rooftarmac1", 0x00000000);
	tmpobjid = CreateDynamicObject(19436, 335.742950, -1799.354248, 3.157700, 0.000000, 0.000000, 90.000000, -1, -1, -1, 300.00, 300.00);
	SetDynamicObjectMaterial(tmpobjid, 0, 10101, "2notherbuildsfe", "ws_rooftarmac1", 0x00000000);
	tmpobjid = CreateDynamicObject(19436, 335.785552, -1800.785156, 3.157700, 0.000000, 0.000000, 90.000000, -1, -1, -1, 300.00, 300.00);
	SetDynamicObjectMaterial(tmpobjid, 0, 10101, "2notherbuildsfe", "ws_rooftarmac1", 0x00000000);
	tmpobjid = CreateDynamicObject(19436, 335.030792, -1800.062377, 3.157740, 0.000000, 0.000000, 0.000000, -1, -1, -1, 300.00, 300.00);
	SetDynamicObjectMaterial(tmpobjid, 0, 10101, "2notherbuildsfe", "ws_rooftarmac1", 0x00000000);
	tmpobjid = CreateDynamicObject(19436, 335.737701, -1799.345947, 6.622700, 0.000000, 0.000000, 90.000000, -1, -1, -1, 300.00, 300.00);
	SetDynamicObjectMaterial(tmpobjid, 0, 10101, "2notherbuildsfe", "ws_rooftarmac1", 0x00000000);
	tmpobjid = CreateDynamicObject(19436, 335.727874, -1800.770751, 6.622700, 0.000000, 0.000000, 90.000000, -1, -1, -1, 300.00, 300.00);
	SetDynamicObjectMaterial(tmpobjid, 0, 10101, "2notherbuildsfe", "ws_rooftarmac1", 0x00000000);
	tmpobjid = CreateDynamicObject(19436, 335.033660, -1800.056884, 6.622670, 0.000000, 0.000000, 0.000000, -1, -1, -1, 300.00, 300.00);
	SetDynamicObjectMaterial(tmpobjid, 0, 10101, "2notherbuildsfe", "ws_rooftarmac1", 0x00000000);
	tmpobjid = CreateDynamicObject(19872, 345.870666, -1821.146606, 1.625800, 0.000000, 0.000000, 90.000000, -1, -1, -1, 300.00, 300.00);
	SetDynamicObjectMaterial(tmpobjid, 0, 10765, "airportgnd_sfse", "ws_yellowline", 0x00000000);
	tmpobjid = CreateDynamicObject(19872, 345.820281, -1825.565917, 1.625800, 0.000000, 0.000000, 90.000000, -1, -1, -1, 300.00, 300.00);
	SetDynamicObjectMaterial(tmpobjid, 0, 10765, "airportgnd_sfse", "ws_yellowline", 0x00000000);
	tmpobjid = CreateDynamicObject(19872, 322.463958, -1820.549194, 1.625800, 0.000000, 0.000000, 90.000000, -1, -1, -1, 300.00, 300.00);
	SetDynamicObjectMaterial(tmpobjid, 0, 10765, "airportgnd_sfse", "ws_yellowline", 0x00000000);
	tmpobjid = CreateDynamicObject(19872, 322.496063, -1826.733642, 1.625800, 0.000000, 0.000000, 90.000000, -1, -1, -1, 300.00, 300.00);
	SetDynamicObjectMaterial(tmpobjid, 0, 10765, "airportgnd_sfse", "ws_yellowline", 0x00000000);
	tmpobjid = CreateDynamicObject(19325, 323.719635, -1846.130493, 4.621500, 0.000000, 0.000000, 90.000000, -1, -1, -1, 300.00, 300.00);
	SetDynamicObjectMaterial(tmpobjid, 0, 11092, "burgalrystore_sfse", "ws_warehswin2", 0x00000000);
	tmpobjid = CreateDynamicObject(19325, 340.809234, -1817.444824, 6.238309, 0.000000, 0.000000, 90.000000, -1, -1, -1, 300.00, 300.00);
	SetDynamicObjectMaterial(tmpobjid, 0, 11092, "burgalrystore_sfse", "ws_warehswin2", 0x00000000);
	tmpobjid = CreateDynamicObject(19325, 327.485290, -1817.522216, 6.238309, 0.000000, 0.000000, 90.000000, -1, -1, -1, 300.00, 300.00);
	SetDynamicObjectMaterial(tmpobjid, 0, 11092, "burgalrystore_sfse", "ws_warehswin2", 0x00000000);
	tmpobjid = CreateDynamicObject(19325, 346.537780, -1817.469848, 6.238309, 0.000000, 0.000000, 90.000000, -1, -1, -1, 300.00, 300.00);
	SetDynamicObjectMaterial(tmpobjid, 0, 11092, "burgalrystore_sfse", "ws_warehswin2", 0x00000000);
	tmpobjid = CreateDynamicObject(19325, 349.841278, -1820.786987, 6.238299, 0.000000, 0.000000, 0.000000, -1, -1, -1, 300.00, 300.00);
	SetDynamicObjectMaterial(tmpobjid, 0, 11092, "burgalrystore_sfse", "ws_warehswin2", 0x00000000);
	tmpobjid = CreateDynamicObject(19325, 349.851257, -1827.358032, 6.238299, 0.000000, 0.000000, 0.000000, -1, -1, -1, 300.00, 300.00);
	SetDynamicObjectMaterial(tmpobjid, 0, 11092, "burgalrystore_sfse", "ws_warehswin2", 0x00000000);
	tmpobjid = CreateDynamicObject(19325, 349.877410, -1833.294433, 6.238299, 0.000000, 0.000000, 0.000000, -1, -1, -1, 300.00, 300.00);
	SetDynamicObjectMaterial(tmpobjid, 0, 11092, "burgalrystore_sfse", "ws_warehswin2", 0x00000000);
	tmpobjid = CreateDynamicObject(19325, 346.570709, -1836.630371, 6.238309, 0.000000, 0.000000, 90.000000, -1, -1, -1, 300.00, 300.00);
	SetDynamicObjectMaterial(tmpobjid, 0, 11092, "burgalrystore_sfse", "ws_warehswin2", 0x00000000);
	tmpobjid = CreateDynamicObject(19325, 339.990020, -1836.627197, 6.238309, 0.000000, 0.000000, 90.000000, -1, -1, -1, 300.00, 300.00);
	SetDynamicObjectMaterial(tmpobjid, 0, 11092, "burgalrystore_sfse", "ws_warehswin2", 0x00000000);
	tmpobjid = CreateDynamicObject(19325, 333.507476, -1836.614257, 6.238309, 0.000000, 0.000000, 90.000000, -1, -1, -1, 300.00, 300.00);
	SetDynamicObjectMaterial(tmpobjid, 0, 11092, "burgalrystore_sfse", "ws_warehswin2", 0x00000000);
	tmpobjid = CreateDynamicObject(19325, 332.274017, -1836.621459, 6.238309, 0.000000, 0.000000, 90.000000, -1, -1, -1, 300.00, 300.00);
	SetDynamicObjectMaterial(tmpobjid, 0, 11092, "burgalrystore_sfse", "ws_warehswin2", 0x00000000);
	tmpobjid = CreateDynamicObject(19325, 321.913787, -1817.551879, 6.238309, 0.000000, 0.000000, 90.000000, -1, -1, -1, 300.00, 300.00);
	SetDynamicObjectMaterial(tmpobjid, 0, 11092, "burgalrystore_sfse", "ws_warehswin2", 0x00000000);
	tmpobjid = CreateDynamicObject(19325, 318.627593, -1820.864257, 6.238299, 0.000000, 0.000000, 0.000000, -1, -1, -1, 300.00, 300.00);
	SetDynamicObjectMaterial(tmpobjid, 0, 11092, "burgalrystore_sfse", "ws_warehswin2", 0x00000000);
	tmpobjid = CreateDynamicObject(19325, 318.622283, -1827.409179, 6.238299, 0.000000, 0.000000, 0.000000, -1, -1, -1, 300.00, 300.00);
	SetDynamicObjectMaterial(tmpobjid, 0, 11092, "burgalrystore_sfse", "ws_warehswin2", 0x00000000);
	tmpobjid = CreateDynamicObject(19325, 318.621398, -1833.355712, 6.238299, 0.000000, 0.000000, 0.000000, -1, -1, -1, 300.00, 300.00);
	SetDynamicObjectMaterial(tmpobjid, 0, 11092, "burgalrystore_sfse", "ws_warehswin2", 0x00000000);
	tmpobjid = CreateDynamicObject(19377, 323.855346, -1831.845336, 8.229860, 0.000000, 90.000000, 0.000000, -1, -1, -1, 300.00, 300.00);
	SetDynamicObjectMaterial(tmpobjid, 0, 9514, "711_sfw", "ws_carpark2", 0x00000000);
	tmpobjid = CreateDynamicObject(19377, 334.264648, -1831.845214, 8.229860, 0.000000, 90.000000, 0.000000, -1, -1, -1, 300.00, 300.00);
	SetDynamicObjectMaterial(tmpobjid, 0, 9514, "711_sfw", "ws_carpark2", 0x00000000);
	tmpobjid = CreateDynamicObject(19377, 344.672698, -1831.825195, 8.229860, 0.000000, 90.000000, 0.000000, -1, -1, -1, 300.00, 300.00);
	SetDynamicObjectMaterial(tmpobjid, 0, 9514, "711_sfw", "ws_carpark2", 0x00000000);
	tmpobjid = CreateDynamicObject(19377, 344.685485, -1822.265380, 8.229860, 0.000000, 90.000000, 0.000000, -1, -1, -1, 300.00, 300.00);
	SetDynamicObjectMaterial(tmpobjid, 0, 9514, "711_sfw", "ws_carpark2", 0x00000000);
	tmpobjid = CreateDynamicObject(19377, 334.310546, -1822.273315, 8.229860, 0.000000, 90.000000, 0.000000, -1, -1, -1, 300.00, 300.00);
	SetDynamicObjectMaterial(tmpobjid, 0, 9514, "711_sfw", "ws_carpark2", 0x00000000);
	tmpobjid = CreateDynamicObject(19377, 323.831085, -1822.255371, 8.229860, 0.000000, 90.000000, 0.000000, -1, -1, -1, 300.00, 300.00);
	SetDynamicObjectMaterial(tmpobjid, 0, 9514, "711_sfw", "ws_carpark2", 0x00000000);
	tmpobjid = CreateDynamicObject(19377, 323.849578, -1841.333007, 6.654799, 0.000000, 90.000000, 0.000000, -1, -1, -1, 300.00, 300.00);
	SetDynamicObjectMaterial(tmpobjid, 0, 9514, "711_sfw", "ws_carpark2", 0x00000000);
	tmpobjid = CreateDynamicObject(19325, 321.951324, -1838.610839, 7.487269, 0.000000, 70.000000, 90.000000, -1, -1, -1, 300.00, 300.00);
	SetDynamicObjectMaterial(tmpobjid, 0, 11092, "burgalrystore_sfse", "ws_warehswin2", 0x00000000);
	tmpobjid = CreateDynamicObject(19325, 325.761718, -1838.630493, 7.487269, 0.000000, 70.000000, 90.000000, -1, -1, -1, 300.00, 300.00);
	SetDynamicObjectMaterial(tmpobjid, 0, 11092, "burgalrystore_sfse", "ws_warehswin2", 0x00000000);
	tmpobjid = CreateDynamicObject(19456, 325.945831, -1836.604003, 4.973869, 0.000000, 0.000000, 90.000000, -1, -1, -1, 300.00, 300.00);
	SetDynamicObjectMaterial(tmpobjid, 0, 10101, "2notherbuildsfe", "sl_vicwall02", 0x00000000);
	tmpobjid = CreateDynamicObject(19437, 318.692962, -1837.286254, 6.416299, 0.000000, 0.000000, 0.000000, -1, -1, -1, 300.00, 300.00);
	SetDynamicObjectMaterial(tmpobjid, 0, 10101, "2notherbuildsfe", "sl_vicwall02", 0x00000000);
	tmpobjid = CreateDynamicObject(19437, 318.671844, -1838.780151, 5.946630, 0.000000, 0.000000, 0.000000, -1, -1, -1, 300.00, 300.00);
	SetDynamicObjectMaterial(tmpobjid, 0, 10101, "2notherbuildsfe", "sl_vicwall02", 0x00000000);
	tmpobjid = CreateDynamicObject(19437, 318.661254, -1840.202270, 5.440820, 0.000000, 0.000000, 0.000000, -1, -1, -1, 300.00, 300.00);
	SetDynamicObjectMaterial(tmpobjid, 0, 10101, "2notherbuildsfe", "sl_vicwall02", 0x00000000);
	tmpobjid = CreateDynamicObject(19437, 329.001342, -1837.399047, 6.416299, 0.000000, 0.000000, 0.000000, -1, -1, -1, 300.00, 300.00);
	SetDynamicObjectMaterial(tmpobjid, 0, 10101, "2notherbuildsfe", "sl_vicwall02", 0x00000000);
	tmpobjid = CreateDynamicObject(19437, 329.007873, -1838.942138, 5.946630, 0.000000, 0.000000, 0.000000, -1, -1, -1, 300.00, 300.00);
	SetDynamicObjectMaterial(tmpobjid, 0, 10101, "2notherbuildsfe", "sl_vicwall02", 0x00000000);
	tmpobjid = CreateDynamicObject(19437, 329.000793, -1840.053710, 5.440820, 0.000000, 0.000000, 0.000000, -1, -1, -1, 300.00, 300.00);
	SetDynamicObjectMaterial(tmpobjid, 0, 10101, "2notherbuildsfe", "sl_vicwall02", 0x00000000);
	tmpobjid = CreateDynamicObject(19462, 328.938201, -1841.336547, 4.964409, 0.000000, 0.000000, 0.000000, -1, -1, -1, 300.00, 300.00);
	SetDynamicObjectMaterial(tmpobjid, 0, 14652, "ab_trukstpa", "CJ_WOOD6", 0x00000000);
	tmpobjid = CreateDynamicObject(19462, 325.970428, -1836.659423, 4.985879, 0.000000, 0.000000, 90.000000, -1, -1, -1, 300.00, 300.00);
	SetDynamicObjectMaterial(tmpobjid, 0, 14652, "ab_trukstpa", "CJ_WOOD6", 0x00000000);
	tmpobjid = CreateDynamicObject(19462, 318.733703, -1841.370117, 4.939539, 0.000000, 0.000000, 0.000000, -1, -1, -1, 300.00, 300.00);
	SetDynamicObjectMaterial(tmpobjid, 0, 14652, "ab_trukstpa", "CJ_WOOD6", 0x00000000);
	tmpobjid = CreateDynamicObject(19437, 329.959747, -1836.659179, 4.995709, 0.000000, 0.000000, 90.000000, -1, -1, -1, 300.00, 300.00);
	SetDynamicObjectMaterial(tmpobjid, 0, 10101, "2notherbuildsfe", "sl_vicwall02", 0x00000000);
	tmpobjid = CreateDynamicObject(19437, 329.699951, -1836.651000, 4.995709, 0.000000, 0.000000, 90.000000, -1, -1, -1, 300.00, 300.00);
	SetDynamicObjectMaterial(tmpobjid, 0, 10101, "2notherbuildsfe", "sl_vicwall02", 0x00000000);
	tmpobjid = CreateDynamicObject(19370, 327.481811, -1846.076782, 4.841330, 0.000000, 0.000000, 90.000000, -1, -1, -1, 300.00, 300.00);
	SetDynamicObjectMaterial(tmpobjid, 0, 14652, "ab_trukstpa", "CJ_WOOD6", 0x00000000);
	tmpobjid = CreateDynamicObject(19370, 320.261505, -1846.062133, 4.841330, 0.000000, 0.000000, 90.000000, -1, -1, -1, 300.00, 300.00);
	SetDynamicObjectMaterial(tmpobjid, 0, 14652, "ab_trukstpa", "CJ_WOOD6", 0x00000000);
	tmpobjid = CreateDynamicObject(19390, 320.383392, -1836.639038, 4.964489, 0.000000, 0.000000, 90.000000, -1, -1, -1, 300.00, 300.00);
	SetDynamicObjectMaterial(tmpobjid, 0, 14652, "ab_trukstpa", "CJ_WOOD6", 0x00000000);
	tmpobjid = CreateDynamicObject(2207, 325.266204, -1840.591308, 3.467000, 0.000000, 0.000000, -90.000000, -1, -1, -1, 300.00, 300.00);
	SetDynamicObjectMaterial(tmpobjid, 0, 10765, "airportgnd_sfse", "ws_yellowline", 0x00000000);
	tmpobjid = CreateDynamicObject(19325, 346.507995, -1828.570922, 6.238309, 0.000000, 0.000000, 90.000000, -1, -1, -1, 300.00, 300.00);
	SetDynamicObjectMaterial(tmpobjid, 0, 11092, "burgalrystore_sfse", "ws_warehswin2", 0x00000000);
	tmpobjid = CreateDynamicObject(19325, 343.568054, -1828.586914, 6.238309, 0.000000, 0.000000, 90.000000, -1, -1, -1, 300.00, 300.00);
	SetDynamicObjectMaterial(tmpobjid, 0, 11092, "burgalrystore_sfse", "ws_warehswin2", 0x00000000);
	tmpobjid = CreateDynamicObject(19437, 340.963165, -1828.598266, 3.841419, 0.000000, 0.000000, 90.000000, -1, -1, -1, 300.00, 300.00);
	SetDynamicObjectMaterial(tmpobjid, 0, 10101, "2notherbuildsfe", "sl_vicwall02", 0x00000000);
	tmpobjid = CreateDynamicObject(19437, 342.537445, -1828.603759, 3.825850, 0.000000, 0.000000, 90.000000, -1, -1, -1, 300.00, 300.00);
	SetDynamicObjectMaterial(tmpobjid, 0, 10101, "2notherbuildsfe", "sl_vicwall02", 0x00000000);
	tmpobjid = CreateDynamicObject(19456, 344.927612, -1828.589355, 2.478179, 0.000000, 0.000000, 90.000000, -1, -1, -1, 300.00, 300.00);
	SetDynamicObjectMaterial(tmpobjid, 0, 10101, "2notherbuildsfe", "sl_vicwall02", 0x00000000);
	tmpobjid = CreateDynamicObject(19456, 333.875976, -1836.666503, 4.973000, 0.000000, 0.000000, 90.000000, -1, -1, -1, 300.00, 300.00);
	SetDynamicObjectMaterial(tmpobjid, 0, 10101, "2notherbuildsfe", "sl_vicwall02", 0x00000000);
	tmpobjid = CreateDynamicObject(19456, 343.516174, -1836.666503, 4.973000, 0.000000, 0.000000, 90.000000, -1, -1, -1, 300.00, 300.00);
	SetDynamicObjectMaterial(tmpobjid, 0, 10101, "2notherbuildsfe", "sl_vicwall02", 0x00000000);
	tmpobjid = CreateDynamicObject(19456, 345.106201, -1836.656494, 4.973000, 0.000000, 0.000000, 90.000000, -1, -1, -1, 300.00, 300.00);
	SetDynamicObjectMaterial(tmpobjid, 0, 10101, "2notherbuildsfe", "sl_vicwall02", 0x00000000);
	tmpobjid = CreateDynamicObject(19377, 334.278411, -1822.222045, 3.304260, 0.000000, 90.000000, 0.000000, -1, -1, -1, 300.00, 300.00);
	SetDynamicObjectMaterial(tmpobjid, 0, 9514, "711_sfw", "ws_carpark2", 0x00000000);
	tmpobjid = CreateDynamicObject(19442, 326.511047, -1817.515991, 4.130676, 0.000020, -1.400031, 90.200035, -1, -1, -1, 300.00, 300.00);
	SetDynamicObjectMaterialText(tmpobjid, 0, "{FFFFFF}Workshop CPX", 90, "Quartz MS", 20, 1, 0x00000000, 0x00000000, 0);
	/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	tmpobjid = CreateDynamicObject(9192, 338.982208, -1778.618652, 8.510990, 0.000000, 0.000000, 42.720001, -1, -1, -1, 300.00, 300.00);
	tmpobjid = CreateDynamicObject(3578, 331.329620, -1800.125732, 2.939229, 0.000000, 0.000000, 0.000000, -1, -1, -1, 300.00, 300.00);
	tmpobjid = CreateDynamicObject(3578, 321.347991, -1800.119506, 2.939229, 0.000000, 0.000000, 0.000000, -1, -1, -1, 300.00, 300.00);
	tmpobjid = CreateDynamicObject(8674, 331.359039, -1799.303588, 2.880110, 0.000000, 0.000000, 0.000000, -1, -1, -1, 300.00, 300.00);
	tmpobjid = CreateDynamicObject(8674, 321.330780, -1799.323730, 2.880110, 0.000000, 0.000000, 0.000000, -1, -1, -1, 300.00, 300.00);
	tmpobjid = CreateDynamicObject(8674, 321.373809, -1800.852661, 2.880110, 0.000000, 0.000000, 0.000000, -1, -1, -1, 300.00, 300.00);
	tmpobjid = CreateDynamicObject(8674, 331.280395, -1800.861572, 2.880110, 0.000000, 0.000000, 0.000000, -1, -1, -1, 300.00, 300.00);
	tmpobjid = CreateDynamicObject(3578, 334.187133, -1812.524414, 2.655430, 0.000000, 0.000000, 0.000000, -1, -1, -1, 300.00, 300.00);
	tmpobjid = CreateDynamicObject(1364, 356.277069, -1816.580566, 4.128590, 0.000000, 0.000000, 180.000000, -1, -1, -1, 300.00, 300.00);
	tmpobjid = CreateDynamicObject(1364, 311.458831, -1816.523925, 4.128590, 0.000000, 0.000000, 180.000000, -1, -1, -1, 300.00, 300.00);
	tmpobjid = CreateDynamicObject(1361, 345.283966, -1816.505249, 3.297660, 0.000000, 0.000000, 0.000000, -1, -1, -1, 300.00, 300.00);
	tmpobjid = CreateDynamicObject(1361, 323.855346, -1816.542236, 3.297660, 0.000000, 0.000000, 0.000000, -1, -1, -1, 300.00, 300.00);
	tmpobjid = CreateDynamicObject(1361, 328.045593, -1816.418823, 3.297660, 0.000000, 0.000000, 0.000000, -1, -1, -1, 300.00, 300.00);
	tmpobjid = CreateDynamicObject(1361, 340.964050, -1816.647094, 3.297660, 0.000000, 0.000000, 0.000000, -1, -1, -1, 300.00, 300.00);
	tmpobjid = CreateDynamicObject(19125, 359.848571, -1785.810546, 4.719880, 0.000000, 0.000000, 0.000000, -1, -1, -1, 300.00, 300.00);
	tmpobjid = CreateDynamicObject(19125, 340.088836, -1786.053344, 4.492899, 0.000000, 0.000000, 0.000000, -1, -1, -1, 300.00, 300.00);
	tmpobjid = CreateDynamicObject(19903, 345.183227, -1818.462402, 3.386090, 0.000000, 0.000000, -145.800003, -1, -1, -1, 300.00, 300.00);
	tmpobjid = CreateDynamicObject(19815, 349.751739, -1832.092163, 4.944399, 0.000000, 0.000000, -90.000000, -1, -1, -1, 300.00, 300.00);
	tmpobjid = CreateDynamicObject(19815, 341.756072, -1828.511352, 4.944399, 0.000000, 0.000000, 180.000000, -1, -1, -1, 300.00, 300.00);
	tmpobjid = CreateDynamicObject(19815, 349.794250, -1820.924194, 4.944399, 0.000000, 0.000000, -90.000000, -1, -1, -1, 300.00, 300.00);
	tmpobjid = CreateDynamicObject(19899, 349.259124, -1832.090820, 4.305469, 180.000000, 0.000000, 180.000000, -1, -1, -1, 300.00, 300.00);
	tmpobjid = CreateDynamicObject(19900, 341.263061, -1835.916748, 3.348700, 0.000000, 0.000000, -34.319988, -1, -1, -1, 300.00, 300.00);
	tmpobjid = CreateDynamicObject(19900, 340.389526, -1836.182617, 3.348700, 0.000000, 0.000000, 6.420000, -1, -1, -1, 300.00, 300.00);
	tmpobjid = CreateDynamicObject(19903, 344.314788, -1829.366088, 3.386090, 0.000000, 0.000000, -145.800003, -1, -1, -1, 300.00, 300.00);
	tmpobjid = CreateDynamicObject(19900, 349.027557, -1835.236328, 3.388020, 0.000000, 0.000000, -11.100000, -1, -1, -1, 300.00, 300.00);
	tmpobjid = CreateDynamicObject(19900, 349.046569, -1835.242553, 4.283870, 0.000000, 0.000000, -11.100000, -1, -1, -1, 300.00, 300.00);
	tmpobjid = CreateDynamicObject(11745, 348.369567, -1835.893432, 3.535650, 0.000000, 0.000000, -29.639999, -1, -1, -1, 300.00, 300.00);
	tmpobjid = CreateDynamicObject(19816, 348.407165, -1836.274414, 3.598710, 0.000000, 0.000000, 0.000000, -1, -1, -1, 300.00, 300.00);
	tmpobjid = CreateDynamicObject(2048, 344.733886, -1836.456298, 5.350500, 0.000000, 0.000000, 180.000000, -1, -1, -1, 300.00, 300.00);
	tmpobjid = CreateDynamicObject(19900, 349.198852, -1827.909912, 3.348700, 0.000000, 0.000000, -34.319988, -1, -1, -1, 300.00, 300.00);
	tmpobjid = CreateDynamicObject(19900, 349.198852, -1827.909912, 4.169859, 0.000000, 0.000000, -34.319988, -1, -1, -1, 300.00, 300.00);
	tmpobjid = CreateDynamicObject(19815, 318.835052, -1823.992065, 4.944399, 0.000000, 0.000000, 90.000000, -1, -1, -1, 300.00, 300.00);
	tmpobjid = CreateDynamicObject(19903, 320.600952, -1829.244506, 3.386090, 0.000000, 0.000000, 31.260000, -1, -1, -1, 300.00, 300.00);
	tmpobjid = CreateDynamicObject(2048, 324.107574, -1836.470092, 5.215439, 0.000000, 0.000000, 180.000000, -1, -1, -1, 300.00, 300.00);
	tmpobjid = CreateDynamicObject(3437, 338.996826, -1778.608764, 0.202099, 180.000000, 0.000000, -44.279998, -1, -1, -1, 300.00, 300.00);
	tmpobjid = CreateDynamicObject(19900, 322.525115, -1823.496459, 3.348700, 0.000000, 0.000000, -89.939956, -1, -1, -1, 300.00, 300.00);
	tmpobjid = CreateDynamicObject(2485, 325.927642, -1840.532592, 4.277800, 0.000000, 0.000000, 0.000000, -1, -1, -1, 300.00, 300.00);
	tmpobjid = CreateDynamicObject(1663, 324.128753, -1840.428344, 3.916019, 0.000000, 0.000000, 61.560001, -1, -1, -1, 300.00, 300.00);
	tmpobjid = CreateDynamicObject(1663, 324.259002, -1842.670410, 3.916019, 0.000000, 0.000000, 109.620002, -1, -1, -1, 300.00, 300.00);
	tmpobjid = CreateDynamicObject(1714, 327.104827, -1841.588500, 3.471400, 0.000000, 0.000000, -80.400001, -1, -1, -1, 300.00, 300.00);
	tmpobjid = CreateDynamicObject(14455, 328.838531, -1842.156616, 4.861889, 0.000000, 0.000000, 90.000000, -1, -1, -1, 300.00, 300.00);
	tmpobjid = CreateDynamicObject(14455, 328.858978, -1845.052368, 4.861889, 0.000000, 0.000000, 90.000000, -1, -1, -1, 300.00, 300.00);
	tmpobjid = CreateDynamicObject(2894, 325.778381, -1842.346923, 4.243080, 0.000000, 0.000000, 118.139968, -1, -1, -1, 300.00, 300.00);
	tmpobjid = CreateDynamicObject(19787, 318.761474, -1841.799560, 5.665279, 0.000000, 0.000000, 90.000000, -1, -1, -1, 300.00, 300.00);
	tmpobjid = CreateDynamicObject(19808, 325.478668, -1841.420532, 4.241320, 0.000000, 0.000000, 78.900001, -1, -1, -1, 300.00, 300.00);
	tmpobjid = CreateDynamicObject(2246, 319.260589, -1837.150390, 3.842849, 0.000000, 0.000000, 0.000000, -1, -1, -1, 300.00, 300.00);
	tmpobjid = CreateDynamicObject(862, 319.252716, -1837.149414, 4.167389, 0.000000, 0.000000, 122.760009, -1, -1, -1, 300.00, 300.00);
	tmpobjid = CreateDynamicObject(19825, 318.894378, -1843.843994, 5.499000, 0.000000, 0.000000, 90.000000, -1, -1, -1, 300.00, 300.00);
	tmpobjid = CreateDynamicObject(19825, 326.297729, -1817.763549, 5.338769, 0.000000, 0.000000, 0.000000, -1, -1, -1, 300.00, 300.00);
	tmpobjid = CreateDynamicObject(19621, 322.615447, -1823.406738, 4.318369, 0.000000, 0.000000, 58.439990, -1, -1, -1, 300.00, 300.00);
	tmpobjid = CreateDynamicObject(19621, 322.455505, -1823.586669, 4.318369, 0.000000, 0.000000, -62.820011, -1, -1, -1, 300.00, 300.00);
	tmpobjid = CreateDynamicObject(19627, 322.614685, -1823.696899, 4.222420, 0.000000, 0.000000, 0.000000, -1, -1, -1, 300.00, 300.00);
	tmpobjid = CreateDynamicObject(19627, 322.614593, -1823.597045, 4.222420, 0.000000, 0.000000, 0.000000, -1, -1, -1, 300.00, 300.00);
	tmpobjid = CreateDynamicObject(19627, 322.402374, -1823.313476, 4.222420, 0.000000, 0.000000, 22.200000, -1, -1, -1, 300.00, 300.00);
	tmpobjid = CreateDynamicObject(19627, 349.153350, -1827.726318, 5.044370, 0.000000, 0.000000, 0.000000, -1, -1, -1, 300.00, 300.00);
	tmpobjid = CreateDynamicObject(19627, 349.055664, -1827.918212, 5.044370, 0.000000, 0.000000, -43.500000, -1, -1, -1, 300.00, 300.00);
	tmpobjid = CreateDynamicObject(19627, 349.283325, -1827.904663, 5.044370, 0.000000, 0.000000, -138.240020, -1, -1, -1, 300.00, 300.00);
	tmpobjid = CreateDynamicObject(19621, 349.074127, -1831.026123, 4.382329, 0.000000, 0.000000, -45.840000, -1, -1, -1, 300.00, 300.00);
	tmpobjid = CreateDynamicObject(19472, 349.095001, -1832.712280, 4.358630, -192.419876, 160.139831, -0.300000, -1, -1, -1, 300.00, 300.00);
	tmpobjid = CreateDynamicObject(19472, 349.024932, -1832.899536, 4.377359, -192.419876, 160.139831, -46.139999, -1, -1, -1, 300.00, 300.00);
	tmpobjid = CreateDynamicObject(19472, 349.067352, -1832.300781, 4.377359, -192.419876, 160.139831, 58.979999, -1, -1, -1, 300.00, 300.00);
	tmpobjid = CreateDynamicObject(1753, 319.330413, -1844.903564, 3.466300, 0.000000, 0.000000, 90.000000, -1, -1, -1, 300.00, 300.00);
	tmpobjid = CreateDynamicObject(1753, 319.089996, -1840.673583, 3.466300, 0.000000, 0.000000, 90.000000, -1, -1, -1, 300.00, 300.00);
	tmpobjid = CreateDynamicObject(1893, 334.048492, -1818.308227, 8.410201, 0.000000, 0.000000, 0.000000, -1, -1, -1, 300.00, 300.00);
	tmpobjid = CreateDynamicObject(1893, 334.048492, -1822.068115, 8.410201, 0.000000, 0.000000, 0.000000, -1, -1, -1, 300.00, 300.00);
	tmpobjid = CreateDynamicObject(1893, 334.048492, -1826.699218, 8.410201, 0.000000, 0.000000, 0.000000, -1, -1, -1, 300.00, 300.00);
	tmpobjid = CreateDynamicObject(1893, 334.048492, -1832.229736, 8.430212, 0.000000, 0.000000, 0.000000, -1, -1, -1, 300.00, 300.00);
	tmpobjid = CreateDynamicObject(1893, 343.948425, -1832.229736, 8.430212, 0.000000, 0.000000, 0.000000, -1, -1, -1, 300.00, 300.00);
	tmpobjid = CreateDynamicObject(1893, 343.948425, -1822.569702, 8.430212, 0.000000, 0.000000, 0.000000, -1, -1, -1, 300.00, 300.00);
	tmpobjid = CreateDynamicObject(1893, 324.158325, -1822.569702, 8.430212, 0.000000, 0.000000, 0.000000, -1, -1, -1, 300.00, 300.00);
	tmpobjid = CreateDynamicObject(1893, 324.158325, -1831.660644, 8.430212, 0.000000, 0.000000, 0.000000, -1, -1, -1, 300.00, 300.00);
	tmpobjid = CreateDynamicObject(1893, 324.293884, -1841.880371, 6.600212, 0.000000, 0.000000, 28.500001, -1, -1, -1, 300.00, 300.00);
	CreateDynamicObject(970, 310.6949, -1786.0683, 4.1111, 0.0000, -0.6999, 0.0000); //fencesmallb
	CreateDynamicObject(970, 314.8548, -1786.0683, 4.1619, 0.0000, -0.6999, 0.0000); //fencesmallb
	CreateDynamicObject(970, 319.0049, -1786.0683, 4.2126, 0.0000, -0.6999, 0.0000); //fencesmallb
	CreateDynamicObject(970, 323.1648, -1786.0683, 4.2634, 0.0000, -0.6999, 0.0000); //fencesmallb
	CreateDynamicObject(970, 327.3246, -1786.0683, 4.3142, 0.0000, -0.6999, 0.0000); //fencesmallb
	CreateDynamicObject(970, 331.4949, -1786.0683, 4.3652, 0.0000, -0.6999, 0.0000); //fencesmallb
	CreateDynamicObject(970, 335.6447, -1786.0683, 4.4159, 0.0000, -0.6999, 0.0000); //fencesmallb
	CreateDynamicObject(970, 337.7345, -1786.0683, 4.4414, 0.0000, -0.6999, 0.0000); //fencesmallb
	CreateDynamicObject(970, 308.3601, -1815.2924, 3.8671, 0.0000, -1.2000, 89.1999); //fencesmallb
	CreateDynamicObject(970, 308.4083, -1811.1431, 3.9312, 0.0000, -0.5000, 89.3999); //fencesmallb
	CreateDynamicObject(970, 308.4211, -1807.0223, 3.9572, 0.0000, -0.2000, 90.1999); //fencesmallb
	CreateDynamicObject(970, 308.4067, -1802.9116, 3.9715, 0.0000, -0.2000, 90.1999); //fencesmallb
	CreateDynamicObject(970, 308.3924, -1798.7822, 3.9860, 0.0000, -0.2000, 90.1999); //fencesmallb
	CreateDynamicObject(970, 308.3983, -1794.6501, 4.0004, 0.0000, -0.2000, 89.7999); //fencesmallb
	CreateDynamicObject(970, 308.4121, -1790.5272, 4.0147, 0.0000, -0.2000, 89.7999); //fencesmallb
	CreateDynamicObject(970, 308.4192, -1788.4364, 4.0220, 0.0000, -0.2000, 89.7999); //fencesmallb
	CreateDynamicObject(970, 356.1022, -1817.3867, 3.8210, 0.0000, 0.0000, 0.0000); //fencesmallb
	CreateDynamicObject(970, 351.9821, -1817.3867, 3.8210, 0.0000, 0.0000, 0.0000); //fencesmallb
	CreateDynamicObject(970, 357.8523, -1817.3867, 3.8210, 0.0000, 0.0000, 0.0000); //fencesmallb
	CreateDynamicObject(970, 310.3908, -1817.3631, 3.8351, 0.0000, 0.0000, 0.0000); //fencesmallb
	CreateDynamicObject(970, 314.4820, -1817.3631, 3.8351, 0.0000, 0.0000, 0.0000); //fencesmallb
	CreateDynamicObject(970, 316.5624, -1817.3631, 3.8351, 0.0000, 0.0000, 0.0000); //fencesmallb
	CreateDynamicObject(970, 360.0289, -1788.0593, 4.8067, 0.0000, -3.3999, 93.7000); //fencesmallb
	CreateDynamicObject(970, 360.2958, -1792.1934, 4.5806, 0.0000, -2.7999, 93.7000); //fencesmallb
	CreateDynamicObject(970, 360.5616, -1796.3137, 4.4188, 0.0000, -1.7000, 93.7000); //fencesmallb
	CreateDynamicObject(970, 360.8278, -1800.4333, 4.2963, 0.0000, -1.7000, 93.7000); //fencesmallb
	CreateDynamicObject(19124, 308.4294, -1786.1785, 4.1803, 0.0000, 0.0000, 0.0000); //BollardLight4
	CreateDynamicObject(12957, 354.9923, -1822.1623, 3.8439, 0.0000, 0.0000, -129.3000); //sw_pickupwreck01
	CreateDynamicObject(11313, 334.1830, -1819.4780, 7.5363, 0.0000, -79.3998, -89.3999); //modshopdoor_SFSe
	CreateDynamicObject(1074, 346.9928, -1817.3500, 5.2654, 0.0000, 0.0000, 86.1998); //wheel_sr3
	CreateDynamicObject(1074, 343.1409, -1817.1007, 5.2654, 0.0000, 0.0000, 86.1998); //wheel_sr3
	CreateDynamicObject(1080, 323.0997, -1817.3416, 5.2211, 0.0000, 0.0000, 90.1000); //wheel_sr5

}