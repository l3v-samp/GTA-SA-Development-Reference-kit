#include <YSI\y_hooks>

hook OnGameModeInit()
{
	new tmpobjid;
	tmpobjid = CreateDynamicObject(19463, 849.531311, 880.812011, 13.040583, 0.399999, 0.000000, 115.099998, 0, 0, -1, 300.00, 300.00); 
	SetDynamicObjectMaterial(tmpobjid, 0, 3922, "bistro", "sw_wallbrick_01", 0x00000000);
	tmpobjid = CreateDynamicObject(19463, 840.810852, 876.727539, 13.107812, 0.399999, 0.000000, 115.099998, 0, 0, -1, 300.00, 300.00); 
	SetDynamicObjectMaterial(tmpobjid, 0, 3922, "bistro", "sw_wallbrick_01", 0x00000000);
	tmpobjid = CreateDynamicObject(19463, 834.526184, 873.783386, 13.156262, 0.399999, 0.000000, 115.099998, 0, 0, -1, 300.00, 300.00); 
	SetDynamicObjectMaterial(tmpobjid, 0, 3922, "bistro", "sw_wallbrick_01", 0x00000000);
	tmpobjid = CreateDynamicObject(19463, 828.181152, 876.156555, 13.163172, 0.399999, 0.000000, 205.100006, 0, 0, -1, 300.00, 300.00); 
	SetDynamicObjectMaterial(tmpobjid, 0, 3922, "bistro", "sw_wallbrick_01", 0x00000000);
	tmpobjid = CreateDynamicObject(19463, 824.096313, 884.877075, 13.095940, 0.399999, 0.000000, 205.100006, 0, 0, -1, 300.00, 300.00); 
	SetDynamicObjectMaterial(tmpobjid, 0, 3922, "bistro", "sw_wallbrick_01", 0x00000000);
	tmpobjid = CreateDynamicObject(19463, 820.011474, 893.597717, 13.028709, 0.399999, 0.000000, 205.100006, 0, 0, -1, 300.00, 300.00); 
	SetDynamicObjectMaterial(tmpobjid, 0, 3922, "bistro", "sw_wallbrick_01", 0x00000000);
	tmpobjid = CreateDynamicObject(19463, 817.781677, 898.360534, 12.991994, 0.399999, 0.000000, 205.100006, 0, 0, -1, 300.00, 300.00); 
	SetDynamicObjectMaterial(tmpobjid, 0, 3922, "bistro", "sw_wallbrick_01", 0x00000000);
	tmpobjid = CreateDynamicObject(19463, 820.218322, 904.736450, 12.986271, 0.399999, 0.000000, 295.100006, 0, 0, -1, 300.00, 300.00); 
	SetDynamicObjectMaterial(tmpobjid, 0, 3922, "bistro", "sw_wallbrick_01", 0x00000000);
	tmpobjid = CreateDynamicObject(19463, 828.929809, 908.817260, 13.053436, 0.399999, 0.000000, 295.100006, 0, 0, -1, 300.00, 300.00); 
	SetDynamicObjectMaterial(tmpobjid, 0, 3922, "bistro", "sw_wallbrick_01", 0x00000000);
	tmpobjid = CreateDynamicObject(19463, 837.615539, 912.952026, 13.120594, 0.399999, 0.000000, -64.199989, 0, 0, -1, 300.00, 300.00); 
	SetDynamicObjectMaterial(tmpobjid, 0, 3922, "bistro", "sw_wallbrick_01", 0x00000000);
	tmpobjid = CreateDynamicObject(19463, 846.276550, 917.139160, 13.187753, 0.399999, 0.000000, -64.199989, 0, 0, -1, 300.00, 300.00); 
	SetDynamicObjectMaterial(tmpobjid, 0, 3922, "bistro", "sw_wallbrick_01", 0x00000000);
	tmpobjid = CreateDynamicObject(19463, 854.978759, 921.235290, 13.254920, 0.399999, 0.000000, -65.399978, 0, 0, -1, 300.00, 300.00); 
	SetDynamicObjectMaterial(tmpobjid, 0, 3922, "bistro", "sw_wallbrick_01", 0x00000000);
	tmpobjid = CreateDynamicObject(19463, 863.082824, 924.844177, 13.318221, 0.299999, 0.000000, -66.599960, 0, 0, -1, 300.00, 300.00); 
	SetDynamicObjectMaterial(tmpobjid, 0, 3922, "bistro", "sw_wallbrick_01", 0x00000000);
	tmpobjid = CreateDynamicObject(19463, 869.506774, 922.299011, 13.312617, 0.299999, 0.000000, 25.200044, 0, 0, -1, 300.00, 300.00); 
	SetDynamicObjectMaterial(tmpobjid, 0, 3922, "bistro", "sw_wallbrick_01", 0x00000000);
	tmpobjid = CreateDynamicObject(19463, 873.606872, 913.585449, 13.262199, 0.299999, 0.000000, 25.200044, 0, 0, -1, 300.00, 300.00); 
	SetDynamicObjectMaterial(tmpobjid, 0, 3922, "bistro", "sw_wallbrick_01", 0x00000000);
	tmpobjid = CreateDynamicObject(19463, 877.702758, 904.881103, 13.211832, 0.299999, 0.000000, 25.200044, 0, 0, -1, 300.00, 300.00); 
	SetDynamicObjectMaterial(tmpobjid, 0, 3922, "bistro", "sw_wallbrick_01", 0x00000000);
	tmpobjid = CreateDynamicObject(19463, 879.942810, 900.122253, 13.184287, 0.299999, 0.000000, 25.200044, 0, 0, -1, 300.00, 300.00); 
	SetDynamicObjectMaterial(tmpobjid, 0, 3922, "bistro", "sw_wallbrick_01", 0x00000000);
	tmpobjid = CreateDynamicObject(19463, 877.585144, 894.011474, 13.199110, 0.299999, 0.000000, 112.700027, 0, 0, -1, 300.00, 300.00); 
	SetDynamicObjectMaterial(tmpobjid, 0, 3922, "bistro", "sw_wallbrick_01", 0x00000000);
	tmpobjid = CreateDynamicObject(19463, 868.845886, 890.057067, 13.249370, 0.299999, 0.000000, 115.900024, 0, 0, -1, 300.00, 300.00); 
	SetDynamicObjectMaterial(tmpobjid, 0, 3922, "bistro", "sw_wallbrick_01", 0x00000000);
	tmpobjid = CreateDynamicObject(19463, 867.226745, 889.270629, 13.258796, 0.299999, 0.000000, 115.900024, 0, 0, -1, 300.00, 300.00); 
	SetDynamicObjectMaterial(tmpobjid, 0, 3922, "bistro", "sw_wallbrick_01", 0x00000000);
	tmpobjid = CreateDynamicObject(19464, 861.284912, 883.858459, 12.640591, 0.000000, 75.000000, 114.099929, 0, 0, -1, 300.00, 300.00); 
	SetDynamicObjectMaterial(tmpobjid, 0, 10778, "airportcpark_sfse", "ws_carpark3", 0x00000000);
	tmpobjid = CreateDynamicObject(19464, 857.556701, 882.020996, 12.605693, -0.499999, 74.800056, 115.899917, 0, 0, -1, 300.00, 300.00); 
	SetDynamicObjectMaterial(tmpobjid, 0, 10778, "airportcpark_sfse", "ws_carpark3", 0x00000000);
	tmpobjid = CreateDynamicObject(19463, 862.657897, 887.986999, 11.644369, 0.299999, 0.000000, 205.900024, 0, 0, -1, 300.00, 300.00); 
	SetDynamicObjectMaterial(tmpobjid, 0, 3922, "bistro", "sw_wallbrick_01", 0x00000000);
	tmpobjid = CreateDynamicObject(19463, 853.208435, 883.798339, 11.572484, 0.299999, 0.000000, 205.900024, 0, 0, -1, 300.00, 300.00); 
	SetDynamicObjectMaterial(tmpobjid, 0, 3922, "bistro", "sw_wallbrick_01", 0x00000000);
	tmpobjid = CreateDynamicObject(19463, 853.312500, 883.860229, 11.572436, 0.299999, 0.000000, 205.900024, 0, 0, -1, 300.00, 300.00); 
	SetDynamicObjectMaterial(tmpobjid, 0, 3922, "bistro", "sw_wallbrick_01", 0x00000000);
	tmpobjid = CreateDynamicObject(19463, 862.586364, 887.952148, 11.644366, 0.299999, 0.000000, 205.900024, 0, 0, -1, 300.00, 300.00); 
	SetDynamicObjectMaterial(tmpobjid, 0, 3922, "bistro", "sw_wallbrick_01", 0x00000000);
	tmpobjid = CreateDynamicObject(967, 865.316406, 884.702697, 12.320316, 0.000000, 0.000000, -64.999992, 0, 0, -1, 300.00, 300.00); 
	SetDynamicObjectMaterial(tmpobjid, 0, 16093, "a51_ext", "corugwall_sandy", 0x00000000);
	SetDynamicObjectMaterial(tmpobjid, 1, 14534, "ab_wooziea", "walp72S", 0x00000000);
	tmpobjid = CreateDynamicObject(19362, 864.941894, 887.254150, 12.274925, 0.000000, 90.000000, -64.700035, 0, 0, -1, 300.00, 300.00); 
	SetDynamicObjectMaterial(tmpobjid, 0, 16639, "a51_labs", "dam_terazzo", 0x00000000);
	tmpobjid = CreateDynamicObject(19477, 854.103088, 877.786376, 14.251566, 0.000000, 0.000000, 0.000000, 0, 0, -1, 300.00, 300.00); 
	SetDynamicObjectMaterialText(tmpobjid, 0, "{000000} Miner", 80, "Ariel", 25, 1, 0x00000000, 0x00000000, 0);
	tmpobjid = CreateDynamicObject(19477, 854.103088, 878.446777, 14.241567, 0.000000, 0.000000, 0.000000, 0, 0, -1, 300.00, 300.00); 
	SetDynamicObjectMaterialText(tmpobjid, 0, "{000000} Parking Lot", 80, "Ariel", 25, 1, 0x00000000, 0x00000000, 0);
	
	tmpobjid = CreateDynamicObject(9254, 848.832092, 899.290710, 13.962494, 0.000000, 0.000000, -154.799987, 0, 0, -1, 300.00, 300.00); 
	tmpobjid = CreateDynamicObject(1231, 849.499938, 885.424560, 16.135375, 0.000000, 0.000000, 25.199996, 0, 0, -1, 300.00, 300.00); 
	tmpobjid = CreateDynamicObject(1231, 863.831115, 892.168762, 16.275379, 0.000000, 0.000000, 25.199996, 0, 0, -1, 300.00, 300.00); 
	tmpobjid = CreateDynamicObject(1231, 831.826110, 877.977539, 16.135375, 0.000000, 0.000000, 11.499996, 0, 0, -1, 300.00, 300.00); 
	tmpobjid = CreateDynamicObject(1231, 821.263977, 900.646179, 16.255380, 0.000000, 0.000000, 41.100013, 0, 0, -1, 300.00, 300.00); 
	tmpobjid = CreateDynamicObject(1231, 864.495178, 921.002075, 16.255380, 0.000000, 0.000000, -164.600067, 0, 0, -1, 300.00, 300.00); 
	tmpobjid = CreateDynamicObject(1231, 875.098876, 898.563659, 16.255380, 0.000000, 0.000000, -138.399993, 0, 0, -1, 300.00, 300.00); 
	tmpobjid = CreateDynamicObject(1280, 865.136901, 887.731811, 12.764162, 0.000000, 0.000000, 116.100013, 0, 0, -1, 300.00, 300.00); 
	tmpobjid = CreateDynamicObject(638, 863.946044, 886.357604, 13.071882, 0.000000, 0.000000, 25.899997, 0, 0, -1, 300.00, 300.00); 
	tmpobjid = CreateDynamicObject(1223, 854.760620, 879.599182, 11.381562, 0.000000, 0.000000, -125.000007, 0, 0, -1, 300.00, 300.00); 
	tmpobjid = CreateDynamicObject(3335, 853.877563, 877.402099, 12.381564, 0.000000, 0.000000, 90.000000, 0, 0, -1, 300.00, 300.00); 

}
//