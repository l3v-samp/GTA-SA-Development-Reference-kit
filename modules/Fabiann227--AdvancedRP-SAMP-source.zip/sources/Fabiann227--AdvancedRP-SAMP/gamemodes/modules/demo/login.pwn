new CharacterActor[MAX_PLAYERS][MAX_CHARACTERS];
new CharacterActorLoaded[MAX_PLAYERS][MAX_CHARACTERS];
new CharacterBirthday[MAX_PLAYERS][MAX_CHARACTERS][24];
new CharacterGender[MAX_PLAYERS][MAX_CHARACTERS];
new CharacterSkin[MAX_PLAYERS][MAX_CHARACTERS];
new SelectCharSession[MAX_PLAYERS];

//textdraw
new PlayerText:CharSelectionTD[MAX_PLAYERS][13];
new PlayerText:RightClick[MAX_PLAYERS];
new PlayerText:LeftClick[MAX_PLAYERS];
new PlayerText:SpawnText[MAX_PLAYERS];
new PlayerText:CharName[MAX_PLAYERS];
new PlayerText:CharSkin[MAX_PLAYERS];
new PlayerText:GenderAge[MAX_PLAYERS];
new PlayerText:SelectCharText[MAX_PLAYERS];
new PlayerText:LoginScreen[MAX_PLAYERS];
ResetActor(playerid)
{
    SelectCharSession[playerid] = 0;
    CharacterActorLoaded[playerid][2] = 0;
    CharacterActorLoaded[playerid][1] = 0;
    CharacterActorLoaded[playerid][0] = 0;

    if(IsValidDynamicActor(CharacterActor[playerid][0]))
        DestroyDynamicActor(CharacterActor[playerid][0]);

    if(IsValidDynamicActor(CharacterActor[playerid][1]))
        DestroyDynamicActor(CharacterActor[playerid][1]);

    if(IsValidDynamicActor(CharacterActor[playerid][2]))
        DestroyDynamicActor(CharacterActor[playerid][2]);

    return 1;
}

CreateCharListTD(playerid)
{
    CharSelectionTD[playerid][0] = CreatePlayerTextDraw(playerid, 495.799926, 380.324340, "_");
    PlayerTextDrawFont(playerid, CharSelectionTD[playerid][0], 1);
    PlayerTextDrawLetterSize(playerid, CharSelectionTD[playerid][0], -0.079166, 5.990005);
    PlayerTextDrawTextSize(playerid, CharSelectionTD[playerid][0], 612.500000, 10.500000);
    PlayerTextDrawSetOutline(playerid, CharSelectionTD[playerid][0], 0);
    PlayerTextDrawSetShadow(playerid, CharSelectionTD[playerid][0], 0);
    PlayerTextDrawAlignment(playerid, CharSelectionTD[playerid][0], 1);
    PlayerTextDrawColor(playerid, CharSelectionTD[playerid][0], -1);
    PlayerTextDrawBackgroundColor(playerid, CharSelectionTD[playerid][0], 255);
    PlayerTextDrawBoxColor(playerid, CharSelectionTD[playerid][0], 336860415);
    PlayerTextDrawUseBox(playerid, CharSelectionTD[playerid][0], 1);
    PlayerTextDrawSetProportional(playerid, CharSelectionTD[playerid][0], 1);
    PlayerTextDrawSetSelectable(playerid, CharSelectionTD[playerid][0], 0);

    CharSelectionTD[playerid][1] = CreatePlayerTextDraw(playerid, 486.400024, 423.884460, "LD_BEAT:chit");
    PlayerTextDrawFont(playerid, CharSelectionTD[playerid][1], 4);
    PlayerTextDrawLetterSize(playerid, CharSelectionTD[playerid][1], 0.000000, 0.000000);
    PlayerTextDrawTextSize(playerid, CharSelectionTD[playerid][1], 15.000000, 15.000000);
    PlayerTextDrawSetOutline(playerid, CharSelectionTD[playerid][1], 0);
    PlayerTextDrawSetShadow(playerid, CharSelectionTD[playerid][1], 0);
    PlayerTextDrawAlignment(playerid, CharSelectionTD[playerid][1], 1);
    PlayerTextDrawColor(playerid, CharSelectionTD[playerid][1], 336860415);
    PlayerTextDrawBackgroundColor(playerid, CharSelectionTD[playerid][1], 255);
    PlayerTextDrawBoxColor(playerid, CharSelectionTD[playerid][1], 255);
    PlayerTextDrawUseBox(playerid, CharSelectionTD[playerid][1], 0);
    PlayerTextDrawSetProportional(playerid, CharSelectionTD[playerid][1], 0);
    PlayerTextDrawSetSelectable(playerid, CharSelectionTD[playerid][1], 0);

    CharSelectionTD[playerid][2] = CreatePlayerTextDraw(playerid, 485.400024, 374.884460, "LD_BEAT:chit");
    PlayerTextDrawFont(playerid, CharSelectionTD[playerid][2], 4);
    PlayerTextDrawLetterSize(playerid, CharSelectionTD[playerid][2], 0.000000, 0.000000);
    PlayerTextDrawTextSize(playerid, CharSelectionTD[playerid][2], 15.000000, 15.000000);
    PlayerTextDrawSetOutline(playerid, CharSelectionTD[playerid][2], 0);
    PlayerTextDrawSetShadow(playerid, CharSelectionTD[playerid][2], 0);
    PlayerTextDrawAlignment(playerid, CharSelectionTD[playerid][2], 1);
    PlayerTextDrawColor(playerid, CharSelectionTD[playerid][2], 336860415);
    PlayerTextDrawBackgroundColor(playerid, CharSelectionTD[playerid][2], 255);
    PlayerTextDrawBoxColor(playerid, CharSelectionTD[playerid][2], 255);
    PlayerTextDrawUseBox(playerid, CharSelectionTD[playerid][2], 0);
    PlayerTextDrawSetProportional(playerid, CharSelectionTD[playerid][2], 0);
    PlayerTextDrawSetSelectable(playerid, CharSelectionTD[playerid][2], 0);

    CharSelectionTD[playerid][3] = CreatePlayerTextDraw(playerid, 620.500000, 382.788787, "_");
    PlayerTextDrawFont(playerid, CharSelectionTD[playerid][3], 1);
    PlayerTextDrawLetterSize(playerid, CharSelectionTD[playerid][3], 0.008333, 5.250003);
    PlayerTextDrawTextSize(playerid, CharSelectionTD[playerid][3], 518.199951, 10.000000);
    PlayerTextDrawSetOutline(playerid, CharSelectionTD[playerid][3], 0);
    PlayerTextDrawSetShadow(playerid, CharSelectionTD[playerid][3], 0);
    PlayerTextDrawAlignment(playerid, CharSelectionTD[playerid][3], 1);
    PlayerTextDrawColor(playerid, CharSelectionTD[playerid][3], -1);
    PlayerTextDrawBackgroundColor(playerid, CharSelectionTD[playerid][3], 255);
    PlayerTextDrawBoxColor(playerid, CharSelectionTD[playerid][3], 336860415);
    PlayerTextDrawUseBox(playerid, CharSelectionTD[playerid][3], 1);
    PlayerTextDrawSetProportional(playerid, CharSelectionTD[playerid][3], 1);
    PlayerTextDrawSetSelectable(playerid, CharSelectionTD[playerid][3], 0);

    CharSelectionTD[playerid][4] = CreatePlayerTextDraw(playerid, 606.500122, 375.513275, "LD_BEAT:chit");
    PlayerTextDrawFont(playerid, CharSelectionTD[playerid][4], 4);
    PlayerTextDrawLetterSize(playerid, CharSelectionTD[playerid][4], 0.000000, 0.000000);
    PlayerTextDrawTextSize(playerid, CharSelectionTD[playerid][4], 15.000000, 15.000000);
    PlayerTextDrawSetOutline(playerid, CharSelectionTD[playerid][4], 0);
    PlayerTextDrawSetShadow(playerid, CharSelectionTD[playerid][4], 0);
    PlayerTextDrawAlignment(playerid, CharSelectionTD[playerid][4], 1);
    PlayerTextDrawColor(playerid, CharSelectionTD[playerid][4], 336860415);
    PlayerTextDrawBackgroundColor(playerid, CharSelectionTD[playerid][4], 255);
    PlayerTextDrawBoxColor(playerid, CharSelectionTD[playerid][4], 255);
    PlayerTextDrawUseBox(playerid, CharSelectionTD[playerid][4], 0);
    PlayerTextDrawSetProportional(playerid, CharSelectionTD[playerid][4], 0);
    PlayerTextDrawSetSelectable(playerid, CharSelectionTD[playerid][4], 0);

    CharSelectionTD[playerid][5] = CreatePlayerTextDraw(playerid, 490.500000, 384.788787, "_");
    PlayerTextDrawFont(playerid, CharSelectionTD[playerid][5], 1);
    PlayerTextDrawLetterSize(playerid, CharSelectionTD[playerid][5], 0.000000, 5.000002);
    PlayerTextDrawTextSize(playerid, CharSelectionTD[playerid][5], 509.699981, 0.000000);
    PlayerTextDrawSetOutline(playerid, CharSelectionTD[playerid][5], 0);
    PlayerTextDrawSetShadow(playerid, CharSelectionTD[playerid][5], 0);
    PlayerTextDrawAlignment(playerid, CharSelectionTD[playerid][5], 1);
    PlayerTextDrawColor(playerid, CharSelectionTD[playerid][5], -1);
    PlayerTextDrawBackgroundColor(playerid, CharSelectionTD[playerid][5], 255);
    PlayerTextDrawBoxColor(playerid, CharSelectionTD[playerid][5], 336860415);
    PlayerTextDrawUseBox(playerid, CharSelectionTD[playerid][5], 1);
    PlayerTextDrawSetProportional(playerid, CharSelectionTD[playerid][5], 1);
    PlayerTextDrawSetSelectable(playerid, CharSelectionTD[playerid][5], 0);

    CharSelectionTD[playerid][6] = CreatePlayerTextDraw(playerid, 555.899902, 397.362457, "_");
    PlayerTextDrawFont(playerid, CharSelectionTD[playerid][6], 2);
    PlayerTextDrawLetterSize(playerid, CharSelectionTD[playerid][6], 0.333932, -0.416355);
    PlayerTextDrawTextSize(playerid, CharSelectionTD[playerid][6], 10.000000, 66.500000);
    PlayerTextDrawSetOutline(playerid, CharSelectionTD[playerid][6], 0);
    PlayerTextDrawSetShadow(playerid, CharSelectionTD[playerid][6], 0);
    PlayerTextDrawAlignment(playerid, CharSelectionTD[playerid][6], 2);
    PlayerTextDrawColor(playerid, CharSelectionTD[playerid][6], -2147429377);
    PlayerTextDrawBackgroundColor(playerid, CharSelectionTD[playerid][6], 255);
    PlayerTextDrawBoxColor(playerid, CharSelectionTD[playerid][6], -2147429377);
    PlayerTextDrawUseBox(playerid, CharSelectionTD[playerid][6], 1);
    PlayerTextDrawSetProportional(playerid, CharSelectionTD[playerid][6], 1);
    PlayerTextDrawSetSelectable(playerid, CharSelectionTD[playerid][6], 1);

    CharSelectionTD[playerid][7] = CreatePlayerTextDraw(playerid, 526.200195, 427.838226, "ld_beat:chit");
    PlayerTextDrawFont(playerid, CharSelectionTD[playerid][7], 4);
    PlayerTextDrawLetterSize(playerid, CharSelectionTD[playerid][7], 0.000000, 0.000000);
    PlayerTextDrawTextSize(playerid, CharSelectionTD[playerid][7], 16.500000, 17.500000);
    PlayerTextDrawSetOutline(playerid, CharSelectionTD[playerid][7], 0);
    PlayerTextDrawSetShadow(playerid, CharSelectionTD[playerid][7], 0);
    PlayerTextDrawAlignment(playerid, CharSelectionTD[playerid][7], 1);
    PlayerTextDrawColor(playerid, CharSelectionTD[playerid][7], -2147429377);
    PlayerTextDrawBackgroundColor(playerid, CharSelectionTD[playerid][7], 255);
    PlayerTextDrawBoxColor(playerid, CharSelectionTD[playerid][7], 255);
    PlayerTextDrawUseBox(playerid, CharSelectionTD[playerid][7], 0);
    PlayerTextDrawSetProportional(playerid, CharSelectionTD[playerid][7], 0);
    PlayerTextDrawSetSelectable(playerid, CharSelectionTD[playerid][7], 0);

    CharSelectionTD[playerid][8] = CreatePlayerTextDraw(playerid, 568.200195, 427.838226, "ld_beat:chit");
    PlayerTextDrawFont(playerid, CharSelectionTD[playerid][8], 4);
    PlayerTextDrawLetterSize(playerid, CharSelectionTD[playerid][8], 0.000000, 0.000000);
    PlayerTextDrawTextSize(playerid, CharSelectionTD[playerid][8], 16.500000, 17.500000);
    PlayerTextDrawSetOutline(playerid, CharSelectionTD[playerid][8], 0);
    PlayerTextDrawSetShadow(playerid, CharSelectionTD[playerid][8], 0);
    PlayerTextDrawAlignment(playerid, CharSelectionTD[playerid][8], 1);
    PlayerTextDrawColor(playerid, CharSelectionTD[playerid][8], -2147429377);
    PlayerTextDrawBackgroundColor(playerid, CharSelectionTD[playerid][8], 255);
    PlayerTextDrawBoxColor(playerid, CharSelectionTD[playerid][8], 255);
    PlayerTextDrawUseBox(playerid, CharSelectionTD[playerid][8], 0);
    PlayerTextDrawSetProportional(playerid, CharSelectionTD[playerid][8], 0);
    PlayerTextDrawSetSelectable(playerid, CharSelectionTD[playerid][8], 0);

    RightClick[playerid] = CreatePlayerTextDraw(playerid, 588.000122, 425.840393, "ld_beat:chit");
    PlayerTextDrawFont(playerid, RightClick[playerid], 4);
    PlayerTextDrawLetterSize(playerid, RightClick[playerid], 0.000000, 0.000000);
    PlayerTextDrawTextSize(playerid, RightClick[playerid], 20.000000, 20.000000);
    PlayerTextDrawSetOutline(playerid, RightClick[playerid], 0);
    PlayerTextDrawSetShadow(playerid, RightClick[playerid], 0);
    PlayerTextDrawAlignment(playerid, RightClick[playerid], 1);
    PlayerTextDrawColor(playerid, RightClick[playerid], -2147429377);
    PlayerTextDrawBackgroundColor(playerid, RightClick[playerid], 255);
    PlayerTextDrawBoxColor(playerid, RightClick[playerid], 255);
    PlayerTextDrawUseBox(playerid, RightClick[playerid], 0);
    PlayerTextDrawSetProportional(playerid, RightClick[playerid], 0);
    PlayerTextDrawSetSelectable(playerid, RightClick[playerid], 1);

    LeftClick[playerid] = CreatePlayerTextDraw(playerid, 503.199401, 426.147125, "ld_beat:chit");
    PlayerTextDrawFont(playerid, LeftClick[playerid], 4);
    PlayerTextDrawLetterSize(playerid, LeftClick[playerid], 0.000000, 0.000000);
    PlayerTextDrawTextSize(playerid, LeftClick[playerid], 20.000000, 20.000000);
    PlayerTextDrawSetOutline(playerid, LeftClick[playerid], 0);
    PlayerTextDrawSetShadow(playerid, LeftClick[playerid], 0);
    PlayerTextDrawAlignment(playerid, LeftClick[playerid], 1);
    PlayerTextDrawColor(playerid, LeftClick[playerid], -2147429377);
    PlayerTextDrawBackgroundColor(playerid, LeftClick[playerid], 255);
    PlayerTextDrawBoxColor(playerid, LeftClick[playerid], -2147429377);
    PlayerTextDrawUseBox(playerid, LeftClick[playerid], 0);
    PlayerTextDrawSetProportional(playerid, LeftClick[playerid], 0);
    PlayerTextDrawSetSelectable(playerid, LeftClick[playerid], 1);

    CharSelectionTD[playerid][9] = CreatePlayerTextDraw(playerid, 592.800048, 428.159942, ">");
    PlayerTextDrawFont(playerid, CharSelectionTD[playerid][9], 2);
    PlayerTextDrawLetterSize(playerid, CharSelectionTD[playerid][9], 0.400000, 1.600000);
    PlayerTextDrawTextSize(playerid, CharSelectionTD[playerid][9], 2.000000, 3.599997);
    PlayerTextDrawSetOutline(playerid, CharSelectionTD[playerid][9], 0);
    PlayerTextDrawSetShadow(playerid, CharSelectionTD[playerid][9], 0);
    PlayerTextDrawAlignment(playerid, CharSelectionTD[playerid][9], 1);
    PlayerTextDrawColor(playerid, CharSelectionTD[playerid][9], -1);
    PlayerTextDrawBackgroundColor(playerid, CharSelectionTD[playerid][9], 255);
    PlayerTextDrawBoxColor(playerid, CharSelectionTD[playerid][9], 255);
    PlayerTextDrawUseBox(playerid, CharSelectionTD[playerid][9], 0);
    PlayerTextDrawSetProportional(playerid, CharSelectionTD[playerid][9], 1);
    PlayerTextDrawSetSelectable(playerid, CharSelectionTD[playerid][9], 0);

    CharSelectionTD[playerid][10] = CreatePlayerTextDraw(playerid, 506.800048, 428.159942, "<");
    PlayerTextDrawFont(playerid, CharSelectionTD[playerid][10], 2);
    PlayerTextDrawLetterSize(playerid, CharSelectionTD[playerid][10], 0.400000, 1.600000);
    PlayerTextDrawTextSize(playerid, CharSelectionTD[playerid][10], 2.000000, 3.599997);
    PlayerTextDrawSetOutline(playerid, CharSelectionTD[playerid][10], 0);
    PlayerTextDrawSetShadow(playerid, CharSelectionTD[playerid][10], 0);
    PlayerTextDrawAlignment(playerid, CharSelectionTD[playerid][10], 1);
    PlayerTextDrawColor(playerid, CharSelectionTD[playerid][10], -1);
    PlayerTextDrawBackgroundColor(playerid, CharSelectionTD[playerid][10], 255);
    PlayerTextDrawBoxColor(playerid, CharSelectionTD[playerid][10], 255);
    PlayerTextDrawUseBox(playerid, CharSelectionTD[playerid][10], 0);
    PlayerTextDrawSetProportional(playerid, CharSelectionTD[playerid][10], 1);
    PlayerTextDrawSetSelectable(playerid, CharSelectionTD[playerid][10], 0);

    SpawnText[playerid] = CreatePlayerTextDraw(playerid, 554.899902, 433.362457, "SPAWN");
    PlayerTextDrawFont(playerid, SpawnText[playerid], 1);
    PlayerTextDrawLetterSize(playerid, SpawnText[playerid], 0.275599, 0.783644);
    PlayerTextDrawTextSize(playerid, SpawnText[playerid], 10.000000, 38.500000);
    PlayerTextDrawSetOutline(playerid, SpawnText[playerid], 0);
    PlayerTextDrawSetShadow(playerid, SpawnText[playerid], 0);
    PlayerTextDrawAlignment(playerid, SpawnText[playerid], 2);
    PlayerTextDrawColor(playerid, SpawnText[playerid], -1);
    PlayerTextDrawBackgroundColor(playerid, SpawnText[playerid], 255);
    PlayerTextDrawBoxColor(playerid, SpawnText[playerid], -2147429377);
    PlayerTextDrawUseBox(playerid, SpawnText[playerid], 1);
    PlayerTextDrawSetProportional(playerid, SpawnText[playerid], 1);
    PlayerTextDrawSetSelectable(playerid, SpawnText[playerid], 1);

    CharSkin[playerid] = CreatePlayerTextDraw(playerid, 466.700134, 382.084472, "");
    PlayerTextDrawFont(playerid, CharSkin[playerid], 5);
    PlayerTextDrawLetterSize(playerid, CharSkin[playerid], 0.000000, 0.000000);
    PlayerTextDrawTextSize(playerid, CharSkin[playerid], 72.000000, 45.000000);
    PlayerTextDrawSetOutline(playerid, CharSkin[playerid], 0);
    PlayerTextDrawSetShadow(playerid, CharSkin[playerid], 0);
    PlayerTextDrawAlignment(playerid, CharSkin[playerid], 1);
    PlayerTextDrawColor(playerid, CharSkin[playerid], -1);
    PlayerTextDrawBackgroundColor(playerid, CharSkin[playerid], 0);
    PlayerTextDrawBoxColor(playerid, CharSkin[playerid], 255);
    PlayerTextDrawUseBox(playerid, CharSkin[playerid], 0);
    PlayerTextDrawSetProportional(playerid, CharSkin[playerid], 0);
    PlayerTextDrawSetSelectable(playerid, CharSkin[playerid], 0);
    PlayerTextDrawSetPreviewModel(playerid, CharSkin[playerid], 3);
    PlayerTextDrawSetPreviewRot(playerid, CharSkin[playerid], 0.000000, 0.000000, 0.000000, 1.000000);
    PlayerTextDrawSetPreviewVehCol(playerid, CharSkin[playerid], 1, 1);

    CharName[playerid] = CreatePlayerTextDraw(playerid, 553.999938, 402.113525, "Joclyn Valerie");
    PlayerTextDrawFont(playerid, CharName[playerid], 1);
    PlayerTextDrawLetterSize(playerid, CharName[playerid], 0.225429, 1.172574);
    PlayerTextDrawTextSize(playerid, CharName[playerid], 12.500000, 65.099998);
    PlayerTextDrawSetOutline(playerid, CharName[playerid], 0);
    PlayerTextDrawSetShadow(playerid, CharName[playerid], 0);
    PlayerTextDrawAlignment(playerid, CharName[playerid], 2);
    PlayerTextDrawColor(playerid, CharName[playerid], -1);
    PlayerTextDrawBackgroundColor(playerid, CharName[playerid], 255);
    PlayerTextDrawBoxColor(playerid, CharName[playerid], 255);
    PlayerTextDrawUseBox(playerid, CharName[playerid], 0);
    PlayerTextDrawSetProportional(playerid, CharName[playerid], 1);
    PlayerTextDrawSetSelectable(playerid, CharName[playerid], 0);

    GenderAge[playerid] = CreatePlayerTextDraw(playerid, 554.999938, 413.113525, "Female, 2006/02/27");
    PlayerTextDrawFont(playerid, GenderAge[playerid], 1);
    PlayerTextDrawLetterSize(playerid, GenderAge[playerid], 0.225429, 1.172574);
    PlayerTextDrawTextSize(playerid, GenderAge[playerid], 5.000000, 146.600006);
    PlayerTextDrawSetOutline(playerid, GenderAge[playerid], 0);
    PlayerTextDrawSetShadow(playerid, GenderAge[playerid], 0);
    PlayerTextDrawAlignment(playerid, GenderAge[playerid], 2);
    PlayerTextDrawColor(playerid, GenderAge[playerid], -1);
    PlayerTextDrawBackgroundColor(playerid, GenderAge[playerid], 255);
    PlayerTextDrawBoxColor(playerid, GenderAge[playerid], 255);
    PlayerTextDrawUseBox(playerid, GenderAge[playerid], 0);
    PlayerTextDrawSetProportional(playerid, GenderAge[playerid], 1);
    PlayerTextDrawSetSelectable(playerid, GenderAge[playerid], 0);

    CharSelectionTD[playerid][11] = CreatePlayerTextDraw(playerid, 606.400024, 423.884460, "LD_BEAT:chit");
    PlayerTextDrawFont(playerid, CharSelectionTD[playerid][11], 4);
    PlayerTextDrawLetterSize(playerid, CharSelectionTD[playerid][11], 0.000000, 0.000000);
    PlayerTextDrawTextSize(playerid, CharSelectionTD[playerid][11], 15.000000, 15.500000);
    PlayerTextDrawSetOutline(playerid, CharSelectionTD[playerid][11], 0);
    PlayerTextDrawSetShadow(playerid, CharSelectionTD[playerid][11], 0);
    PlayerTextDrawAlignment(playerid, CharSelectionTD[playerid][11], 1);
    PlayerTextDrawColor(playerid, CharSelectionTD[playerid][11], 336860415);
    PlayerTextDrawBackgroundColor(playerid, CharSelectionTD[playerid][11], 255);
    PlayerTextDrawBoxColor(playerid, CharSelectionTD[playerid][11], 255);
    PlayerTextDrawUseBox(playerid, CharSelectionTD[playerid][11], 0);
    PlayerTextDrawSetProportional(playerid, CharSelectionTD[playerid][11], 0);
    PlayerTextDrawSetSelectable(playerid, CharSelectionTD[playerid][11], 0);

    SelectCharText[playerid] = CreatePlayerTextDraw(playerid, 555.999938, 382.113525, "Select Character");
    PlayerTextDrawFont(playerid, SelectCharText[playerid], 1);
    PlayerTextDrawLetterSize(playerid, SelectCharText[playerid], 0.225429, 1.172574);
    PlayerTextDrawTextSize(playerid, SelectCharText[playerid], 5.000000, 146.600006);
    PlayerTextDrawSetOutline(playerid, SelectCharText[playerid], 0);
    PlayerTextDrawSetShadow(playerid, SelectCharText[playerid], 0);
    PlayerTextDrawAlignment(playerid, SelectCharText[playerid], 2);
    PlayerTextDrawColor(playerid, SelectCharText[playerid], -1);
    PlayerTextDrawBackgroundColor(playerid, SelectCharText[playerid], 255);
    PlayerTextDrawBoxColor(playerid, SelectCharText[playerid], 255);
    PlayerTextDrawUseBox(playerid, SelectCharText[playerid], 0);
    PlayerTextDrawSetProportional(playerid, SelectCharText[playerid], 1);
    PlayerTextDrawSetSelectable(playerid, SelectCharText[playerid], 0);

    return 1;
}

stock RefrestCharacterListTextDraw(playerid, num)
{
    if(CharacterList[playerid][num][0] != EOS) {
        PlayerTextDrawSetString(playerid, SelectCharText[playerid], "Select Character");
        PlayerTextDrawSetString(playerid, SpawnText[playerid], "SPAWN");
        PlayerTextDrawSetString(playerid, CharName[playerid], sprintf("%s", CharacterList[playerid][num]));
        PlayerTextDrawSetString(playerid, GenderAge[playerid], sprintf("%s, %s", (CharacterGender[playerid][num] == 1) ? ("Male") : ("Female"), CharacterBirthday[playerid][num]));
        PlayerTextDrawSetPreviewModel(playerid, CharSkin[playerid], CharacterSkin[playerid][num]);

        PlayerTextDrawShow(playerid, CharSkin[playerid]);
        format(PlayerData[playerid][pTempName], MAX_PLAYER_NAME, CharacterList[playerid][num]);
    }
    else 
    {
        PlayerTextDrawSetString(playerid, SelectCharText[playerid], "Create Character");
        PlayerTextDrawSetString(playerid, SpawnText[playerid], "CREATE");
        PlayerTextDrawSetString(playerid, CharName[playerid], "Empty_Slot");
        PlayerTextDrawSetString(playerid, GenderAge[playerid], sprintf("Gender, Birthday"));
        //PlayerTextDrawSetPreviewModel(playerid, CharSkin[playerid], 299);

        PlayerTextDrawHide(playerid, CharSkin[playerid]);
    }
    return 1;
}

stock RefrestCharacterPos(playerid)
{
    if(CharacterList[playerid][2][0] != EOS) 
    {
        if(!CharacterActorLoaded[playerid][2])
        {
            CharacterActor[playerid][2] = CreateDynamicActor(CharacterSkin[playerid][2], 1638.99,-2287.57,15.4952,177.131, true, 100, playerid+1);
            ApplyDynamicActorAnimation(CharacterActor[playerid][2], "DEALER", "DEALER_IDLE", 4.1, 1, 0, 0, 0, 0);
        
            CharacterActorLoaded[playerid][2] = 1;
        }
    }
    if(CharacterList[playerid][1][0] != EOS) 
    {
        if(!CharacterActorLoaded[playerid][1])
        {
            CharacterActor[playerid][1] = CreateDynamicActor(CharacterSkin[playerid][1], 1627.2,-2306.89,13.6147,1.87795, true, 100, playerid+1);
            ApplyDynamicActorAnimation(CharacterActor[playerid][1], "ped", "SEAT_down", 4.1, 0, 0, 0, 1, 0);
        
            CharacterActorLoaded[playerid][1] = 1;
        }
    }
    if(CharacterList[playerid][0][0] != EOS) 
    {
        if(!CharacterActorLoaded[playerid][0])
        {
            CharacterActor[playerid][0] = CreateDynamicActor(CharacterSkin[playerid][0], 1645.21,-2313.51,13.5578,181.083, true, 100, playerid+1);
            ApplyDynamicActorAnimation(CharacterActor[playerid][0], "SMOKING", "M_smk_drag", 4.1, 1, 0, 0, 0, 0);
            CharacterActorLoaded[playerid][0] = 1;
        }
    }        
    return 1;
}