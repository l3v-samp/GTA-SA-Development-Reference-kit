new Text:RegModeTD[11];
new PlayerText:CharNameTD[MAX_PLAYERS];
new PlayerText:CreateCharTD[MAX_PLAYERS];
new PlayerText:BirthTD[MAX_PLAYERS];
new PlayerText:NationTD[MAX_PLAYERS];
new PlayerText:AccentTD[MAX_PLAYERS];
new PlayerText:GenderTD[MAX_PLAYERS];
new PlayerText:SkinTD[MAX_PLAYERS];
new PlayerText:PrevSkinTD[MAX_PLAYERS];
new PlayerText:NextSkinTD[MAX_PLAYERS];

new maleskinSession[MAX_PLAYERS], femaleskinSession[MAX_PLAYERS];

new MaleSkinData[] = 
{
	1,
	2,
	3,
	98,
	101,
	299,
	182
};

new FemaleSkinData[] = 
{
	56,
	41,
	12,
	13,
	193,
	298,
	211
};

CreateRegisterTD(playerid)
{
    //regmode
    CharNameTD[playerid] = CreatePlayerTextDraw(playerid, 538.000000, 106.000000, "Character Name");
    PlayerTextDrawFont(playerid, CharNameTD[playerid], 1);
    PlayerTextDrawLetterSize(playerid, CharNameTD[playerid], 0.241665, 1.500000);
    PlayerTextDrawTextSize(playerid, CharNameTD[playerid], 16.500000, 90.500000);
    PlayerTextDrawSetOutline(playerid, CharNameTD[playerid], 0);
    PlayerTextDrawSetShadow(playerid, CharNameTD[playerid], 0);
    PlayerTextDrawAlignment(playerid, CharNameTD[playerid], 2);
    PlayerTextDrawColor(playerid, CharNameTD[playerid], -148);
    PlayerTextDrawBackgroundColor(playerid, CharNameTD[playerid], 205);
    PlayerTextDrawBoxColor(playerid, CharNameTD[playerid], 35);
    PlayerTextDrawUseBox(playerid, CharNameTD[playerid], 0);
    PlayerTextDrawSetProportional(playerid, CharNameTD[playerid], 1);
    PlayerTextDrawSetSelectable(playerid, CharNameTD[playerid], 1);

    CreateCharTD[playerid] = CreatePlayerTextDraw(playerid, 542.000000, 351.000000, "Deploy Character");
    PlayerTextDrawFont(playerid, CreateCharTD[playerid], 1);
    PlayerTextDrawLetterSize(playerid, CreateCharTD[playerid], 0.241665, 1.500000);
    PlayerTextDrawTextSize(playerid, CreateCharTD[playerid], 16.500000, 90.500000);
    PlayerTextDrawSetOutline(playerid, CreateCharTD[playerid], 0);
    PlayerTextDrawSetShadow(playerid, CreateCharTD[playerid], 0);
    PlayerTextDrawAlignment(playerid, CreateCharTD[playerid], 2);
    PlayerTextDrawColor(playerid, CreateCharTD[playerid], -148);
    PlayerTextDrawBackgroundColor(playerid, CreateCharTD[playerid], 205);
    PlayerTextDrawBoxColor(playerid, CreateCharTD[playerid], 35);
    PlayerTextDrawUseBox(playerid, CreateCharTD[playerid], 1);
    PlayerTextDrawSetProportional(playerid, CreateCharTD[playerid], 1);
    PlayerTextDrawSetSelectable(playerid, CreateCharTD[playerid], 1);

    BirthTD[playerid] = CreatePlayerTextDraw(playerid, 539.000000, 131.000000, "Date of Birth");
    PlayerTextDrawFont(playerid, BirthTD[playerid], 1);
    PlayerTextDrawLetterSize(playerid, BirthTD[playerid], 0.241665, 1.500000);
    PlayerTextDrawTextSize(playerid, BirthTD[playerid], 16.500000, 90.500000);
    PlayerTextDrawSetOutline(playerid, BirthTD[playerid], 0);
    PlayerTextDrawSetShadow(playerid, BirthTD[playerid], 0);
    PlayerTextDrawAlignment(playerid, BirthTD[playerid], 2);
    PlayerTextDrawColor(playerid, BirthTD[playerid], -148);
    PlayerTextDrawBackgroundColor(playerid, BirthTD[playerid], 205);
    PlayerTextDrawBoxColor(playerid, BirthTD[playerid], 35);
    PlayerTextDrawUseBox(playerid, BirthTD[playerid], 1);
    PlayerTextDrawSetProportional(playerid, BirthTD[playerid], 1);
    PlayerTextDrawSetSelectable(playerid, BirthTD[playerid], 1);

    NationTD[playerid] = CreatePlayerTextDraw(playerid, 539.000000, 163.000000, "Nation");
    PlayerTextDrawFont(playerid, NationTD[playerid], 1);
    PlayerTextDrawLetterSize(playerid, NationTD[playerid], 0.241665, 1.500000);
    PlayerTextDrawTextSize(playerid, NationTD[playerid], 16.500000, 90.500000);
    PlayerTextDrawSetOutline(playerid, NationTD[playerid], 0);
    PlayerTextDrawSetShadow(playerid, NationTD[playerid], 0);
    PlayerTextDrawAlignment(playerid, NationTD[playerid], 2);
    PlayerTextDrawColor(playerid, NationTD[playerid], -148);
    PlayerTextDrawBackgroundColor(playerid, NationTD[playerid], 205);
    PlayerTextDrawBoxColor(playerid, NationTD[playerid], 35);
    PlayerTextDrawUseBox(playerid, NationTD[playerid], 1);
    PlayerTextDrawSetProportional(playerid, NationTD[playerid], 1);
    PlayerTextDrawSetSelectable(playerid, NationTD[playerid], 1);

    AccentTD[playerid] = CreatePlayerTextDraw(playerid, 539.000000, 195.000000, "Accent");
    PlayerTextDrawFont(playerid, AccentTD[playerid], 1);
    PlayerTextDrawLetterSize(playerid, AccentTD[playerid], 0.241665, 1.500000);
    PlayerTextDrawTextSize(playerid, AccentTD[playerid], 16.500000, 90.500000);
    PlayerTextDrawSetOutline(playerid, AccentTD[playerid], 0);
    PlayerTextDrawSetShadow(playerid, AccentTD[playerid], 0);
    PlayerTextDrawAlignment(playerid, AccentTD[playerid], 2);
    PlayerTextDrawColor(playerid, AccentTD[playerid], -148);
    PlayerTextDrawBackgroundColor(playerid, AccentTD[playerid], 205);
    PlayerTextDrawBoxColor(playerid, AccentTD[playerid], 35);
    PlayerTextDrawUseBox(playerid, AccentTD[playerid], 1);
    PlayerTextDrawSetProportional(playerid, AccentTD[playerid], 1);
    PlayerTextDrawSetSelectable(playerid, AccentTD[playerid], 1);

    GenderTD[playerid] = CreatePlayerTextDraw(playerid, 539.000000, 227.000000, "Gender");
    PlayerTextDrawFont(playerid, GenderTD[playerid], 1);
    PlayerTextDrawLetterSize(playerid, GenderTD[playerid], 0.241665, 1.500000);
    PlayerTextDrawTextSize(playerid, GenderTD[playerid], 16.500000, 90.500000);
    PlayerTextDrawSetOutline(playerid, GenderTD[playerid], 0);
    PlayerTextDrawSetShadow(playerid, GenderTD[playerid], 0);
    PlayerTextDrawAlignment(playerid, GenderTD[playerid], 2);
    PlayerTextDrawColor(playerid, GenderTD[playerid], -148);
    PlayerTextDrawBackgroundColor(playerid, GenderTD[playerid], 205);
    PlayerTextDrawBoxColor(playerid, GenderTD[playerid], 35);
    PlayerTextDrawUseBox(playerid, GenderTD[playerid], 1);
    PlayerTextDrawSetProportional(playerid, GenderTD[playerid], 1);
    PlayerTextDrawSetSelectable(playerid, GenderTD[playerid], 1);

    SkinTD[playerid] = CreatePlayerTextDraw(playerid, 509.000000, 270.000000, "Preview_Model");
    PlayerTextDrawFont(playerid, SkinTD[playerid], 5);
    PlayerTextDrawLetterSize(playerid, SkinTD[playerid], 0.600000, 2.000000);
    PlayerTextDrawTextSize(playerid, SkinTD[playerid], 62.500000, 79.000000);
    PlayerTextDrawSetOutline(playerid, SkinTD[playerid], 0);
    PlayerTextDrawSetShadow(playerid, SkinTD[playerid], 0);
    PlayerTextDrawAlignment(playerid, SkinTD[playerid], 1);
    PlayerTextDrawColor(playerid, SkinTD[playerid], -1);
    PlayerTextDrawBackgroundColor(playerid, SkinTD[playerid], 0);
    PlayerTextDrawBoxColor(playerid, SkinTD[playerid], 255);
    PlayerTextDrawUseBox(playerid, SkinTD[playerid], 0);
    PlayerTextDrawSetProportional(playerid, SkinTD[playerid], 1);
    PlayerTextDrawSetSelectable(playerid, SkinTD[playerid], 0);
    PlayerTextDrawSetPreviewModel(playerid, SkinTD[playerid], 292);
    PlayerTextDrawSetPreviewRot(playerid, SkinTD[playerid], -10.000000, 0.000000, -20.000000, 1.000000);
    PlayerTextDrawSetPreviewVehCol(playerid, SkinTD[playerid], 1, 1);

    PrevSkinTD[playerid] = CreatePlayerTextDraw(playerid, 475.000000, 299.000000, "<<");
    PlayerTextDrawFont(playerid, PrevSkinTD[playerid], 1);
    PlayerTextDrawLetterSize(playerid, PrevSkinTD[playerid], 0.262497, 1.899999);
    PlayerTextDrawTextSize(playerid, PrevSkinTD[playerid], 16.500000, 90.500000);
    PlayerTextDrawSetOutline(playerid, PrevSkinTD[playerid], 0);
    PlayerTextDrawSetShadow(playerid, PrevSkinTD[playerid], 0);
    PlayerTextDrawAlignment(playerid, PrevSkinTD[playerid], 2);
    PlayerTextDrawColor(playerid, PrevSkinTD[playerid], -148);
    PlayerTextDrawBackgroundColor(playerid, PrevSkinTD[playerid], 205);
    PlayerTextDrawBoxColor(playerid, PrevSkinTD[playerid], 35);
    PlayerTextDrawUseBox(playerid, PrevSkinTD[playerid], 0);
    PlayerTextDrawSetProportional(playerid, PrevSkinTD[playerid], 1);
    PlayerTextDrawSetSelectable(playerid, PrevSkinTD[playerid], 1);

    NextSkinTD[playerid] = CreatePlayerTextDraw(playerid, 599.000000, 299.000000, ">>");
    PlayerTextDrawFont(playerid, NextSkinTD[playerid], 1);
    PlayerTextDrawLetterSize(playerid, NextSkinTD[playerid], 0.262497, 1.899999);
    PlayerTextDrawTextSize(playerid, NextSkinTD[playerid], 16.500000, 90.500000);
    PlayerTextDrawSetOutline(playerid, NextSkinTD[playerid], 0);
    PlayerTextDrawSetShadow(playerid, NextSkinTD[playerid], 0);
    PlayerTextDrawAlignment(playerid, NextSkinTD[playerid], 2);
    PlayerTextDrawColor(playerid, NextSkinTD[playerid], -148);
    PlayerTextDrawBackgroundColor(playerid, NextSkinTD[playerid], 205);
    PlayerTextDrawBoxColor(playerid, NextSkinTD[playerid], 35);
    PlayerTextDrawUseBox(playerid, NextSkinTD[playerid], 0);
    PlayerTextDrawSetProportional(playerid, NextSkinTD[playerid], 1);
    PlayerTextDrawSetSelectable(playerid, NextSkinTD[playerid], 1);

    return 1;
}

stock HideCharacterSetup(playerid)
{
	CancelSelectTextDraw(playerid);
	forex(i, 11)
	{
		TextDrawHideForPlayer(playerid, RegModeTD[i]);
	}
	DestroyPlayerTD(playerid, CharNameTD[playerid]);
	DestroyPlayerTD(playerid, CreateCharTD[playerid]);
	DestroyPlayerTD(playerid, BirthTD[playerid]);
	DestroyPlayerTD(playerid, NationTD[playerid]);
	DestroyPlayerTD(playerid, AccentTD[playerid]);
	DestroyPlayerTD(playerid, GenderTD[playerid]);
	DestroyPlayerTD(playerid, SkinTD[playerid]);
	DestroyPlayerTD(playerid, PrevSkinTD[playerid]);
	DestroyPlayerTD(playerid, NextSkinTD[playerid]);	

	maleskinSession[playerid] = -1;
    femaleskinSession[playerid] = -1;
	return 1;
}
stock ShowCharacterSetup(playerid)
{	
	SetPlayerPos(playerid,65.1892, 1073.6, -50.9141);
	SetPlayerFacingAngle(playerid, 179.98);
	TogglePlayerControllable(playerid,0);

	InterpolateCameraPos(playerid, 64.819900, 1070.314453, -50.432876, 64.542419, 1071.572387, -50.401107, 10000);
    InterpolateCameraLookAt(playerid, 64.796295, 1075.312866, -50.307888, 65.710304, 1076.430908, -50.576854, 10000);

    ToggleGUIDisplay(playerid, false);

	SelectTextDraw(playerid, COLOR_YELLOW);
	forex(i, 11)
	{
		TextDrawShowForPlayer(playerid, RegModeTD[i]);
	}
	PlayerTextDrawShow(playerid, CharNameTD[playerid]);
	PlayerTextDrawShow(playerid, CreateCharTD[playerid]);
	PlayerTextDrawShow(playerid, BirthTD[playerid]);
	PlayerTextDrawShow(playerid, NationTD[playerid]);
	PlayerTextDrawShow(playerid, AccentTD[playerid]);
	PlayerTextDrawShow(playerid, GenderTD[playerid]);
	
	PlayerTextDrawShow(playerid, PrevSkinTD[playerid]);
	PlayerTextDrawShow(playerid, NextSkinTD[playerid]);

    PlayerData[playerid][pCharacter] = SelectCharSession[playerid];
    SetPlayerName(playerid, CharacterList[playerid][SelectCharSession[playerid]]);
	PlayerTextDrawSetString(playerid, CharNameTD[playerid], sprintf("%s", PlayerData[playerid][pTempName]));

	return 1;
}

GetPlayerOrigin(playerid)
{
    new origin[26];
    switch(PlayerData[playerid][pOrigin])
    {
        case 0, 1: origin = "United States";
        case 2: origin = "Unites Kingdom";
        case 3: origin = "Indonesia";
        case 4: origin = "Africa";
    }
    return origin;
}

GetPlayerAccent(playerid)
{
	new accent[26];
	switch(PlayerData[playerid][pAccent])
	{
		case 0, 1: accent = "No accent";
		case 2: accent = "British accent";
		case 3: accent = "Japanese accent";
		case 4: accent = "Chinese accent";
		case 5: accent = "Korean accent";
		case 6: accent = "Scottish accent";
		case 7: accent = "Irish accent";
		case 8: accent = "Russian accent";
		case 9: accent = "American accent";
		case 10, 12: accent = "Spanish accent";
		case 11: accent = "Southern accent";
		case 13: accent = "Italian accent";
		case 14: accent = "Gangster accent";
		case 15: accent = "Australian accent";
		case 16: accent = "Arabic accent";
		case 17: accent = "Balkan accent";
		case 18: accent = "Canadian accent";
		case 19: accent = "Jamaican accent";
		case 20: accent = "Israeli accent";
		case 21: accent = "Dutch accent";
		case 22: accent = "Brazilian accent";
		case 23: accent = "German accent";
		case 24: accent = "Turkish accent";
		case 25: accent = "Kiwi accent";
		case 26: accent = "French accent";
		case 27: accent = "Korean accent";
		case 28: accent = "Indonesian accent";
		case 29: accent = "Thai accent";
	}
	return accent;
}

Dialog:CharName(playerid, response, listitem, inputtext[])
{
    if (!response)
        return SelectTextDraw(playerid, COLOR_YELLOW);

    if (!IsValidRoleplayName(inputtext) || strlen(inputtext) <= 3 && strlen(inputtext) > 24) {
        SendClientMessage(playerid, COLOR_WHITE, "Name must comply with Roleplay rules, eg: Kimberly_Summers, Rein_Styles, Paul_Rostislav");
        return Dialog_Show(playerid, CharName, DIALOG_STYLE_INPUT, "Create Character", WHITE"Enter character name, maximum 24 characters\n\nExample: "GREEN"Mark_Arhur, Alexader_Kimberly.", "Create", "Back");
    }

    mysql_tquery(g_iHandle, sprintf("SELECT * FROM `characters` WHERE `Character` = '%s' LIMIT 1;", inputtext), "OnCharacterNameCheck", "is", playerid, inputtext);
    return 1;
}

Function:OnCharacterNameCheck(playerid, charaname[])
{
    if (!cache_num_rows())
    {
        format(PlayerData[playerid][pTempName], MAX_PLAYER_NAME, charaname);
        PlayerTextDrawSetString(playerid, CharNameTD[playerid], sprintf("%s", PlayerData[playerid][pTempName]));
        SelectTextDraw(playerid, COLOR_YELLOW);
        return 1;
    }

    SendClientMessage(playerid, COLOR_WHITE, "Nama tersebut sudah terpakai! Silahkan ganti nama yang lain.");
    Dialog_Show(playerid, CharName, DIALOG_STYLE_INPUT, "Create Character", WHITE"Nama sudah terpakai, Gunakan nama lain!\n\nContoh: "GREEN"Mark_Arhur, Alexader_Kimberly.", "Create", "Back");
    return 1;
}

Dialog:Gender(playerid, response, listitem, inputtext[])
{
    if(response)
    {
    	switch (listitem) 
		{
			case 0: 
			{
				femaleskinSession[playerid] = -1;
				maleskinSession[playerid] = 1;
				PlayerTextDrawSetString(playerid, GenderTD[playerid], "Male");
		        PlayerData[playerid][pGender] = 1;

		        SetPlayerSkinEx(playerid, 299);
		        PlayerTextDrawSetPreviewModel(playerid, SkinTD[playerid], PlayerData[playerid][pSkin]);
                PlayerTextDrawShow(playerid, SkinTD[playerid]);
        		SelectTextDraw(playerid, COLOR_YELLOW);
        	}
        	case 1:
        	{
        		maleskinSession[playerid] = -1;
        		femaleskinSession[playerid] = 1;
				PlayerTextDrawSetString(playerid, GenderTD[playerid], "Female");
		        PlayerData[playerid][pGender] = 2;

		        SetPlayerSkinEx(playerid, 193);
		        PlayerTextDrawSetPreviewModel(playerid, SkinTD[playerid], PlayerData[playerid][pSkin]);
                PlayerTextDrawShow(playerid, SkinTD[playerid]);
        		SelectTextDraw(playerid, COLOR_YELLOW);
        	}
        }
    }
    else SelectTextDraw(playerid, COLOR_YELLOW);
    return 1;
}

Dialog:DateBirth(playerid, response, listitem, inputtext[])
{
    if(response)
    {
        new
            iDay,
            iMonth,
            iYear,
            day,
            month,
            year;

        getdate(year, month, day);

        static const
                arrMonthDays[] = {31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};

        if(sscanf(inputtext, "p</>ddd", iDay, iMonth, iYear)) {
            Dialog_Show(playerid, DateBirth, DIALOG_STYLE_INPUT, "Tanggal Lahir", "Error: Tidak sesuai format, gunakan / di setiap tanggal/bulan/tahun!\n\nMasukkan tanggal lahir dengan mengikuti format (DD/MM/YYYY):", "Submit", "Cancel");
        }
        else if(iYear < 1900 || iYear > year) {
            Dialog_Show(playerid, DateBirth, DIALOG_STYLE_INPUT, "Tanggal Lahir", "Error: Takun tidak sesuai!\n\nMasukkan tanggal lahir dengan mengikuti format (DD/MM/YYYY):", "Submit", "Cancel");
        }
        else if(iMonth < 1 || iMonth > 12) {
            Dialog_Show(playerid, DateBirth, DIALOG_STYLE_INPUT, "Tanggal Lahir", "Error: Bulan tidak sesuai!\n\nMasukkan tanggal lahir dengan mengikuti format (DD/MM/YYYY):", "Submit", "Cancel");
        }
        else if(iDay < 1 || iDay > arrMonthDays[iMonth - 1]) {
            Dialog_Show(playerid, DateBirth, DIALOG_STYLE_INPUT, "Tanggal Lahir", "Error: Hari tidak sesuai!\n\nMasukkan tanggal lahir dengan mengikuti format (DD/MM/YYYY):", "Submit", "Cancel");
        }
        else {
            format(PlayerData[playerid][pBirthdate], 24, inputtext);
            PlayerTextDrawSetString(playerid, BirthTD[playerid], sprintf("%s", PlayerData[playerid][pBirthdate]));
            SelectTextDraw(playerid, COLOR_YELLOW);
        }
    }
    else SelectTextDraw(playerid, COLOR_YELLOW);
    return 1;
}

Dialog:Origin(playerid, response, listitem, inputtext[])
{
    if(response)
    {
        PlayerData[playerid][pOrigin] = listitem+1;
        new string[128];
        format(string, sizeof(string), "%s", GetPlayerOrigin(playerid));
        PlayerTextDrawSetString(playerid, NationTD[playerid], string);
        SelectTextDraw(playerid, COLOR_YELLOW);
    }
    else SelectTextDraw(playerid, COLOR_YELLOW);
    return 1;
}

Dialog:AccentList(playerid, response, listitem, inputtext[])
{
	if(response)
	{
		if(listitem == 0) PlayerData[playerid][pAccent] = listitem;
		if(listitem > 0) PlayerData[playerid][pAccent] = listitem+1;
		new string[128];
		format(string, sizeof(string), "%s", GetPlayerAccent(playerid));
		PlayerTextDrawSetString(playerid, AccentTD[playerid], string);
		SelectTextDraw(playerid, COLOR_YELLOW);
	}
	else SelectTextDraw(playerid, COLOR_YELLOW);
    return 1;
}