#include <YSI\y_hooks>

public OnPlayerClickMap(playerid, Float:fX, Float:fY, Float:fZ)
{

    if(GetPlayerWayPointStatus(playerid))
    {
        RemovePlayerMapIcon(playerid, 20);
        // RemoveDriverMarkerPoint(playerid);
        // SetPlayerWayPointStatus(playerid, false);
    }

    if(IsPlayerInAnyVehicle(playerid) && GetPlayerState(playerid) != PLAYER_STATE_DRIVER)
    {
        SetDriverMarkerPoint(playerid, fX, fY, fZ);
    }
    if(AccountData[playerid][pAdminDuty])
    {
        if(GetPlayerState(playerid) == PLAYER_STATE_DRIVER)
            SetVehiclePos(GetPlayerVehicleID(playerid), fX, fY, fZ),
            SendServerMessage(playerid, "You have teleported to map.");

        else
            SetPlayerPosFindZ(playerid, fX, fY, fZ),
            SendServerMessage(playerid, "You have teleported to map.");
    }
    return 1;
}

hook OnPlayerConnect(playerid)
{
    playerWayPoint[playerid] = false;
}

hook OnPlayerDisconnect(playerid, reason)
{
    playerWayPoint[playerid] = false;
}