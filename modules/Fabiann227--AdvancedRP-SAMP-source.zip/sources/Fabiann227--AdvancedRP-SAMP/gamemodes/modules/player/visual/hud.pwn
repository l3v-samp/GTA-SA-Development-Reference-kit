new PlayerText:AdvancedHud[MAX_PLAYERS][24];
new PlayerText:HealthBar[MAX_PLAYERS];
new PlayerText:ArmorBar[MAX_PLAYERS];
new PlayerText:Thirst[MAX_PLAYERS];
new PlayerText:Hunger[MAX_PLAYERS];

PcGUI(playerid)
{
	AdvancedHud[playerid][0] = CreatePlayerTextDraw(playerid, 313.500000, 429.000000, "_");
	PlayerTextDrawFont(playerid, AdvancedHud[playerid][0], 1);
	PlayerTextDrawLetterSize(playerid, AdvancedHud[playerid][0], 0.012500, -0.399996);
	PlayerTextDrawTextSize(playerid, AdvancedHud[playerid][0], 300.500000, 61.000000);
	PlayerTextDrawSetOutline(playerid, AdvancedHud[playerid][0], 1);
	PlayerTextDrawSetShadow(playerid, AdvancedHud[playerid][0], 0);
	PlayerTextDrawAlignment(playerid, AdvancedHud[playerid][0], 2);
	PlayerTextDrawColor(playerid, AdvancedHud[playerid][0], -1);
	PlayerTextDrawBackgroundColor(playerid, AdvancedHud[playerid][0], 255);
	PlayerTextDrawBoxColor(playerid, AdvancedHud[playerid][0], 135);
	PlayerTextDrawUseBox(playerid, AdvancedHud[playerid][0], 1);
	PlayerTextDrawSetProportional(playerid, AdvancedHud[playerid][0], 1);
	PlayerTextDrawSetSelectable(playerid, AdvancedHud[playerid][0], 0);

	AdvancedHud[playerid][1] = CreatePlayerTextDraw(playerid, 330.000000, 429.000000, "ld_dual:white");
	PlayerTextDrawFont(playerid, AdvancedHud[playerid][1], 4);
	PlayerTextDrawLetterSize(playerid, AdvancedHud[playerid][1], 0.600000, 2.000000);
	PlayerTextDrawTextSize(playerid, AdvancedHud[playerid][1], 14.000000, 16.500000);
	PlayerTextDrawSetOutline(playerid, AdvancedHud[playerid][1], 1);
	PlayerTextDrawSetShadow(playerid, AdvancedHud[playerid][1], 0);
	PlayerTextDrawAlignment(playerid, AdvancedHud[playerid][1], 1);
	PlayerTextDrawColor(playerid, AdvancedHud[playerid][1], 201);
	PlayerTextDrawBackgroundColor(playerid, AdvancedHud[playerid][1], 255);
	PlayerTextDrawBoxColor(playerid, AdvancedHud[playerid][1], -1094795726);
	PlayerTextDrawUseBox(playerid, AdvancedHud[playerid][1], 1);
	PlayerTextDrawSetProportional(playerid, AdvancedHud[playerid][1], 1);
	PlayerTextDrawSetSelectable(playerid, AdvancedHud[playerid][1], 0);

	AdvancedHud[playerid][2] = CreatePlayerTextDraw(playerid, 283.000000, 429.000000, "ld_dual:white");
	PlayerTextDrawFont(playerid, AdvancedHud[playerid][2], 4);
	PlayerTextDrawLetterSize(playerid, AdvancedHud[playerid][2], 0.600000, 2.000000);
	PlayerTextDrawTextSize(playerid, AdvancedHud[playerid][2], 14.000000, 16.500000);
	PlayerTextDrawSetOutline(playerid, AdvancedHud[playerid][2], 1);
	PlayerTextDrawSetShadow(playerid, AdvancedHud[playerid][2], 0);
	PlayerTextDrawAlignment(playerid, AdvancedHud[playerid][2], 1);
	PlayerTextDrawColor(playerid, AdvancedHud[playerid][2], 201);
	PlayerTextDrawBackgroundColor(playerid, AdvancedHud[playerid][2], 255);
	PlayerTextDrawBoxColor(playerid, AdvancedHud[playerid][2], -1094795726);
	PlayerTextDrawUseBox(playerid, AdvancedHud[playerid][2], 1);
	PlayerTextDrawSetProportional(playerid, AdvancedHud[playerid][2], 1);
	PlayerTextDrawSetSelectable(playerid, AdvancedHud[playerid][2], 0);

	AdvancedHud[playerid][3] = CreatePlayerTextDraw(playerid, 285.000000, 443.000000, "ld_dual:white");
	PlayerTextDrawFont(playerid, AdvancedHud[playerid][3], 4);
	PlayerTextDrawLetterSize(playerid, AdvancedHud[playerid][3], 0.600000, 2.000000);
	PlayerTextDrawTextSize(playerid, AdvancedHud[playerid][3], 10.500000, 1.500000);
	PlayerTextDrawSetOutline(playerid, AdvancedHud[playerid][3], 1);
	PlayerTextDrawSetShadow(playerid, AdvancedHud[playerid][3], 0);
	PlayerTextDrawAlignment(playerid, AdvancedHud[playerid][3], 1);
	PlayerTextDrawColor(playerid, AdvancedHud[playerid][3], -1962934017);
	PlayerTextDrawBackgroundColor(playerid, AdvancedHud[playerid][3], 255);
	PlayerTextDrawBoxColor(playerid, AdvancedHud[playerid][3], -1094795726);
	PlayerTextDrawUseBox(playerid, AdvancedHud[playerid][3], 1);
	PlayerTextDrawSetProportional(playerid, AdvancedHud[playerid][3], 1);
	PlayerTextDrawSetSelectable(playerid, AdvancedHud[playerid][3], 0);

	AdvancedHud[playerid][4] = CreatePlayerTextDraw(playerid, 298.000000, 429.000000, "ld_dual:white");
	PlayerTextDrawFont(playerid, AdvancedHud[playerid][4], 4);
	PlayerTextDrawLetterSize(playerid, AdvancedHud[playerid][4], 0.600000, 2.000000);
	PlayerTextDrawTextSize(playerid, AdvancedHud[playerid][4], 14.000000, 16.500000);
	PlayerTextDrawSetOutline(playerid, AdvancedHud[playerid][4], 1);
	PlayerTextDrawSetShadow(playerid, AdvancedHud[playerid][4], 0);
	PlayerTextDrawAlignment(playerid, AdvancedHud[playerid][4], 1);
	PlayerTextDrawColor(playerid, AdvancedHud[playerid][4], 201);
	PlayerTextDrawBackgroundColor(playerid, AdvancedHud[playerid][4], 255);
	PlayerTextDrawBoxColor(playerid, AdvancedHud[playerid][4], -1094795726);
	PlayerTextDrawUseBox(playerid, AdvancedHud[playerid][4], 1);
	PlayerTextDrawSetProportional(playerid, AdvancedHud[playerid][4], 1);
	PlayerTextDrawSetSelectable(playerid, AdvancedHud[playerid][4], 0);

	AdvancedHud[playerid][5] = CreatePlayerTextDraw(playerid, 315.000000, 429.000000, "ld_dual:white");
	PlayerTextDrawFont(playerid, AdvancedHud[playerid][5], 4);
	PlayerTextDrawLetterSize(playerid, AdvancedHud[playerid][5], 0.600000, 2.000000);
	PlayerTextDrawTextSize(playerid, AdvancedHud[playerid][5], 14.000000, 16.500000);
	PlayerTextDrawSetOutline(playerid, AdvancedHud[playerid][5], 1);
	PlayerTextDrawSetShadow(playerid, AdvancedHud[playerid][5], 0);
	PlayerTextDrawAlignment(playerid, AdvancedHud[playerid][5], 1);
	PlayerTextDrawColor(playerid, AdvancedHud[playerid][5], 201);
	PlayerTextDrawBackgroundColor(playerid, AdvancedHud[playerid][5], 255);
	PlayerTextDrawBoxColor(playerid, AdvancedHud[playerid][5], -1094795726);
	PlayerTextDrawUseBox(playerid, AdvancedHud[playerid][5], 1);
	PlayerTextDrawSetProportional(playerid, AdvancedHud[playerid][5], 1);
	PlayerTextDrawSetSelectable(playerid, AdvancedHud[playerid][5], 0);

	AdvancedHud[playerid][9] = CreatePlayerTextDraw(playerid, 280.000000, 427.000000, "mdl-2003:health_logo");
	PlayerTextDrawFont(playerid, AdvancedHud[playerid][9], 4);
	PlayerTextDrawLetterSize(playerid, AdvancedHud[playerid][9], 0.600000, 2.000000);
	PlayerTextDrawTextSize(playerid, AdvancedHud[playerid][9], 19.500000, 19.500000);
	PlayerTextDrawSetOutline(playerid, AdvancedHud[playerid][9], 1);
	PlayerTextDrawSetShadow(playerid, AdvancedHud[playerid][9], 0);
	PlayerTextDrawAlignment(playerid, AdvancedHud[playerid][9], 1);
	PlayerTextDrawColor(playerid, AdvancedHud[playerid][9], -1);
	PlayerTextDrawBackgroundColor(playerid, AdvancedHud[playerid][9], 255);
	PlayerTextDrawBoxColor(playerid, AdvancedHud[playerid][9], 50);
	PlayerTextDrawUseBox(playerid, AdvancedHud[playerid][9], 1);
	PlayerTextDrawSetProportional(playerid, AdvancedHud[playerid][9], 1);
	PlayerTextDrawSetSelectable(playerid, AdvancedHud[playerid][9], 0);

	AdvancedHud[playerid][6] = CreatePlayerTextDraw(playerid, 300.000000, 443.000000, "ld_dual:white");
	PlayerTextDrawFont(playerid, AdvancedHud[playerid][6], 4);
	PlayerTextDrawLetterSize(playerid, AdvancedHud[playerid][6], 0.600000, 2.000000);
	PlayerTextDrawTextSize(playerid, AdvancedHud[playerid][6], 10.500000, 1.500000);
	PlayerTextDrawSetOutline(playerid, AdvancedHud[playerid][6], 1);
	PlayerTextDrawSetShadow(playerid, AdvancedHud[playerid][6], 0);
	PlayerTextDrawAlignment(playerid, AdvancedHud[playerid][6], 1);
	PlayerTextDrawColor(playerid, AdvancedHud[playerid][6], 9109759);
	PlayerTextDrawBackgroundColor(playerid, AdvancedHud[playerid][6], 255);
	PlayerTextDrawBoxColor(playerid, AdvancedHud[playerid][6], -1094795726);
	PlayerTextDrawUseBox(playerid, AdvancedHud[playerid][6], 1);
	PlayerTextDrawSetProportional(playerid, AdvancedHud[playerid][6], 1);
	PlayerTextDrawSetSelectable(playerid, AdvancedHud[playerid][6], 0);

	AdvancedHud[playerid][7] = CreatePlayerTextDraw(playerid, 317.000000, 443.000000, "ld_dual:white");
	PlayerTextDrawFont(playerid, AdvancedHud[playerid][7], 4);
	PlayerTextDrawLetterSize(playerid, AdvancedHud[playerid][7], 0.600000, 2.000000);
	PlayerTextDrawTextSize(playerid, AdvancedHud[playerid][7], 10.000000, 1.500000);
	PlayerTextDrawSetOutline(playerid, AdvancedHud[playerid][7], 1);
	PlayerTextDrawSetShadow(playerid, AdvancedHud[playerid][7], 0);
	PlayerTextDrawAlignment(playerid, AdvancedHud[playerid][7], 1);
	PlayerTextDrawColor(playerid, AdvancedHud[playerid][7], 9145343);
	PlayerTextDrawBackgroundColor(playerid, AdvancedHud[playerid][7], 255);
	PlayerTextDrawBoxColor(playerid, AdvancedHud[playerid][7], -1094795726);
	PlayerTextDrawUseBox(playerid, AdvancedHud[playerid][7], 1);
	PlayerTextDrawSetProportional(playerid, AdvancedHud[playerid][7], 1);
	PlayerTextDrawSetSelectable(playerid, AdvancedHud[playerid][7], 0);

	AdvancedHud[playerid][10] = CreatePlayerTextDraw(playerid, 325.000000, 423.000000, "mdl-2004:burger_logo");
	PlayerTextDrawFont(playerid, AdvancedHud[playerid][10], 4);
	PlayerTextDrawLetterSize(playerid, AdvancedHud[playerid][10], 0.600000, 2.000000);
	PlayerTextDrawTextSize(playerid, AdvancedHud[playerid][10], 22.500000, 26.000000);
	PlayerTextDrawSetOutline(playerid, AdvancedHud[playerid][10], 1);
	PlayerTextDrawSetShadow(playerid, AdvancedHud[playerid][10], 0);
	PlayerTextDrawAlignment(playerid, AdvancedHud[playerid][10], 1);
	PlayerTextDrawColor(playerid, AdvancedHud[playerid][10], -1);
	PlayerTextDrawBackgroundColor(playerid, AdvancedHud[playerid][10], 255);
	PlayerTextDrawBoxColor(playerid, AdvancedHud[playerid][10], 50);
	PlayerTextDrawUseBox(playerid, AdvancedHud[playerid][10], 1);
	PlayerTextDrawSetProportional(playerid, AdvancedHud[playerid][10], 1);
	PlayerTextDrawSetSelectable(playerid, AdvancedHud[playerid][10], 0);

	AdvancedHud[playerid][11] = CreatePlayerTextDraw(playerid, 308.500000, 425.000000, "mdl-2008:thirst_logo");
	PlayerTextDrawFont(playerid, AdvancedHud[playerid][11], 4);
	PlayerTextDrawLetterSize(playerid, AdvancedHud[playerid][11], 0.600000, 2.000000);
	PlayerTextDrawTextSize(playerid, AdvancedHud[playerid][11], 25.500000, 23.000000);
	PlayerTextDrawSetOutline(playerid, AdvancedHud[playerid][11], 1);
	PlayerTextDrawSetShadow(playerid, AdvancedHud[playerid][11], 0);
	PlayerTextDrawAlignment(playerid, AdvancedHud[playerid][11], 1);
	PlayerTextDrawColor(playerid, AdvancedHud[playerid][11], -1);
	PlayerTextDrawBackgroundColor(playerid, AdvancedHud[playerid][11], 255);
	PlayerTextDrawBoxColor(playerid, AdvancedHud[playerid][11], 50);
	PlayerTextDrawUseBox(playerid, AdvancedHud[playerid][11], 1);
	PlayerTextDrawSetProportional(playerid, AdvancedHud[playerid][11], 1);
	PlayerTextDrawSetSelectable(playerid, AdvancedHud[playerid][11], 0);

	AdvancedHud[playerid][8] = CreatePlayerTextDraw(playerid, 332.000000, 443.000000, "ld_dual:white");
	PlayerTextDrawFont(playerid, AdvancedHud[playerid][8], 4);
	PlayerTextDrawLetterSize(playerid, AdvancedHud[playerid][8], 0.600000, 2.000000);
	PlayerTextDrawTextSize(playerid, AdvancedHud[playerid][8], 10.500000, 1.500000);
	PlayerTextDrawSetOutline(playerid, AdvancedHud[playerid][8], 1);
	PlayerTextDrawSetShadow(playerid, AdvancedHud[playerid][8], 0);
	PlayerTextDrawAlignment(playerid, AdvancedHud[playerid][8], 1);
	PlayerTextDrawColor(playerid, AdvancedHud[playerid][8], -1421536257);
	PlayerTextDrawBackgroundColor(playerid, AdvancedHud[playerid][8], 255);
	PlayerTextDrawBoxColor(playerid, AdvancedHud[playerid][8], -1094795726);
	PlayerTextDrawUseBox(playerid, AdvancedHud[playerid][8], 1);
	PlayerTextDrawSetProportional(playerid, AdvancedHud[playerid][8], 1);
	PlayerTextDrawSetSelectable(playerid, AdvancedHud[playerid][8], 0);

	HealthBar[playerid] = CreatePlayerTextDraw(playerid, 285.000000, 443.000000, "ld_dual:white");
	PlayerTextDrawFont(playerid, HealthBar[playerid], 4);
	PlayerTextDrawLetterSize(playerid, HealthBar[playerid], 0.600000, 2.000000);
	PlayerTextDrawTextSize(playerid, HealthBar[playerid], 10.000000, 1.500000);
	PlayerTextDrawSetOutline(playerid, HealthBar[playerid], 1);
	PlayerTextDrawSetShadow(playerid, HealthBar[playerid], 0);
	PlayerTextDrawAlignment(playerid, HealthBar[playerid], 1);
	PlayerTextDrawColor(playerid, HealthBar[playerid], -469234433);
	PlayerTextDrawBackgroundColor(playerid, HealthBar[playerid], 255);
	PlayerTextDrawBoxColor(playerid, HealthBar[playerid], -1094795726);
	PlayerTextDrawUseBox(playerid, HealthBar[playerid], 1);
	PlayerTextDrawSetProportional(playerid, HealthBar[playerid], 1);
	PlayerTextDrawSetSelectable(playerid, HealthBar[playerid], 0);

	ArmorBar[playerid] = CreatePlayerTextDraw(playerid, 300.000000, 443.000000, "ld_dual:white");
	PlayerTextDrawFont(playerid, ArmorBar[playerid], 4);
	PlayerTextDrawLetterSize(playerid, ArmorBar[playerid], 0.600000, 2.000000);
	PlayerTextDrawTextSize(playerid, ArmorBar[playerid], 10.000000, 1.500000);
	PlayerTextDrawSetOutline(playerid, ArmorBar[playerid], 1);
	PlayerTextDrawSetShadow(playerid, ArmorBar[playerid], 0);
	PlayerTextDrawAlignment(playerid, ArmorBar[playerid], 1);
	PlayerTextDrawColor(playerid, ArmorBar[playerid], 13369599);
	PlayerTextDrawBackgroundColor(playerid, ArmorBar[playerid], 255);
	PlayerTextDrawBoxColor(playerid, ArmorBar[playerid], -1094795726);
	PlayerTextDrawUseBox(playerid, ArmorBar[playerid], 1);
	PlayerTextDrawSetProportional(playerid, ArmorBar[playerid], 1);
	PlayerTextDrawSetSelectable(playerid, ArmorBar[playerid], 0);

	Thirst[playerid] = CreatePlayerTextDraw(playerid, 317.000000, 443.000000, "ld_dual:white");
	PlayerTextDrawFont(playerid, Thirst[playerid], 4);
	PlayerTextDrawLetterSize(playerid, Thirst[playerid], 0.600000, 2.000000);
	PlayerTextDrawTextSize(playerid, Thirst[playerid], 10.000000, 1.500000);
	PlayerTextDrawSetOutline(playerid, Thirst[playerid], 1);
	PlayerTextDrawSetShadow(playerid, Thirst[playerid], 0);
	PlayerTextDrawAlignment(playerid, Thirst[playerid], 1);
	PlayerTextDrawColor(playerid, Thirst[playerid], -2016478465);
	PlayerTextDrawBackgroundColor(playerid, Thirst[playerid], 255);
	PlayerTextDrawBoxColor(playerid, Thirst[playerid], -1094795726);
	PlayerTextDrawUseBox(playerid, Thirst[playerid], 1);
	PlayerTextDrawSetProportional(playerid, Thirst[playerid], 1);
	PlayerTextDrawSetSelectable(playerid, Thirst[playerid], 0);

	Hunger[playerid] = CreatePlayerTextDraw(playerid, 333.000000, 443.000000, "ld_dual:white");
	PlayerTextDrawFont(playerid, Hunger[playerid], 4);
	PlayerTextDrawLetterSize(playerid, Hunger[playerid], 0.600000, 2.000000);
	PlayerTextDrawTextSize(playerid, Hunger[playerid], 10.000000, 1.500000);
	PlayerTextDrawSetOutline(playerid, Hunger[playerid], 1);
	PlayerTextDrawSetShadow(playerid, Hunger[playerid], 0);
	PlayerTextDrawAlignment(playerid, Hunger[playerid], 1);
	PlayerTextDrawColor(playerid, Hunger[playerid], -764862721);
	PlayerTextDrawBackgroundColor(playerid, Hunger[playerid], 255);
	PlayerTextDrawBoxColor(playerid, Hunger[playerid], -1094795726);
	PlayerTextDrawUseBox(playerid, Hunger[playerid], 1);
	PlayerTextDrawSetProportional(playerid, Hunger[playerid], 1);
	PlayerTextDrawSetSelectable(playerid, Hunger[playerid], 0);

	AdvancedHud[playerid][12] = CreatePlayerTextDraw(playerid, 296.000000, 427.000000, "mdl-2006:armour_logo");
	PlayerTextDrawFont(playerid, AdvancedHud[playerid][12], 4);
	PlayerTextDrawLetterSize(playerid, AdvancedHud[playerid][12], 0.600000, 2.000000);
	PlayerTextDrawTextSize(playerid, AdvancedHud[playerid][12], 18.500000, 17.000000);
	PlayerTextDrawSetOutline(playerid, AdvancedHud[playerid][12], 1);
	PlayerTextDrawSetShadow(playerid, AdvancedHud[playerid][12], 0);
	PlayerTextDrawAlignment(playerid, AdvancedHud[playerid][12], 1);
	PlayerTextDrawColor(playerid, AdvancedHud[playerid][12], -1);
	PlayerTextDrawBackgroundColor(playerid, AdvancedHud[playerid][12], 255);
	PlayerTextDrawBoxColor(playerid, AdvancedHud[playerid][12], 50);
	PlayerTextDrawUseBox(playerid, AdvancedHud[playerid][12], 1);
	PlayerTextDrawSetProportional(playerid, AdvancedHud[playerid][12], 1);
	PlayerTextDrawSetSelectable(playerid, AdvancedHud[playerid][12], 0);
	return 1;
}

AndroidGUI(playerid)
{
	AdvancedHud[playerid][0] = CreatePlayerTextDraw(playerid, 313.500000, 429.000000, "_");
	PlayerTextDrawFont(playerid, AdvancedHud[playerid][0], 1);
	PlayerTextDrawLetterSize(playerid, AdvancedHud[playerid][0], 0.012500, -0.399996);
	PlayerTextDrawTextSize(playerid, AdvancedHud[playerid][0], 300.500000, 61.000000);
	PlayerTextDrawSetOutline(playerid, AdvancedHud[playerid][0], 1);
	PlayerTextDrawSetShadow(playerid, AdvancedHud[playerid][0], 0);
	PlayerTextDrawAlignment(playerid, AdvancedHud[playerid][0], 2);
	PlayerTextDrawColor(playerid, AdvancedHud[playerid][0], -1);
	PlayerTextDrawBackgroundColor(playerid, AdvancedHud[playerid][0], 255);
	PlayerTextDrawBoxColor(playerid, AdvancedHud[playerid][0], 135);
	PlayerTextDrawUseBox(playerid, AdvancedHud[playerid][0], 1);
	PlayerTextDrawSetProportional(playerid, AdvancedHud[playerid][0], 1);
	PlayerTextDrawSetSelectable(playerid, AdvancedHud[playerid][0], 0);

	AdvancedHud[playerid][1] = CreatePlayerTextDraw(playerid, 330.000000, 429.000000, "ld_dual:white");
	PlayerTextDrawFont(playerid, AdvancedHud[playerid][1], 4);
	PlayerTextDrawLetterSize(playerid, AdvancedHud[playerid][1], 0.600000, 2.000000);
	PlayerTextDrawTextSize(playerid, AdvancedHud[playerid][1], 14.000000, 16.500000);
	PlayerTextDrawSetOutline(playerid, AdvancedHud[playerid][1], 1);
	PlayerTextDrawSetShadow(playerid, AdvancedHud[playerid][1], 0);
	PlayerTextDrawAlignment(playerid, AdvancedHud[playerid][1], 1);
	PlayerTextDrawColor(playerid, AdvancedHud[playerid][1], 201);
	PlayerTextDrawBackgroundColor(playerid, AdvancedHud[playerid][1], 255);
	PlayerTextDrawBoxColor(playerid, AdvancedHud[playerid][1], -1094795726);
	PlayerTextDrawUseBox(playerid, AdvancedHud[playerid][1], 1);
	PlayerTextDrawSetProportional(playerid, AdvancedHud[playerid][1], 1);
	PlayerTextDrawSetSelectable(playerid, AdvancedHud[playerid][1], 0);

	AdvancedHud[playerid][2] = CreatePlayerTextDraw(playerid, 283.000000, 429.000000, "ld_dual:white");
	PlayerTextDrawFont(playerid, AdvancedHud[playerid][2], 4);
	PlayerTextDrawLetterSize(playerid, AdvancedHud[playerid][2], 0.600000, 2.000000);
	PlayerTextDrawTextSize(playerid, AdvancedHud[playerid][2], 14.000000, 16.500000);
	PlayerTextDrawSetOutline(playerid, AdvancedHud[playerid][2], 1);
	PlayerTextDrawSetShadow(playerid, AdvancedHud[playerid][2], 0);
	PlayerTextDrawAlignment(playerid, AdvancedHud[playerid][2], 1);
	PlayerTextDrawColor(playerid, AdvancedHud[playerid][2], 201);
	PlayerTextDrawBackgroundColor(playerid, AdvancedHud[playerid][2], 255);
	PlayerTextDrawBoxColor(playerid, AdvancedHud[playerid][2], -1094795726);
	PlayerTextDrawUseBox(playerid, AdvancedHud[playerid][2], 1);
	PlayerTextDrawSetProportional(playerid, AdvancedHud[playerid][2], 1);
	PlayerTextDrawSetSelectable(playerid, AdvancedHud[playerid][2], 0);

	AdvancedHud[playerid][3] = CreatePlayerTextDraw(playerid, 333.000000, 438.000000, "ld_dual:white");
	PlayerTextDrawFont(playerid, AdvancedHud[playerid][3], 4);
	PlayerTextDrawLetterSize(playerid, AdvancedHud[playerid][3], 0.600000, 2.000000);
	PlayerTextDrawTextSize(playerid, AdvancedHud[playerid][3], 8.000000, 1.500000);
	PlayerTextDrawSetOutline(playerid, AdvancedHud[playerid][3], 1);
	PlayerTextDrawSetShadow(playerid, AdvancedHud[playerid][3], 0);
	PlayerTextDrawAlignment(playerid, AdvancedHud[playerid][3], 1);
	PlayerTextDrawColor(playerid, AdvancedHud[playerid][3], -1);
	PlayerTextDrawBackgroundColor(playerid, AdvancedHud[playerid][3], 255);
	PlayerTextDrawBoxColor(playerid, AdvancedHud[playerid][3], -1094795726);
	PlayerTextDrawUseBox(playerid, AdvancedHud[playerid][3], 1);
	PlayerTextDrawSetProportional(playerid, AdvancedHud[playerid][3], 1);
	PlayerTextDrawSetSelectable(playerid, AdvancedHud[playerid][3], 0);

	AdvancedHud[playerid][4] = CreatePlayerTextDraw(playerid, 333.000000, 435.000000, "ld_dual:white");
	PlayerTextDrawFont(playerid, AdvancedHud[playerid][4], 4);
	PlayerTextDrawLetterSize(playerid, AdvancedHud[playerid][4], 0.600000, 2.000000);
	PlayerTextDrawTextSize(playerid, AdvancedHud[playerid][4], 8.000000, 0.500000);
	PlayerTextDrawSetOutline(playerid, AdvancedHud[playerid][4], 1);
	PlayerTextDrawSetShadow(playerid, AdvancedHud[playerid][4], 0);
	PlayerTextDrawAlignment(playerid, AdvancedHud[playerid][4], 1);
	PlayerTextDrawColor(playerid, AdvancedHud[playerid][4], -1);
	PlayerTextDrawBackgroundColor(playerid, AdvancedHud[playerid][4], 255);
	PlayerTextDrawBoxColor(playerid, AdvancedHud[playerid][4], -1094795726);
	PlayerTextDrawUseBox(playerid, AdvancedHud[playerid][4], 1);
	PlayerTextDrawSetProportional(playerid, AdvancedHud[playerid][4], 1);
	PlayerTextDrawSetSelectable(playerid, AdvancedHud[playerid][4], 0);

	AdvancedHud[playerid][5] = CreatePlayerTextDraw(playerid, 332.500000, 432.000000, "ld_beat:chit");
	PlayerTextDrawFont(playerid, AdvancedHud[playerid][5], 4);
	PlayerTextDrawLetterSize(playerid, AdvancedHud[playerid][5], 0.600000, 2.000000);
	PlayerTextDrawTextSize(playerid, AdvancedHud[playerid][5], 3.000000, 4.500000);
	PlayerTextDrawSetOutline(playerid, AdvancedHud[playerid][5], 1);
	PlayerTextDrawSetShadow(playerid, AdvancedHud[playerid][5], 0);
	PlayerTextDrawAlignment(playerid, AdvancedHud[playerid][5], 1);
	PlayerTextDrawColor(playerid, AdvancedHud[playerid][5], -1);
	PlayerTextDrawBackgroundColor(playerid, AdvancedHud[playerid][5], 255);
	PlayerTextDrawBoxColor(playerid, AdvancedHud[playerid][5], 50);
	PlayerTextDrawUseBox(playerid, AdvancedHud[playerid][5], 1);
	PlayerTextDrawSetProportional(playerid, AdvancedHud[playerid][5], 1);
	PlayerTextDrawSetSelectable(playerid, AdvancedHud[playerid][5], 0);

	AdvancedHud[playerid][6] = CreatePlayerTextDraw(playerid, 333.500000, 431.000000, "ld_beat:chit");
	PlayerTextDrawFont(playerid, AdvancedHud[playerid][6], 4);
	PlayerTextDrawLetterSize(playerid, AdvancedHud[playerid][6], 0.600000, 2.000000);
	PlayerTextDrawTextSize(playerid, AdvancedHud[playerid][6], 4.000000, 5.500000);
	PlayerTextDrawSetOutline(playerid, AdvancedHud[playerid][6], 1);
	PlayerTextDrawSetShadow(playerid, AdvancedHud[playerid][6], 0);
	PlayerTextDrawAlignment(playerid, AdvancedHud[playerid][6], 1);
	PlayerTextDrawColor(playerid, AdvancedHud[playerid][6], -1);
	PlayerTextDrawBackgroundColor(playerid, AdvancedHud[playerid][6], 255);
	PlayerTextDrawBoxColor(playerid, AdvancedHud[playerid][6], 50);
	PlayerTextDrawUseBox(playerid, AdvancedHud[playerid][6], 1);
	PlayerTextDrawSetProportional(playerid, AdvancedHud[playerid][6], 1);
	PlayerTextDrawSetSelectable(playerid, AdvancedHud[playerid][6], 0);

	AdvancedHud[playerid][7] = CreatePlayerTextDraw(playerid, 285.000000, 443.000000, "ld_dual:white");
	PlayerTextDrawFont(playerid, AdvancedHud[playerid][7], 4);
	PlayerTextDrawLetterSize(playerid, AdvancedHud[playerid][7], 0.600000, 2.000000);
	PlayerTextDrawTextSize(playerid, AdvancedHud[playerid][7], 10.500000, 1.500000);
	PlayerTextDrawSetOutline(playerid, AdvancedHud[playerid][7], 1);
	PlayerTextDrawSetShadow(playerid, AdvancedHud[playerid][7], 0);
	PlayerTextDrawAlignment(playerid, AdvancedHud[playerid][7], 1);
	PlayerTextDrawColor(playerid, AdvancedHud[playerid][7], -1962934017);
	PlayerTextDrawBackgroundColor(playerid, AdvancedHud[playerid][7], 255);
	PlayerTextDrawBoxColor(playerid, AdvancedHud[playerid][7], -1094795726);
	PlayerTextDrawUseBox(playerid, AdvancedHud[playerid][7], 1);
	PlayerTextDrawSetProportional(playerid, AdvancedHud[playerid][7], 1);
	PlayerTextDrawSetSelectable(playerid, AdvancedHud[playerid][7], 0);

	AdvancedHud[playerid][8] = CreatePlayerTextDraw(playerid, 286.000000, 431.000000, "ld_beat:chit");
	PlayerTextDrawFont(playerid, AdvancedHud[playerid][8], 4);
	PlayerTextDrawLetterSize(playerid, AdvancedHud[playerid][8], 0.600000, 2.000000);
	PlayerTextDrawTextSize(playerid, AdvancedHud[playerid][8], 7.000000, 5.500000);
	PlayerTextDrawSetOutline(playerid, AdvancedHud[playerid][8], 1);
	PlayerTextDrawSetShadow(playerid, AdvancedHud[playerid][8], 0);
	PlayerTextDrawAlignment(playerid, AdvancedHud[playerid][8], 1);
	PlayerTextDrawColor(playerid, AdvancedHud[playerid][8], -1);
	PlayerTextDrawBackgroundColor(playerid, AdvancedHud[playerid][8], 255);
	PlayerTextDrawBoxColor(playerid, AdvancedHud[playerid][8], 50);
	PlayerTextDrawUseBox(playerid, AdvancedHud[playerid][8], 1);
	PlayerTextDrawSetProportional(playerid, AdvancedHud[playerid][8], 1);
	PlayerTextDrawSetSelectable(playerid, AdvancedHud[playerid][8], 0);

	AdvancedHud[playerid][9] = CreatePlayerTextDraw(playerid, 298.000000, 429.000000, "ld_dual:white");
	PlayerTextDrawFont(playerid, AdvancedHud[playerid][9], 4);
	PlayerTextDrawLetterSize(playerid, AdvancedHud[playerid][9], 0.600000, 2.000000);
	PlayerTextDrawTextSize(playerid, AdvancedHud[playerid][9], 14.000000, 16.500000);
	PlayerTextDrawSetOutline(playerid, AdvancedHud[playerid][9], 1);
	PlayerTextDrawSetShadow(playerid, AdvancedHud[playerid][9], 0);
	PlayerTextDrawAlignment(playerid, AdvancedHud[playerid][9], 1);
	PlayerTextDrawColor(playerid, AdvancedHud[playerid][9], 201);
	PlayerTextDrawBackgroundColor(playerid, AdvancedHud[playerid][9], 255);
	PlayerTextDrawBoxColor(playerid, AdvancedHud[playerid][9], -1094795726);
	PlayerTextDrawUseBox(playerid, AdvancedHud[playerid][9], 1);
	PlayerTextDrawSetProportional(playerid, AdvancedHud[playerid][9], 1);
	PlayerTextDrawSetSelectable(playerid, AdvancedHud[playerid][9], 0);

	AdvancedHud[playerid][10] = CreatePlayerTextDraw(playerid, 315.000000, 429.000000, "ld_dual:white");
	PlayerTextDrawFont(playerid, AdvancedHud[playerid][10], 4);
	PlayerTextDrawLetterSize(playerid, AdvancedHud[playerid][10], 0.600000, 2.000000);
	PlayerTextDrawTextSize(playerid, AdvancedHud[playerid][10], 14.000000, 16.500000);
	PlayerTextDrawSetOutline(playerid, AdvancedHud[playerid][10], 1);
	PlayerTextDrawSetShadow(playerid, AdvancedHud[playerid][10], 0);
	PlayerTextDrawAlignment(playerid, AdvancedHud[playerid][10], 1);
	PlayerTextDrawColor(playerid, AdvancedHud[playerid][10], 201);
	PlayerTextDrawBackgroundColor(playerid, AdvancedHud[playerid][10], 255);
	PlayerTextDrawBoxColor(playerid, AdvancedHud[playerid][10], -1094795726);
	PlayerTextDrawUseBox(playerid, AdvancedHud[playerid][10], 1);
	PlayerTextDrawSetProportional(playerid, AdvancedHud[playerid][10], 1);
	PlayerTextDrawSetSelectable(playerid, AdvancedHud[playerid][10], 0);

	AdvancedHud[playerid][11] = CreatePlayerTextDraw(playerid, 301.000000, 429.000000, "Y");
	PlayerTextDrawFont(playerid, AdvancedHud[playerid][11], 1);
	PlayerTextDrawLetterSize(playerid, AdvancedHud[playerid][11], 0.408329, 1.549996);
	PlayerTextDrawTextSize(playerid, AdvancedHud[playerid][11], 400.000000, 17.000000);
	PlayerTextDrawSetOutline(playerid, AdvancedHud[playerid][11], 0);
	PlayerTextDrawSetShadow(playerid, AdvancedHud[playerid][11], 0);
	PlayerTextDrawAlignment(playerid, AdvancedHud[playerid][11], 1);
	PlayerTextDrawColor(playerid, AdvancedHud[playerid][11], -1);
	PlayerTextDrawBackgroundColor(playerid, AdvancedHud[playerid][11], 255);
	PlayerTextDrawBoxColor(playerid, AdvancedHud[playerid][11], 50);
	PlayerTextDrawUseBox(playerid, AdvancedHud[playerid][11], 0);
	PlayerTextDrawSetProportional(playerid, AdvancedHud[playerid][11], 1);
	PlayerTextDrawSetSelectable(playerid, AdvancedHud[playerid][11], 0);

	AdvancedHud[playerid][12] = CreatePlayerTextDraw(playerid, 317.000000, 432.000000, "ld_beat:chit");
	PlayerTextDrawFont(playerid, AdvancedHud[playerid][12], 4);
	PlayerTextDrawLetterSize(playerid, AdvancedHud[playerid][12], 0.600000, 2.000000);
	PlayerTextDrawTextSize(playerid, AdvancedHud[playerid][12], 8.500000, 10.500000);
	PlayerTextDrawSetOutline(playerid, AdvancedHud[playerid][12], 1);
	PlayerTextDrawSetShadow(playerid, AdvancedHud[playerid][12], 0);
	PlayerTextDrawAlignment(playerid, AdvancedHud[playerid][12], 1);
	PlayerTextDrawColor(playerid, AdvancedHud[playerid][12], -1);
	PlayerTextDrawBackgroundColor(playerid, AdvancedHud[playerid][12], 255);
	PlayerTextDrawBoxColor(playerid, AdvancedHud[playerid][12], -1094795726);
	PlayerTextDrawUseBox(playerid, AdvancedHud[playerid][12], 1);
	PlayerTextDrawSetProportional(playerid, AdvancedHud[playerid][12], 1);
	PlayerTextDrawSetSelectable(playerid, AdvancedHud[playerid][12], 0);

	AdvancedHud[playerid][13] = CreatePlayerTextDraw(playerid, 327.000000, 427.000000, "c");
	PlayerTextDrawFont(playerid, AdvancedHud[playerid][13], 1);
	PlayerTextDrawLetterSize(playerid, AdvancedHud[playerid][13], -0.266663, 1.449998);
	PlayerTextDrawTextSize(playerid, AdvancedHud[playerid][13], 400.000000, 17.000000);
	PlayerTextDrawSetOutline(playerid, AdvancedHud[playerid][13], 0);
	PlayerTextDrawSetShadow(playerid, AdvancedHud[playerid][13], 0);
	PlayerTextDrawAlignment(playerid, AdvancedHud[playerid][13], 1);
	PlayerTextDrawColor(playerid, AdvancedHud[playerid][13], -1);
	PlayerTextDrawBackgroundColor(playerid, AdvancedHud[playerid][13], 255);
	PlayerTextDrawBoxColor(playerid, AdvancedHud[playerid][13], 50);
	PlayerTextDrawUseBox(playerid, AdvancedHud[playerid][13], 0);
	PlayerTextDrawSetProportional(playerid, AdvancedHud[playerid][13], 1);
	PlayerTextDrawSetSelectable(playerid, AdvancedHud[playerid][13], 0);

	AdvancedHud[playerid][14] = CreatePlayerTextDraw(playerid, 318.000000, 432.000000, "ld_dual:white");
	PlayerTextDrawFont(playerid, AdvancedHud[playerid][14], 4);
	PlayerTextDrawLetterSize(playerid, AdvancedHud[playerid][14], 0.600000, 2.000000);
	PlayerTextDrawTextSize(playerid, AdvancedHud[playerid][14], 6.500000, 5.000000);
	PlayerTextDrawSetOutline(playerid, AdvancedHud[playerid][14], 1);
	PlayerTextDrawSetShadow(playerid, AdvancedHud[playerid][14], 0);
	PlayerTextDrawAlignment(playerid, AdvancedHud[playerid][14], 1);
	PlayerTextDrawColor(playerid, AdvancedHud[playerid][14], -1);
	PlayerTextDrawBackgroundColor(playerid, AdvancedHud[playerid][14], 255);
	PlayerTextDrawBoxColor(playerid, AdvancedHud[playerid][14], -1094795726);
	PlayerTextDrawUseBox(playerid, AdvancedHud[playerid][14], 1);
	PlayerTextDrawSetProportional(playerid, AdvancedHud[playerid][14], 1);
	PlayerTextDrawSetSelectable(playerid, AdvancedHud[playerid][14], 0);

	AdvancedHud[playerid][15] = CreatePlayerTextDraw(playerid, 300.000000, 443.000000, "ld_dual:white");
	PlayerTextDrawFont(playerid, AdvancedHud[playerid][15], 4);
	PlayerTextDrawLetterSize(playerid, AdvancedHud[playerid][15], 0.600000, 2.000000);
	PlayerTextDrawTextSize(playerid, AdvancedHud[playerid][15], 10.500000, 1.500000);
	PlayerTextDrawSetOutline(playerid, AdvancedHud[playerid][15], 1);
	PlayerTextDrawSetShadow(playerid, AdvancedHud[playerid][15], 0);
	PlayerTextDrawAlignment(playerid, AdvancedHud[playerid][15], 1);
	PlayerTextDrawColor(playerid, AdvancedHud[playerid][15], 9109759);
	PlayerTextDrawBackgroundColor(playerid, AdvancedHud[playerid][15], 255);
	PlayerTextDrawBoxColor(playerid, AdvancedHud[playerid][15], -1094795726);
	PlayerTextDrawUseBox(playerid, AdvancedHud[playerid][15], 1);
	PlayerTextDrawSetProportional(playerid, AdvancedHud[playerid][15], 1);
	PlayerTextDrawSetSelectable(playerid, AdvancedHud[playerid][15], 0);

	AdvancedHud[playerid][16] = CreatePlayerTextDraw(playerid, 317.000000, 443.000000, "ld_dual:white");
	PlayerTextDrawFont(playerid, AdvancedHud[playerid][16], 4);
	PlayerTextDrawLetterSize(playerid, AdvancedHud[playerid][16], 0.600000, 2.000000);
	PlayerTextDrawTextSize(playerid, AdvancedHud[playerid][16], 10.000000, 1.500000);
	PlayerTextDrawSetOutline(playerid, AdvancedHud[playerid][16], 1);
	PlayerTextDrawSetShadow(playerid, AdvancedHud[playerid][16], 0);
	PlayerTextDrawAlignment(playerid, AdvancedHud[playerid][16], 1);
	PlayerTextDrawColor(playerid, AdvancedHud[playerid][16], 3394815);
	PlayerTextDrawBackgroundColor(playerid, AdvancedHud[playerid][16], 255);
	PlayerTextDrawBoxColor(playerid, AdvancedHud[playerid][16], -1094795726);
	PlayerTextDrawUseBox(playerid, AdvancedHud[playerid][16], 1);
	PlayerTextDrawSetProportional(playerid, AdvancedHud[playerid][16], 1);
	PlayerTextDrawSetSelectable(playerid, AdvancedHud[playerid][16], 0);

	AdvancedHud[playerid][17] = CreatePlayerTextDraw(playerid, 335.000000, 431.000000, "ld_beat:chit");
	PlayerTextDrawFont(playerid, AdvancedHud[playerid][17], 4);
	PlayerTextDrawLetterSize(playerid, AdvancedHud[playerid][17], 0.600000, 2.000000);
	PlayerTextDrawTextSize(playerid, AdvancedHud[playerid][17], 4.000000, 4.000000);
	PlayerTextDrawSetOutline(playerid, AdvancedHud[playerid][17], 1);
	PlayerTextDrawSetShadow(playerid, AdvancedHud[playerid][17], 0);
	PlayerTextDrawAlignment(playerid, AdvancedHud[playerid][17], 1);
	PlayerTextDrawColor(playerid, AdvancedHud[playerid][17], -1);
	PlayerTextDrawBackgroundColor(playerid, AdvancedHud[playerid][17], 255);
	PlayerTextDrawBoxColor(playerid, AdvancedHud[playerid][17], 50);
	PlayerTextDrawUseBox(playerid, AdvancedHud[playerid][17], 1);
	PlayerTextDrawSetProportional(playerid, AdvancedHud[playerid][17], 1);
	PlayerTextDrawSetSelectable(playerid, AdvancedHud[playerid][17], 0);

	AdvancedHud[playerid][18] = CreatePlayerTextDraw(playerid, 337.000000, 432.000000, "ld_beat:chit");
	PlayerTextDrawFont(playerid, AdvancedHud[playerid][18], 4);
	PlayerTextDrawLetterSize(playerid, AdvancedHud[playerid][18], 0.600000, 2.000000);
	PlayerTextDrawTextSize(playerid, AdvancedHud[playerid][18], 4.000000, 4.000000);
	PlayerTextDrawSetOutline(playerid, AdvancedHud[playerid][18], 1);
	PlayerTextDrawSetShadow(playerid, AdvancedHud[playerid][18], 0);
	PlayerTextDrawAlignment(playerid, AdvancedHud[playerid][18], 1);
	PlayerTextDrawColor(playerid, AdvancedHud[playerid][18], -1);
	PlayerTextDrawBackgroundColor(playerid, AdvancedHud[playerid][18], 255);
	PlayerTextDrawBoxColor(playerid, AdvancedHud[playerid][18], 50);
	PlayerTextDrawUseBox(playerid, AdvancedHud[playerid][18], 1);
	PlayerTextDrawSetProportional(playerid, AdvancedHud[playerid][18], 1);
	PlayerTextDrawSetSelectable(playerid, AdvancedHud[playerid][18], 0);

	AdvancedHud[playerid][19] = CreatePlayerTextDraw(playerid, 339.000000, 433.000000, "ld_beat:chit");
	PlayerTextDrawFont(playerid, AdvancedHud[playerid][19], 4);
	PlayerTextDrawLetterSize(playerid, AdvancedHud[playerid][19], 0.600000, 2.000000);
	PlayerTextDrawTextSize(playerid, AdvancedHud[playerid][19], 2.500000, 3.000000);
	PlayerTextDrawSetOutline(playerid, AdvancedHud[playerid][19], 1);
	PlayerTextDrawSetShadow(playerid, AdvancedHud[playerid][19], 0);
	PlayerTextDrawAlignment(playerid, AdvancedHud[playerid][19], 1);
	PlayerTextDrawColor(playerid, AdvancedHud[playerid][19], -1);
	PlayerTextDrawBackgroundColor(playerid, AdvancedHud[playerid][19], 255);
	PlayerTextDrawBoxColor(playerid, AdvancedHud[playerid][19], 50);
	PlayerTextDrawUseBox(playerid, AdvancedHud[playerid][19], 1);
	PlayerTextDrawSetProportional(playerid, AdvancedHud[playerid][19], 1);
	PlayerTextDrawSetSelectable(playerid, AdvancedHud[playerid][19], 0);

	AdvancedHud[playerid][20] = CreatePlayerTextDraw(playerid, 333.000000, 436.500000, "ld_dual:white");
	PlayerTextDrawFont(playerid, AdvancedHud[playerid][20], 4);
	PlayerTextDrawLetterSize(playerid, AdvancedHud[playerid][20], 0.600000, 2.000000);
	PlayerTextDrawTextSize(playerid, AdvancedHud[playerid][20], 8.000000, 0.500000);
	PlayerTextDrawSetOutline(playerid, AdvancedHud[playerid][20], 1);
	PlayerTextDrawSetShadow(playerid, AdvancedHud[playerid][20], 0);
	PlayerTextDrawAlignment(playerid, AdvancedHud[playerid][20], 1);
	PlayerTextDrawColor(playerid, AdvancedHud[playerid][20], -1);
	PlayerTextDrawBackgroundColor(playerid, AdvancedHud[playerid][20], 255);
	PlayerTextDrawBoxColor(playerid, AdvancedHud[playerid][20], -1094795726);
	PlayerTextDrawUseBox(playerid, AdvancedHud[playerid][20], 1);
	PlayerTextDrawSetProportional(playerid, AdvancedHud[playerid][20], 1);
	PlayerTextDrawSetSelectable(playerid, AdvancedHud[playerid][20], 0);

	AdvancedHud[playerid][21] = CreatePlayerTextDraw(playerid, 332.000000, 443.000000, "ld_dual:white");
	PlayerTextDrawFont(playerid, AdvancedHud[playerid][21], 4);
	PlayerTextDrawLetterSize(playerid, AdvancedHud[playerid][21], 0.600000, 2.000000);
	PlayerTextDrawTextSize(playerid, AdvancedHud[playerid][21], 10.500000, 1.500000);
	PlayerTextDrawSetOutline(playerid, AdvancedHud[playerid][21], 1);
	PlayerTextDrawSetShadow(playerid, AdvancedHud[playerid][21], 0);
	PlayerTextDrawAlignment(playerid, AdvancedHud[playerid][21], 1);
	PlayerTextDrawColor(playerid, AdvancedHud[playerid][21], -1421536257);
	PlayerTextDrawBackgroundColor(playerid, AdvancedHud[playerid][21], 255);
	PlayerTextDrawBoxColor(playerid, AdvancedHud[playerid][21], -1094795726);
	PlayerTextDrawUseBox(playerid, AdvancedHud[playerid][21], 1);
	PlayerTextDrawSetProportional(playerid, AdvancedHud[playerid][21], 1);
	PlayerTextDrawSetSelectable(playerid, AdvancedHud[playerid][21], 0);

	AdvancedHud[playerid][22] = CreatePlayerTextDraw(playerid, 285.000000, 435.000000, "ld_beat:chit");
	PlayerTextDrawFont(playerid, AdvancedHud[playerid][22], 4);
	PlayerTextDrawLetterSize(playerid, AdvancedHud[playerid][22], 0.600000, 2.000000);
	PlayerTextDrawTextSize(playerid, AdvancedHud[playerid][22], 9.500000, 6.500000);
	PlayerTextDrawSetOutline(playerid, AdvancedHud[playerid][22], 1);
	PlayerTextDrawSetShadow(playerid, AdvancedHud[playerid][22], 0);
	PlayerTextDrawAlignment(playerid, AdvancedHud[playerid][22], 1);
	PlayerTextDrawColor(playerid, AdvancedHud[playerid][22], -1);
	PlayerTextDrawBackgroundColor(playerid, AdvancedHud[playerid][22], 255);
	PlayerTextDrawBoxColor(playerid, AdvancedHud[playerid][22], 50);
	PlayerTextDrawUseBox(playerid, AdvancedHud[playerid][22], 1);
	PlayerTextDrawSetProportional(playerid, AdvancedHud[playerid][22], 1);
	PlayerTextDrawSetSelectable(playerid, AdvancedHud[playerid][22], 0);

	HealthBar[playerid] = CreatePlayerTextDraw(playerid, 285.000000, 443.000000, "ld_dual:white");
	PlayerTextDrawFont(playerid, HealthBar[playerid], 4);
	PlayerTextDrawLetterSize(playerid, HealthBar[playerid], 0.600000, 2.000000);
	PlayerTextDrawTextSize(playerid, HealthBar[playerid], 10.000000, 1.500000);
	PlayerTextDrawSetOutline(playerid, HealthBar[playerid], 1);
	PlayerTextDrawSetShadow(playerid, HealthBar[playerid], 0);
	PlayerTextDrawAlignment(playerid, HealthBar[playerid], 1);
	PlayerTextDrawColor(playerid, HealthBar[playerid], -469234433);
	PlayerTextDrawBackgroundColor(playerid, HealthBar[playerid], 255);
	PlayerTextDrawBoxColor(playerid, HealthBar[playerid], -1094795726);
	PlayerTextDrawUseBox(playerid, HealthBar[playerid], 1);
	PlayerTextDrawSetProportional(playerid, HealthBar[playerid], 1);
	PlayerTextDrawSetSelectable(playerid, HealthBar[playerid], 0);

	ArmorBar[playerid] = CreatePlayerTextDraw(playerid, 300.000000, 443.000000, "ld_dual:white");
	PlayerTextDrawFont(playerid, ArmorBar[playerid], 4);
	PlayerTextDrawLetterSize(playerid, ArmorBar[playerid], 0.600000, 2.000000);
	PlayerTextDrawTextSize(playerid, ArmorBar[playerid], 10.000000, 1.500000);
	PlayerTextDrawSetOutline(playerid, ArmorBar[playerid], 1);
	PlayerTextDrawSetShadow(playerid, ArmorBar[playerid], 0);
	PlayerTextDrawAlignment(playerid, ArmorBar[playerid], 1);
	PlayerTextDrawColor(playerid, ArmorBar[playerid], 13369599);
	PlayerTextDrawBackgroundColor(playerid, ArmorBar[playerid], 255);
	PlayerTextDrawBoxColor(playerid, ArmorBar[playerid], -1094795726);
	PlayerTextDrawUseBox(playerid, ArmorBar[playerid], 1);
	PlayerTextDrawSetProportional(playerid, ArmorBar[playerid], 1);
	PlayerTextDrawSetSelectable(playerid, ArmorBar[playerid], 0);

	Thirst[playerid] = CreatePlayerTextDraw(playerid, 317.000000, 443.000000, "ld_dual:white");
	PlayerTextDrawFont(playerid, Thirst[playerid], 4);
	PlayerTextDrawLetterSize(playerid, Thirst[playerid], 0.600000, 2.000000);
	PlayerTextDrawTextSize(playerid, Thirst[playerid], 10.000000, 1.500000);
	PlayerTextDrawSetOutline(playerid, Thirst[playerid], 1);
	PlayerTextDrawSetShadow(playerid, Thirst[playerid], 0);
	PlayerTextDrawAlignment(playerid, Thirst[playerid], 1);
	PlayerTextDrawColor(playerid, Thirst[playerid], 1097458175);
	PlayerTextDrawBackgroundColor(playerid, Thirst[playerid], 255);
	PlayerTextDrawBoxColor(playerid, Thirst[playerid], -1094795726);
	PlayerTextDrawUseBox(playerid, Thirst[playerid], 1);
	PlayerTextDrawSetProportional(playerid, Thirst[playerid], 1);
	PlayerTextDrawSetSelectable(playerid, Thirst[playerid], 0);

	Hunger[playerid] = CreatePlayerTextDraw(playerid, 333.000000, 443.000000, "ld_dual:white");
	PlayerTextDrawFont(playerid, Hunger[playerid], 4);
	PlayerTextDrawLetterSize(playerid, Hunger[playerid], 0.600000, 2.000000);
	PlayerTextDrawTextSize(playerid, Hunger[playerid], 10.000000, 1.500000);
	PlayerTextDrawSetOutline(playerid, Hunger[playerid], 1);
	PlayerTextDrawSetShadow(playerid, Hunger[playerid], 0);
	PlayerTextDrawAlignment(playerid, Hunger[playerid], 1);
	PlayerTextDrawColor(playerid, Hunger[playerid], -764862721);
	PlayerTextDrawBackgroundColor(playerid, Hunger[playerid], 255);
	PlayerTextDrawBoxColor(playerid, Hunger[playerid], -1094795726);
	PlayerTextDrawUseBox(playerid, Hunger[playerid], 1);
	PlayerTextDrawSetProportional(playerid, Hunger[playerid], 1);
	PlayerTextDrawSetSelectable(playerid, Hunger[playerid], 0);

	AdvancedHud[playerid][23] = CreatePlayerTextDraw(playerid, 303.000000, 434.000000, "ld_dual:white");
	PlayerTextDrawFont(playerid, AdvancedHud[playerid][23], 4);
	PlayerTextDrawLetterSize(playerid, AdvancedHud[playerid][23], 0.600000, 2.000000);
	PlayerTextDrawTextSize(playerid, AdvancedHud[playerid][23], 5.000000, 7.000000);
	PlayerTextDrawSetOutline(playerid, AdvancedHud[playerid][23], 1);
	PlayerTextDrawSetShadow(playerid, AdvancedHud[playerid][23], 0);
	PlayerTextDrawAlignment(playerid, AdvancedHud[playerid][23], 1);
	PlayerTextDrawColor(playerid, AdvancedHud[playerid][23], -1);
	PlayerTextDrawBackgroundColor(playerid, AdvancedHud[playerid][23], 255);
	PlayerTextDrawBoxColor(playerid, AdvancedHud[playerid][23], -1094795726);
	PlayerTextDrawUseBox(playerid, AdvancedHud[playerid][23], 1);
	PlayerTextDrawSetProportional(playerid, AdvancedHud[playerid][23], 1);
	PlayerTextDrawSetSelectable(playerid, AdvancedHud[playerid][23], 0);
	return 1;
}

//android
ShowAndroidGUI(playerid)
{
    for(new i = 0; i < 24; i++)
	{
		PlayerTextDrawShow(playerid, AdvancedHud[playerid][i]);
	}
	PlayerTextDrawShow(playerid, HealthBar[playerid]);
	PlayerTextDrawShow(playerid, ArmorBar[playerid]);
	PlayerTextDrawShow(playerid, Thirst[playerid]);
	PlayerTextDrawShow(playerid, Hunger[playerid]);
    return 1;
}

HideAndroidGUI(playerid)
{
	PlayerTextDrawHide(playerid, HealthBar[playerid]);
	PlayerTextDrawHide(playerid, ArmorBar[playerid]);
	PlayerTextDrawHide(playerid, Thirst[playerid]);
	PlayerTextDrawHide(playerid, Hunger[playerid]);
	for(new i = 0; i < 24; i++ )
	{
		PlayerTextDrawHide(playerid, AdvancedHud[playerid][i]);
	}
    return 1;
}

//pc
ShowPcGUI(playerid)
{
    for(new i = 0; i < 13; i++)
	{
		PlayerTextDrawShow(playerid, AdvancedHud[playerid][i]);
	}
	PlayerTextDrawShow(playerid, HealthBar[playerid]);
	PlayerTextDrawShow(playerid, ArmorBar[playerid]);
	PlayerTextDrawShow(playerid, Thirst[playerid]);
	PlayerTextDrawShow(playerid, Hunger[playerid]);
    return 1;
}

//Hide
HidePcGUI(playerid)
{
	PlayerTextDrawHide(playerid, HealthBar[playerid]);
	PlayerTextDrawHide(playerid, ArmorBar[playerid]);
	PlayerTextDrawHide(playerid, Thirst[playerid]);
	PlayerTextDrawHide(playerid, Hunger[playerid]);
	for(new i = 0; i < 13; i++ )
	{
		PlayerTextDrawHide(playerid, AdvancedHud[playerid][i]);
	}
    return 1;
}

CMD:hudstyle(playerid, params[])
{
	Dialog_Show(playerid, HUDSTYLE, DIALOG_STYLE_LIST, "Hud Style", "Advanced\n"COL_RED"Disable", "Select", "Close");
	return 1;
}

Dialog:HUDSTYLE(playerid, response, listitem, inputtext[])
{
	if(response)
	{
		if(GetPlayerState(playerid) == PLAYER_STATE_DRIVER)
		{
			if(listitem == 0)
			{
				if(Device[playerid] == CLIENT_TYPE_PC)
                {
                    SpeedometerPCHide(playerid);
                }
                else
                {
                    SpeedometerAndroidHide(playerid);
                }
			}
			else
			{
				if(Device[playerid] == CLIENT_TYPE_PC)
                {
                    SpeedometerPCShow(playerid);
                }
                else
                {
                    SpeedometerAndroidShow(playerid);
                }
			}
		}

		switch(listitem)
		{
			case 0:
			{
				if(Device[playerid] == CLIENT_TYPE_PC)
                {
                    ShowPcGUI(playerid);
                }
                else
                {
                    ShowAndroidGUI(playerid);
                }
				SendServerMessage(playerid, "You change your hud style to "LIGHTBLUE"Advanced");
			}
			case 1:
			{
				if(Device[playerid] == CLIENT_TYPE_PC)
                {
                    HidePcGUI(playerid);
                }
                else
                {
                    HideAndroidGUI(playerid);
                }
				SendServerMessage(playerid, "HUD "COL_RED"Disable");
			}
		}
		PlayerData[playerid][pHudStyle] = listitem;
	}
	return 1;
}