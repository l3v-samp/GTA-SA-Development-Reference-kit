new Text:TextInv[27], PlayerText:TextInvP[MAX_PLAYERS][50];

new OpenedInventory[MAX_PLAYERS], SlotItemSelected[MAX_PLAYERS], ItemSelected[MAX_PLAYERS], CurrentPage[MAX_PLAYERS], SelectedPage[MAX_PLAYERS], MenuSelected[MAX_PLAYERS];
new AccSelected[MAX_PLAYERS], SlotAccSelected[MAX_PLAYERS], Flooder[MAX_PLAYERS];

enum I_VEHICLE_DATA
{
    VehicleModel,
    VehicleState,
    VehicleInsurance,
    VehiclePosX,
    VehiclePosY,
    VehiclePosZ
}

new iVehicleData[MAX_PLAYERS][5][I_VEHICLE_DATA], VehicleSelected[MAX_PLAYERS];

stock Inv_GetPlayerItem(playerid)
{
    new item; if(PlayerData[playerid][pBackpack] == 0) item = 15; else if(PlayerData[playerid][pBackpack] == 1) item = 30; else if(PlayerData[playerid][pBackpack] == 2) item = 45;
    return item;
}

stock Inventory_Clear(playerid)
{
    for (new i = 0; i < Inv_GetPlayerItem(playerid); i ++)
    {
        if(InventoryData[playerid][i][invModel] > 0)
        {
            InventoryData[playerid][i][invModel] = 0;
            InventoryData[playerid][i][invQuantity] = 0;
            InventoryData[playerid][i][invItem] = EOS;
        }
    }
    return 1;
}

stock Inventory_Set(playerid, item[], model, amount)
{
    new itemid = Inventory_GetItemID(playerid, item);

    if(itemid == -1 && amount > 0)
        Inventory_Add(playerid, item, model, amount);

    else if(amount > 0 && itemid != -1)
        Inventory_SetQuantity(playerid, item, amount);

    else if(amount < 1 && itemid != -1)
        Inventory_Remove(playerid, item, -1);

    return 1;
}

Inventory_GetItemID(playerid, item[])
{
    for (new i = 0; i < Inv_GetPlayerItem(playerid); i ++)
    {
        if(InventoryData[playerid][i][invItem] == EOS)
            continue;

        if(!strcmp(InventoryData[playerid][i][invItem], item)) return i;
    }
    return -1;
}

Inventory_GetFreeID(playerid)
{
    new total;
    if((total = Inventory_Items(playerid)) >= Inv_GetPlayerItem(playerid))
    {
        SendErrorMessage(playerid, "Your inventory is full! you have %d items inside your inventory!", total);
        return -1;
    }
    else
    {
    	for (new i = 0; i < Inv_GetPlayerItem(playerid); i ++)
	    {
	        if(InventoryData[playerid][i][invItem] == EOS)
	        return i;
	    }
	}
    return -1;
}

static Inventory_Items(playerid)
{
    new count;

    for (new i = 0; i != Inv_GetPlayerItem(playerid); i ++) if(InventoryData[playerid][i][invModel] > 0) {
        count++;
    }
    return count;
}

stock Inventory_Count(playerid, item[])
{
    new itemid = Inventory_GetItemID(playerid, item);

    if(itemid != -1)
        return InventoryData[playerid][itemid][invQuantity];

    return 0;
}

stock Inventory_HasItem(playerid, item[])
{
    return (Inventory_GetItemID(playerid, item) != -1);
}

stock Inventory_SetQuantity(playerid, item[], quantity)
{
    new
        itemid = Inventory_GetItemID(playerid, item);

    if(itemid != -1)
    {
        InventoryData[playerid][itemid][invQuantity] = quantity;
    }
    return 1;
}

stock Inventory_MaxCount(item[])
{
    for (new i = 0; i < sizeof(g_aInventoryItems); i ++) if(!strcmp(g_aInventoryItems[i][e_InventoryItem], item, true)) {
        return g_aInventoryItems[i][e_InventoryMax];
    }
    return 0;
}

stock Inventory_Add(playerid, item[], model, quantity = 1)
{
    new
        itemid = Inventory_GetItemID(playerid, item);

    if(PlayerData[playerid][pLoadedInv] == false)
        return SendErrorMessage(playerid, "Kamu belum memiliki tas, belilah terlebih dahulu!");

    for (new i = 0; i < sizeof(g_aInventoryItems); i ++) if(!strcmp(g_aInventoryItems[i][e_InventoryItem], item, true))
    {
        if((Inventory_Count(playerid, g_aInventoryItems[i][e_InventoryItem]) + quantity) > g_aInventoryItems[i][e_InventoryMax])
        {
            SendErrorMessage(playerid, "Item %s dibatasi sebanyak %d item!.", item, g_aInventoryItems[i][e_InventoryMax]);
            return -1;
        }
    }
    if(itemid == -1)
    {
        itemid = Inventory_GetFreeID(playerid);
        if(itemid != -1)
        {
            InventoryData[playerid][itemid][invModel] = model;
            InventoryData[playerid][itemid][invQuantity] = quantity;

            strpack(InventoryData[playerid][itemid][invItem], item, 32 char);

            return itemid;
        }
        return -1;
    }
    else
    {
        InventoryData[playerid][itemid][invQuantity] += quantity;
    }
    return itemid;
}

stock Inventory_Remove(playerid, item[], quantity = 1)
{
    new
        itemid = Inventory_GetItemID(playerid, item);

    if(PlayerData[playerid][pLoadedInv] == false)
        return SendErrorMessage(playerid, "Database tidak ditemukan, lapor staff/report bug");

    if(itemid != -1)
    {
    	if(OpenedInventory[playerid] == 1)
        {
            PlayerPlaySound(playerid, 6400, 0, 0, 0);
            InventoryGlobalGUI(playerid, false);
            InventoryGUI(playerid, false);
        }
        if(InventoryData[playerid][itemid][invQuantity] > 0)
        {
            InventoryData[playerid][itemid][invQuantity] -= quantity;
        }
        if(quantity == -1 || InventoryData[playerid][itemid][invQuantity] < 1)
        {
            InventoryData[playerid][itemid][invModel] = 0;
            InventoryData[playerid][itemid][invQuantity] = 0;
            InventoryData[playerid][itemid][invItem] = EOS;
        }
        else if(quantity != -1 && InventoryData[playerid][itemid][invQuantity] > 0)
        {
        	InventoryData[playerid][itemid][invQuantity] -= quantity;
        }
        return 1;
    }
    return 0;
}

Function:EatingPizza(playerid)
{
    if(PlayerData[playerid][pEatingTime] < 64)
    {
        PlayerData[playerid][pEatingTime] += 0.5;
        return 1;
    }
    else if(PlayerData[playerid][pEatingTime] >= 64)
    {
        SetPlayerHunger(playerid, PlayerData[playerid][pHunger]+12);
        Inventory_Remove(playerid, "Cooked Pizza");
        KillTimer(PlayerData[playerid][pEatingTime]);
    }
    return 1;
}

Function:OnPlayerUseInvItem(playerid, itemid, name[])
{	
    if(!strcmp(name, "Fish Rod", true)) {
        cmd_fish(playerid, "\1");
    }
/*    else if(!strcmp(name, "Magazine", true)) {
        cmd_usemag(playerid, "\1");
    }*/
/*    else if(!strcmp(name, "Backpack", true)) {
        cmd_backpack(playerid, "\1");
    }*/
    // else if(!strcmp(name, "First Aid", true)) {
    //     cmd_usekit(playerid, "\1");
    // }
    else if(!strcmp(name, "Fuel Can", true)) {
        cmd_fill(playerid, "\1");
    }
    else if(!strcmp(name, "Cellphone", true)) {
        cmd_phone(playerid, "\1");
    }
    else if(!strcmp(name, "Portable Radio", true)) {
        cmd_setfreq(playerid, "\1");
    }
    else if(!strcmp(name, "GPS System", true)) {
        cmd_gps(playerid, "\1");
    }
    else if(!strcmp(name, "Marijuana", true)) {
        cmd_usedrug(playerid, "marijuana");
    }
    else if(!strcmp(name, "Cocaine", true)) {
        cmd_usedrug(playerid, "cocaine");
    }
    else if(!strcmp(name, "Heroin", true)) {
        cmd_usedrug(playerid, "heroin");
    }
    else if(!strcmp(name, "LSD", true)) {
        cmd_usedrug(playerid, "lsd");
    }
    else if(!strcmp(name, "Ecstasy", true)) {
        cmd_usedrug(playerid, "ecs");
    }
    // else if(!strcmp(name, "Steroids", true)) {
    //     cmd_usedrug(playerid, "steroids");
    // }
    else if(!strcmp(name, "Frozen Pizza", true)) {
        cmd_cook(playerid, "pizza");
    }
    else if(!strcmp(name, "Frozen Burger", true)) {
        cmd_cook(playerid, "burger");
    }
    else if(!strcmp(name, "Armored Vest", true)) {
        cmd_vest(playerid, "\1");
    }
/*    else if(!strcmp(name, "Ammo Cartridge", true)) {
        cmd_ammo(playerid, "\1");
    }*/
/*    else if(!strcmp(name, "Colt 45", true)) {
        EquipWeapon(playerid, "Colt 45");
    }
    else if(!strcmp(name, "Desert Eagle", true)) {
        EquipWeapon(playerid, "Desert Eagle");
    }
    else if(!strcmp(name, "Shotgun", true)) {
        EquipWeapon(playerid, "Shotgun");
    }
    else if(!strcmp(name, "Micro SMG", true)) {
        EquipWeapon(playerid, "Micro SMG");
    }
    else if(!strcmp(name, "Tec-9", true)) {
        EquipWeapon(playerid, "Tec-9");
    }
    else if(!strcmp(name, "MP5", true)) {
        EquipWeapon(playerid, "MP5");
    }
    else if(!strcmp(name, "AK-47", true)) {
        EquipWeapon(playerid, "AK-47");
    }
    else if(!strcmp(name, "Rifle", true)) {
        EquipWeapon(playerid, "Rifle");
    }
    else if(!strcmp(name, "Sniper", true)) {
        EquipWeapon(playerid, "Sniper");
    }
    else if(!strcmp(name, "Golf Club", true)) {
        EquipWeapon(playerid, "Golf Club");
    }
    else if(!strcmp(name, "Knife", true)) {
        EquipWeapon(playerid, "Knife");
    }
    else if(!strcmp(name, "Shovel", true)) {
        EquipWeapon(playerid, "Shovel");
    }
    else if(!strcmp(name, "Katana", true)) {
        EquipWeapon(playerid, "Katana");
    }*/
    else if(!strcmp(name, "Marijuana Seeds", true)) {
        cmd_plant(playerid, "place 0");
    }
    else if(!strcmp(name, "Cocaine Seeds", true)) {
        cmd_plant(playerid, "place 1");
    }
    else if(!strcmp(name, "Heroin Opium Seeds", true)) {
        cmd_plant(playerid, "place 2");
    }
    //Laptop Sign
/*    else if(!strcmp(name, "Laptop", true)) {
        cmd_laptop(playerid, "");
    }*/
    else if(!strcmp(name, "Cooked Pizza", true))
    {
        if(PlayerData[playerid][pHunger] > 90)
            return SendErrorMessage(playerid, "You are not hungry right now.");//pler

        if(!IsPlayerAttachedObjectSlotUsed(playerid, WEAPON_SLOT))
        {
            SetPlayerAttachedObject(playerid, WEAPON_SLOT, 2702, 6, 0.173041, 0.049197, 0.056789, 0.000000, 274.166107, 299.057983, 1.000000, 1.000000, 1.000000);
            SetTimerEx("RemoveAttachedObject", 3000, false, "dd", playerid, WEAPON_SLOT);
        }
        
        CreatePlayerLoadingBar(playerid, 5, "Eating Pizza...");
        PlayerData[playerid][pEatingTime] = SetTimerEx("EatingPizza", 5*6, true, "d", playerid);

        ApplyAnimation(playerid, "FOOD", "EAT_Burger", 4.1, 0, 0, 0, 0, 0, 1);
        SendServerMessage(playerid, "You have takes a slice of pizza and eats it!");
    }
    else if(!strcmp(name, "Neladryl Acetate", true))
    {
        if(PlayerData[playerid][pUsePills]) return SendErrorMessage(playerid, "Tidak dapat mengkonsumsi pill sekarang, tunggu hingga %d detik lagi.", PlayerData[playerid][pUsePills]);
        if(PlayerData[playerid][pCough] < 1) return SendErrorMessage(playerid, "Anda tidak dapat mengkonsumsi pil ini.");

        Inventory_Remove(playerid, "Neladryl Acetate");
        PlayerData[playerid][pCough] --;
        PlayerData[playerid][pUsePills] = 60;
        cmd_me(playerid, sprintf("take's out %s and eat it.", name));  
    }
    else if(!strcmp(name, "Kratotamax Plus 1.0", true))
    {
        if(PlayerData[playerid][pUsePills]) return SendErrorMessage(playerid, "Tidak dapat mengkonsumsi pill sekarang, tunggu hingga %d detik lagi.", PlayerData[playerid][pUsePills]);
        if(PlayerData[playerid][pMigrainRate] < 1) return SendErrorMessage(playerid, "Anda tidak dapat mengkonsumsi pil ini.");

        Inventory_Remove(playerid, "Kratotamax Plus 1.0");
        if(++PlayerData[playerid][pMigrainUsed] >= 2)
        {
            PlayerData[playerid][pMigrainRate] --;
            PlayerData[playerid][pMigrainUsed] = 0;
        }
        PlayerData[playerid][pUsePills] = 60;
        cmd_me(playerid, sprintf("take's out %s and eat it.", name));  
    }
    else if(!strcmp(name, "Lazattavitus Extra", true))
    {
        if(PlayerData[playerid][pUsePills]) return SendErrorMessage(playerid, "Tidak dapat mengkonsumsi pill sekarang, tunggu hingga %d detik lagi.", PlayerData[playerid][pUsePills]);
        if(PlayerData[playerid][pFever] < 1) return SendErrorMessage(playerid, "Anda tidak dapat mengkonsumsi pil ini.");
        Inventory_Remove(playerid, "Lazattavitus Extra");
        if(++PlayerData[playerid][pFeverUsed] >= 2)
        {
            PlayerData[playerid][pFeverUsed] = 0;
            PlayerData[playerid][pFever] --;
        }
        PlayerData[playerid][pUsePills] = 60;
        cmd_me(playerid, sprintf("take's out %s and eat it.", name));  
    }           
    else if(!strcmp(name, "Cooked Fish", true))
    {
        if(PlayerData[playerid][pHunger] > 90)
            return SendErrorMessage(playerid, "You are not hungry right now.");

        SetPlayerHunger(playerid, PlayerData[playerid][pHunger]+30);
        Inventory_Remove(playerid, "Cooked Fish");
        ApplyAnimation(playerid, "FOOD", "EAT_Burger", 4.1, 0, 0, 0, 0, 0, 1);
        SendServerMessage(playerid, "You have takes a cooked fish and eats it!");
    }
    else if(!strcmp(name, "Water", true))
    {
        if(PlayerData[playerid][pEnergy] > 90)
            return SendErrorMessage(playerid, "You are not thirsty right now.");

        // if(!IsPlayerAttachedObjectSlotUsed(playerid, WEAPON_SLOT))
        // {
        //     SetPlayerAttachedObject(playerid, WEAPON_SLOT, 1484, 6, 0.173041, 0.049197, 0.056789, 0.000000, 274.166107, 299.057983, 1.000000, 1.000000, 1.000000);
        //     SetTimerEx("RemoveAttachedObject", 3000, false, "dd", playerid, WEAPON_SLOT);
        // }
        SetPlayerEnergy(playerid, PlayerData[playerid][pEnergy]+10);
        Inventory_Remove(playerid, "Water");
//        ApplyAnimation(playerid, "FOOD", "EAT_Burger", 4.1, 0, 0, 0, 0, 0, 1);
        SendServerMessage(playerid, "You have takes a water and drinks it!");
    }
    else if(!strcmp(name, "Snack", true))
    {
        if(PlayerData[playerid][pHunger] > 90)
            return SendErrorMessage(playerid, "You are not hungry right now.");

        if(!IsPlayerAttachedObjectSlotUsed(playerid, WEAPON_SLOT))
        {
            SetPlayerAttachedObject(playerid, WEAPON_SLOT, 2768, 6, 0.173041, 0.049197, 0.056789, 0.000000, 274.166107, 299.057983, 1.000000, 1.000000, 1.000000);
            SetTimerEx("RemoveAttachedObject", 3000, false, "dd", playerid, WEAPON_SLOT);
        }
        SetPlayerHunger(playerid, PlayerData[playerid][pHunger]+10);
        Inventory_Remove(playerid, "Snack");
        ApplyAnimation(playerid, "FOOD", "EAT_Burger", 4.1, 0, 0, 0, 0, 0, 1);
        SendServerMessage(playerid, "You have takes a snack and eats it!");
    }
    else if(!strcmp(name, "Cooked Burger", true))
    {
        if(PlayerData[playerid][pHunger] > 90)
            return SendErrorMessage(playerid, "You are not hungry right now.");

        if(!IsPlayerAttachedObjectSlotUsed(playerid, WEAPON_SLOT))
        {
            SetPlayerAttachedObject(playerid, WEAPON_SLOT, 2703, 6, 0.078287, 0.019677, -0.001004, 0.000000, 0.000000, 0.000000, 1.000000, 1.000000, 1.000000);
            SetTimerEx("RemoveAttachedObject", 3000, false, "dd", playerid, WEAPON_SLOT);
        }
        SetPlayerHunger(playerid, PlayerData[playerid][pHunger]+11);
        Inventory_Remove(playerid, "Cooked Burger");
        ApplyAnimation(playerid, "FOOD", "EAT_Burger", 4.1, 0, 0, 0, 0, 0, 1);
        SendServerMessage(playerid, "You have takes a cooked burger and eats it!");
    }
    else if(!strcmp(name, "Chicken", true))
    {
        if(PlayerData[playerid][pHunger] > 90)
            return SendErrorMessage(playerid, "You are not hungry right now.");

        if(!IsPlayerAttachedObjectSlotUsed(playerid, WEAPON_SLOT))
        {
            SetPlayerAttachedObject(playerid, WEAPON_SLOT, 2663, 6, 0.078287, 0.019677, -0.001004, 0.000000, 0.000000, 0.000000, 1.000000, 1.000000, 1.000000);
            SetTimerEx("RemoveAttachedObject", 3000, false, "dd", playerid, WEAPON_SLOT);
        }
        SetPlayerHunger(playerid, PlayerData[playerid][pHunger]+14);
        Inventory_Remove(playerid, "Chicken");
        ApplyAnimation(playerid, "VENDING", "VEND_Eat_P", 4.1, 0, 0, 0, 0, 0, 1);
        SendServerMessage(playerid, "You have takes a chicken and eats it!");
    }
    else if(!strcmp(name, "First Aid", true))
    {
        return cmd_usekit(playerid, "");
    }
    else if(!strcmp(name, "MP3 Player", true))
    {
        Dialog_Show(playerid, AudioPlayer, DIALOG_STYLE_INPUT, "MP3 Player", "Input link URL to start listening to MP3 - Masukan Off untuk mematikan lagu!", "Insert", "Close");
    }
    else if(!strcmp(name, "Cigarettes", true))
    {
        SetPlayerSpecialAction(playerid, SPECIAL_ACTION_SMOKE_CIGGY);
        cmd_me(playerid, sprintf("takes out %s and light it up using their lighter.", name));
        Inventory_Remove(playerid, "Cigarettes"); 
    }
    else if(!strcmp(name, "Bobby Pin", true))
    {
        return SendErrorMessage(playerid, "Temporary disabled");
        //cmd_lockpick(playerid,"");
    }
    else if(!strcmp(name, "Kevlar Vest", true))
    {
        if(PlayerData[playerid][pHospital] != -1 || PlayerData[playerid][pCuffed] || PlayerData[playerid][pTied] || PlayerData[playerid][pInjured] || !IsPlayerSpawned(playerid))
            return SendErrorMessage(playerid, "You can't use this command now.");

        if(!Inventory_HasItem(playerid, "Kevlar Vest"))
            return SendErrorMessage(playerid, "You don't have an kevlar vest.");

        if(GetArmour(playerid) >= 100)
            return SendErrorMessage(playerid, "You already have a full vest on.");

        SetArmour(playerid, 100.0);

        Inventory_Remove(playerid, "Kevlar Vest");
        SendNearbyMessage(playerid, 15.0, X11_PLUM, "** %s takes out a kevlar vest and puts it on.", ReturnName(playerid, 0));
    }
    return 1;
}

Inventory_Save(playerid)
{
    new name[48], query[1024], line[2024];

    strunpack(name, InventoryData[playerid][0][invItem]);
    format(query,sizeof(query),"UPDATE `inventory` SET \
    `invmodel0`='%d',`invQuantity0`='%d',`invItem0`='%s',", 
    	InventoryData[playerid][0][invModel],
        InventoryData[playerid][0][invQuantity],
        name
    );
    strcat(line, query);

    for(new itemid = 1; itemid != 29; itemid++)
	{
		strunpack(name, InventoryData[playerid][itemid][invItem]);
	    format(query,sizeof(query),"`invmodel%d`='%d',`invQuantity%d`='%d',`invItem%d`='%s',",
	        itemid,
	        InventoryData[playerid][itemid][invModel],
	        itemid,
	        InventoryData[playerid][itemid][invQuantity],
	        itemid,
	        name
	    );
	    strcat(line, query);
	}

	strunpack(name, InventoryData[playerid][29][invItem]);
	format(query,sizeof(query),"%s `invmodel29`='%d',`invQuantity29`='%d',`invItem29`='%s' WHERE `ID` = '%d'",
		query,
        InventoryData[playerid][29][invModel],
        InventoryData[playerid][29][invQuantity],
        name,
        PlayerData[playerid][pID]
    );
    strcat(line, query);

    return mysql_tquery(g_iHandle, line);
}

stock CheckLimite(item[], qttA, QttB)
{
	new result;
    if(qttA + QttB >= Inventory_MaxCount(item))
    {
        result = 0;
    }
    else
    {
        result = 1;
    }

    return result;
}

Function:InventoryGlobalGUI(playerid, bool:show) 
{
	if(show) 
	{
        switch(PlayerData[playerid][pInventoryMode])
        {
            case 1:
            {
                TextDrawBackgroundColor(TextInv[4], 0xDE1987FF);
                TextDrawBackgroundColor(TextInv[5], 0xDE1987FF);
                TextDrawBackgroundColor(TextInv[6], 0xDE1987FF);
                TextDrawColor(TextInv[9], 0xDE1987FF);
                TextDrawBackgroundColor(TextInv[9], 0xDE1987FF);
                TextDrawBoxColor(TextInv[17], 0xDE1987FF);
                TextDrawBoxColor(TextInv[18], 0xDE1987FF);
                TextDrawBackgroundColor(TextInv[19], 0xDE1987FF);
                TextDrawBackgroundColor(TextInv[20], 0xDE1987FF);
                TextDrawBackgroundColor(TextInv[21], 0xDE1987FF);
                TextDrawBackgroundColor(TextInv[22], 0xDE1987FF);
            }
            case 2:
            {
                TextDrawBackgroundColor(TextInv[4], 0xF75394FF);
                TextDrawBackgroundColor(TextInv[5], 0xF75394FF);
                TextDrawBackgroundColor(TextInv[6], 0xF75394FF);
                TextDrawColor(TextInv[9], 0xF75394FF);
                TextDrawBackgroundColor(TextInv[9], 0xF75394FF);
                TextDrawBoxColor(TextInv[17], 0xF75394FF);
                TextDrawBoxColor(TextInv[18], 0xF75394FF);
                TextDrawBackgroundColor(TextInv[19], 0xF75394FF);
                TextDrawBackgroundColor(TextInv[20], 0xF75394FF);
                TextDrawBackgroundColor(TextInv[21], 0xF75394FF);
                TextDrawBackgroundColor(TextInv[22], 0xF75394FF);
            }
            case 3:
            {
                TextDrawBackgroundColor(TextInv[4], 0x78BE21FF);
                TextDrawBackgroundColor(TextInv[5], 0x78BE21FF);
                TextDrawBackgroundColor(TextInv[6], 0x78BE21FF);
                TextDrawColor(TextInv[9], 0x78BE21FF);
                TextDrawBackgroundColor(TextInv[9], 0x78BE21FF);
                TextDrawBoxColor(TextInv[17], 0x78BE21FF);
                TextDrawBoxColor(TextInv[18], 0x78BE21FF);
                TextDrawBackgroundColor(TextInv[19], 0x78BE21FF);
                TextDrawBackgroundColor(TextInv[20], 0x78BE21FF);
                TextDrawBackgroundColor(TextInv[21], 0x78BE21FF);
                TextDrawBackgroundColor(TextInv[22], 0x78BE21FF);
            }
            case 4:
            {
                TextDrawBackgroundColor(TextInv[4], 0x6B54B6FF);
                TextDrawBackgroundColor(TextInv[5], 0x6B54B6FF);
                TextDrawBackgroundColor(TextInv[6], 0x6B54B6FF);
                TextDrawColor(TextInv[9], 0x6B54B6FF);
                TextDrawBackgroundColor(TextInv[9], 0x6B54B6FF);
                TextDrawBoxColor(TextInv[17], 0x6B54B6FF);
                TextDrawBoxColor(TextInv[18], 0x6B54B6FF);
                TextDrawBackgroundColor(TextInv[19], 0x6B54B6FF);
                TextDrawBackgroundColor(TextInv[20], 0x6B54B6FF);
                TextDrawBackgroundColor(TextInv[21], 0x6B54B6FF);
                TextDrawBackgroundColor(TextInv[22], 0x6B54B6FF);
            }
        }
		for(new t; t < 27; t++)
		{
		    TextDrawShowForPlayer(playerid, TextInv[t]);
	    }
	}
	else 
	{
		for(new t; t < 27; t++)
		{
	 		TextDrawHideForPlayer(playerid, TextInv[t]);
			//TextInv[t] = Text:-1;
	 	}
	}
	return 1;
}

Function:InventoryGUI(playerid, bool:show) 
{
	if(show) 
	{
		TextInvP[playerid][0] = CreatePlayerTextDraw(playerid, 368.500000, 308.000000, "ld_pool:ball");
		PlayerTextDrawFont(playerid, TextInvP[playerid][0], 4);
		PlayerTextDrawLetterSize(playerid, TextInvP[playerid][0], 0.600000, 2.000000);
		PlayerTextDrawTextSize(playerid, TextInvP[playerid][0], 10.000000, 10.000000);
		PlayerTextDrawSetOutline(playerid, TextInvP[playerid][0], 1);
		PlayerTextDrawSetShadow(playerid, TextInvP[playerid][0], 0);
		PlayerTextDrawAlignment(playerid, TextInvP[playerid][0], 2);
		PlayerTextDrawColor(playerid, TextInvP[playerid][0], -2071689985);
		PlayerTextDrawBackgroundColor(playerid, TextInvP[playerid][0], 255);
		PlayerTextDrawBoxColor(playerid, TextInvP[playerid][0], 50);
		PlayerTextDrawUseBox(playerid, TextInvP[playerid][0], 1);
		PlayerTextDrawSetProportional(playerid, TextInvP[playerid][0], 1);
		PlayerTextDrawSetSelectable(playerid, TextInvP[playerid][0], 1);

		TextInvP[playerid][1] = CreatePlayerTextDraw(playerid, 383.000000, 308.000000, "ld_pool:ball");
		PlayerTextDrawFont(playerid, TextInvP[playerid][1], 4);
		PlayerTextDrawLetterSize(playerid, TextInvP[playerid][1], 0.600000, 2.000000);
		PlayerTextDrawTextSize(playerid, TextInvP[playerid][1], 10.000000, 10.000000);
		PlayerTextDrawSetOutline(playerid, TextInvP[playerid][1], 1);
		PlayerTextDrawSetShadow(playerid, TextInvP[playerid][1], 0);
		PlayerTextDrawAlignment(playerid, TextInvP[playerid][1], 2);
		PlayerTextDrawColor(playerid, TextInvP[playerid][1], -2071690138);
		PlayerTextDrawBackgroundColor(playerid, TextInvP[playerid][1], 255);
		PlayerTextDrawBoxColor(playerid, TextInvP[playerid][1], 50);
		PlayerTextDrawUseBox(playerid, TextInvP[playerid][1], 1);
		PlayerTextDrawSetProportional(playerid, TextInvP[playerid][1], 1);
		PlayerTextDrawSetSelectable(playerid, TextInvP[playerid][1], 1);

		TextInvP[playerid][2] = CreatePlayerTextDraw(playerid, 398.000000, 308.000000, "ld_pool:ball");
		PlayerTextDrawFont(playerid, TextInvP[playerid][2], 4);
		PlayerTextDrawLetterSize(playerid, TextInvP[playerid][2], 0.600000, 2.000000);
		PlayerTextDrawTextSize(playerid, TextInvP[playerid][2], 10.000000, 10.500000);
		PlayerTextDrawSetOutline(playerid, TextInvP[playerid][2], 1);
		PlayerTextDrawSetShadow(playerid, TextInvP[playerid][2], 0);
		PlayerTextDrawAlignment(playerid, TextInvP[playerid][2], 2);
		PlayerTextDrawColor(playerid, TextInvP[playerid][2], -2071690206);
		PlayerTextDrawBackgroundColor(playerid, TextInvP[playerid][2], 255);
		PlayerTextDrawBoxColor(playerid, TextInvP[playerid][2], 50);
		PlayerTextDrawUseBox(playerid, TextInvP[playerid][2], 1);
		PlayerTextDrawSetProportional(playerid, TextInvP[playerid][2], 1);
		PlayerTextDrawSetSelectable(playerid, TextInvP[playerid][2], 1);

		TextInvP[playerid][3] = CreatePlayerTextDraw(playerid, 285.000000, 178.000000, "Preview_Model");
		PlayerTextDrawFont(playerid, TextInvP[playerid][3], 5);
		PlayerTextDrawLetterSize(playerid, TextInvP[playerid][3], 0.600000, 2.000000);
		PlayerTextDrawTextSize(playerid, TextInvP[playerid][3], 40.000000, 40.500000);
		PlayerTextDrawSetOutline(playerid, TextInvP[playerid][3], 0);
		PlayerTextDrawSetShadow(playerid, TextInvP[playerid][3], 0);
		PlayerTextDrawAlignment(playerid, TextInvP[playerid][3], 1);
		PlayerTextDrawColor(playerid, TextInvP[playerid][3], -1);
		PlayerTextDrawBackgroundColor(playerid, TextInvP[playerid][3], -2071690155);
		PlayerTextDrawBoxColor(playerid, TextInvP[playerid][3], 255);
		PlayerTextDrawUseBox(playerid, TextInvP[playerid][3], 0);
		PlayerTextDrawSetProportional(playerid, TextInvP[playerid][3], 1);
		PlayerTextDrawSetSelectable(playerid, TextInvP[playerid][3], 1);
		PlayerTextDrawSetPreviewModel(playerid, TextInvP[playerid][3], 0);
		PlayerTextDrawSetPreviewRot(playerid, TextInvP[playerid][3], -10.000000, 0.000000, -20.000000, 1.000000);
		PlayerTextDrawSetPreviewVehCol(playerid, TextInvP[playerid][3], 1, 1);

		TextInvP[playerid][4] = CreatePlayerTextDraw(playerid, 326.500000, 178.000000, "Preview_Model");
		PlayerTextDrawFont(playerid, TextInvP[playerid][4], 5);
		PlayerTextDrawLetterSize(playerid, TextInvP[playerid][4], 0.600000, 2.000000);
		PlayerTextDrawTextSize(playerid, TextInvP[playerid][4], 40.000000, 40.500000);
		PlayerTextDrawSetOutline(playerid, TextInvP[playerid][4], 0);
		PlayerTextDrawSetShadow(playerid, TextInvP[playerid][4], 0);
		PlayerTextDrawAlignment(playerid, TextInvP[playerid][4], 1);
		PlayerTextDrawColor(playerid, TextInvP[playerid][4], -1);
		PlayerTextDrawBackgroundColor(playerid, TextInvP[playerid][4], -2071690155);
		PlayerTextDrawBoxColor(playerid, TextInvP[playerid][4], 255);
		PlayerTextDrawUseBox(playerid, TextInvP[playerid][4], 0);
		PlayerTextDrawSetProportional(playerid, TextInvP[playerid][4], 1);
		PlayerTextDrawSetSelectable(playerid, TextInvP[playerid][4], 1);
		PlayerTextDrawSetPreviewModel(playerid, TextInvP[playerid][4], 0);
		PlayerTextDrawSetPreviewRot(playerid, TextInvP[playerid][4], -10.000000, 0.000000, -20.000000, 1.000000);
		PlayerTextDrawSetPreviewVehCol(playerid, TextInvP[playerid][4], 1, 1);

		TextInvP[playerid][5] = CreatePlayerTextDraw(playerid, 368.000000, 178.000000, "Preview_Model");
		PlayerTextDrawFont(playerid, TextInvP[playerid][5], 5);
		PlayerTextDrawLetterSize(playerid, TextInvP[playerid][5], 0.600000, 2.000000);
		PlayerTextDrawTextSize(playerid, TextInvP[playerid][5], 40.000000, 40.500000);
		PlayerTextDrawSetOutline(playerid, TextInvP[playerid][5], 0);
		PlayerTextDrawSetShadow(playerid, TextInvP[playerid][5], 0);
		PlayerTextDrawAlignment(playerid, TextInvP[playerid][5], 1);
		PlayerTextDrawColor(playerid, TextInvP[playerid][5], -1);
		PlayerTextDrawBackgroundColor(playerid, TextInvP[playerid][5], -2071690155);
		PlayerTextDrawBoxColor(playerid, TextInvP[playerid][5], 255);
		PlayerTextDrawUseBox(playerid, TextInvP[playerid][5], 0);
		PlayerTextDrawSetProportional(playerid, TextInvP[playerid][5], 1);
		PlayerTextDrawSetSelectable(playerid, TextInvP[playerid][5], 1);
		PlayerTextDrawSetPreviewModel(playerid, TextInvP[playerid][5], 0);
		PlayerTextDrawSetPreviewRot(playerid, TextInvP[playerid][5], -10.000000, 0.000000, -20.000000, 1.000000);
		PlayerTextDrawSetPreviewVehCol(playerid, TextInvP[playerid][5], 1, 1);

		TextInvP[playerid][6] = CreatePlayerTextDraw(playerid, 409.500000, 178.000000, "Preview_Model");
		PlayerTextDrawFont(playerid, TextInvP[playerid][6], 5);
		PlayerTextDrawLetterSize(playerid, TextInvP[playerid][6], 0.600000, 2.000000);
		PlayerTextDrawTextSize(playerid, TextInvP[playerid][6], 40.000000, 40.500000);
		PlayerTextDrawSetOutline(playerid, TextInvP[playerid][6], 0);
		PlayerTextDrawSetShadow(playerid, TextInvP[playerid][6], 0);
		PlayerTextDrawAlignment(playerid, TextInvP[playerid][6], 1);
		PlayerTextDrawColor(playerid, TextInvP[playerid][6], -1);
		PlayerTextDrawBackgroundColor(playerid, TextInvP[playerid][6], -2071690155);
		PlayerTextDrawBoxColor(playerid, TextInvP[playerid][6], 255);
		PlayerTextDrawUseBox(playerid, TextInvP[playerid][6], 0);
		PlayerTextDrawSetProportional(playerid, TextInvP[playerid][6], 1);
		PlayerTextDrawSetSelectable(playerid, TextInvP[playerid][6], 1);
		PlayerTextDrawSetPreviewModel(playerid, TextInvP[playerid][6], 0);
		PlayerTextDrawSetPreviewRot(playerid, TextInvP[playerid][6], -10.000000, 0.000000, -20.000000, 1.000000);
		PlayerTextDrawSetPreviewVehCol(playerid, TextInvP[playerid][6], 1, 1);

		TextInvP[playerid][7] = CreatePlayerTextDraw(playerid, 451.000000, 178.000000, "Preview_Model");
		PlayerTextDrawFont(playerid, TextInvP[playerid][7], 5);
		PlayerTextDrawLetterSize(playerid, TextInvP[playerid][7], 0.600000, 2.000000);
		PlayerTextDrawTextSize(playerid, TextInvP[playerid][7], 40.000000, 40.500000);
		PlayerTextDrawSetOutline(playerid, TextInvP[playerid][7], 0);
		PlayerTextDrawSetShadow(playerid, TextInvP[playerid][7], 0);
		PlayerTextDrawAlignment(playerid, TextInvP[playerid][7], 1);
		PlayerTextDrawColor(playerid, TextInvP[playerid][7], -1);
		PlayerTextDrawBackgroundColor(playerid, TextInvP[playerid][7], -2071690155);
		PlayerTextDrawBoxColor(playerid, TextInvP[playerid][7], 255);
		PlayerTextDrawUseBox(playerid, TextInvP[playerid][7], 0);
		PlayerTextDrawSetProportional(playerid, TextInvP[playerid][7], 1);
		PlayerTextDrawSetSelectable(playerid, TextInvP[playerid][7], 1);
		PlayerTextDrawSetPreviewModel(playerid, TextInvP[playerid][7], 0);
		PlayerTextDrawSetPreviewRot(playerid, TextInvP[playerid][7], -10.000000, 0.000000, -20.000000, 1.000000);
		PlayerTextDrawSetPreviewVehCol(playerid, TextInvP[playerid][7], 1, 1);

		TextInvP[playerid][8] = CreatePlayerTextDraw(playerid, 285.000000, 220.000000, "Preview_Model");
		PlayerTextDrawFont(playerid, TextInvP[playerid][8], 5);
		PlayerTextDrawLetterSize(playerid, TextInvP[playerid][8], 0.600000, 2.000000);
		PlayerTextDrawTextSize(playerid, TextInvP[playerid][8], 40.000000, 40.500000);
		PlayerTextDrawSetOutline(playerid, TextInvP[playerid][8], 0);
		PlayerTextDrawSetShadow(playerid, TextInvP[playerid][8], 0);
		PlayerTextDrawAlignment(playerid, TextInvP[playerid][8], 1);
		PlayerTextDrawColor(playerid, TextInvP[playerid][8], -1);
		PlayerTextDrawBackgroundColor(playerid, TextInvP[playerid][8], -2071690155);
		PlayerTextDrawBoxColor(playerid, TextInvP[playerid][8], 255);
		PlayerTextDrawUseBox(playerid, TextInvP[playerid][8], 0);
		PlayerTextDrawSetProportional(playerid, TextInvP[playerid][8], 1);
		PlayerTextDrawSetSelectable(playerid, TextInvP[playerid][8], 1);
		PlayerTextDrawSetPreviewModel(playerid, TextInvP[playerid][8], 0);
		PlayerTextDrawSetPreviewRot(playerid, TextInvP[playerid][8], -10.000000, 0.000000, -20.000000, 1.000000);
		PlayerTextDrawSetPreviewVehCol(playerid, TextInvP[playerid][8], 1, 1);

		TextInvP[playerid][9] = CreatePlayerTextDraw(playerid, 326.500000, 220.000000, "Preview_Model");
		PlayerTextDrawFont(playerid, TextInvP[playerid][9], 5);
		PlayerTextDrawLetterSize(playerid, TextInvP[playerid][9], 0.600000, 2.000000);
		PlayerTextDrawTextSize(playerid, TextInvP[playerid][9], 40.000000, 40.500000);
		PlayerTextDrawSetOutline(playerid, TextInvP[playerid][9], 0);
		PlayerTextDrawSetShadow(playerid, TextInvP[playerid][9], 0);
		PlayerTextDrawAlignment(playerid, TextInvP[playerid][9], 1);
		PlayerTextDrawColor(playerid, TextInvP[playerid][9], -1);
		PlayerTextDrawBackgroundColor(playerid, TextInvP[playerid][9], -2071690155);
		PlayerTextDrawBoxColor(playerid, TextInvP[playerid][9], 255);
		PlayerTextDrawUseBox(playerid, TextInvP[playerid][9], 0);
		PlayerTextDrawSetProportional(playerid, TextInvP[playerid][9], 1);
		PlayerTextDrawSetSelectable(playerid, TextInvP[playerid][9], 1);
		PlayerTextDrawSetPreviewModel(playerid, TextInvP[playerid][9], 0);
		PlayerTextDrawSetPreviewRot(playerid, TextInvP[playerid][9], -10.000000, 0.000000, -20.000000, 1.000000);
		PlayerTextDrawSetPreviewVehCol(playerid, TextInvP[playerid][9], 1, 1);

		TextInvP[playerid][10] = CreatePlayerTextDraw(playerid, 368.000000, 220.000000, "Preview_Model");
		PlayerTextDrawFont(playerid, TextInvP[playerid][10], 5);
		PlayerTextDrawLetterSize(playerid, TextInvP[playerid][10], 0.600000, 2.000000);
		PlayerTextDrawTextSize(playerid, TextInvP[playerid][10], 40.000000, 40.500000);
		PlayerTextDrawSetOutline(playerid, TextInvP[playerid][10], 0);
		PlayerTextDrawSetShadow(playerid, TextInvP[playerid][10], 0);
		PlayerTextDrawAlignment(playerid, TextInvP[playerid][10], 1);
		PlayerTextDrawColor(playerid, TextInvP[playerid][10], -1);
		PlayerTextDrawBackgroundColor(playerid, TextInvP[playerid][10], -2071690155);
		PlayerTextDrawBoxColor(playerid, TextInvP[playerid][10], 255);
		PlayerTextDrawUseBox(playerid, TextInvP[playerid][10], 0);
		PlayerTextDrawSetProportional(playerid, TextInvP[playerid][10], 1);
		PlayerTextDrawSetSelectable(playerid, TextInvP[playerid][10], 1);
		PlayerTextDrawSetPreviewModel(playerid, TextInvP[playerid][10], 0);
		PlayerTextDrawSetPreviewRot(playerid, TextInvP[playerid][10], -10.000000, 0.000000, -20.000000, 1.000000);
		PlayerTextDrawSetPreviewVehCol(playerid, TextInvP[playerid][10], 1, 1);

		TextInvP[playerid][11] = CreatePlayerTextDraw(playerid, 409.500000, 220.000000, "Preview_Model");
		PlayerTextDrawFont(playerid, TextInvP[playerid][11], 5);
		PlayerTextDrawLetterSize(playerid, TextInvP[playerid][11], 0.600000, 2.000000);
		PlayerTextDrawTextSize(playerid, TextInvP[playerid][11], 40.000000, 40.500000);
		PlayerTextDrawSetOutline(playerid, TextInvP[playerid][11], 0);
		PlayerTextDrawSetShadow(playerid, TextInvP[playerid][11], 0);
		PlayerTextDrawAlignment(playerid, TextInvP[playerid][11], 1);
		PlayerTextDrawColor(playerid, TextInvP[playerid][11], -1);
		PlayerTextDrawBackgroundColor(playerid, TextInvP[playerid][11], -2071690155);
		PlayerTextDrawBoxColor(playerid, TextInvP[playerid][11], 255);
		PlayerTextDrawUseBox(playerid, TextInvP[playerid][11], 0);
		PlayerTextDrawSetProportional(playerid, TextInvP[playerid][11], 1);
		PlayerTextDrawSetSelectable(playerid, TextInvP[playerid][11], 1);
		PlayerTextDrawSetPreviewModel(playerid, TextInvP[playerid][11], 0);
		PlayerTextDrawSetPreviewRot(playerid, TextInvP[playerid][11], -10.000000, 0.000000, -20.000000, 1.000000);
		PlayerTextDrawSetPreviewVehCol(playerid, TextInvP[playerid][11], 1, 1);

		TextInvP[playerid][12] = CreatePlayerTextDraw(playerid, 451.000000, 220.000000, "Preview_Model");
		PlayerTextDrawFont(playerid, TextInvP[playerid][12], 5);
		PlayerTextDrawLetterSize(playerid, TextInvP[playerid][12], 0.600000, 2.000000);
		PlayerTextDrawTextSize(playerid, TextInvP[playerid][12], 40.000000, 40.500000);
		PlayerTextDrawSetOutline(playerid, TextInvP[playerid][12], 0);
		PlayerTextDrawSetShadow(playerid, TextInvP[playerid][12], 0);
		PlayerTextDrawAlignment(playerid, TextInvP[playerid][12], 1);
		PlayerTextDrawColor(playerid, TextInvP[playerid][12], -1);
		PlayerTextDrawBackgroundColor(playerid, TextInvP[playerid][12], -2071690155);
		PlayerTextDrawBoxColor(playerid, TextInvP[playerid][12], 255);
		PlayerTextDrawUseBox(playerid, TextInvP[playerid][12], 0);
		PlayerTextDrawSetProportional(playerid, TextInvP[playerid][12], 1);
		PlayerTextDrawSetSelectable(playerid, TextInvP[playerid][12], 1);
		PlayerTextDrawSetPreviewModel(playerid, TextInvP[playerid][12], 0);
		PlayerTextDrawSetPreviewRot(playerid, TextInvP[playerid][12], -10.000000, 0.000000, -20.000000, 1.000000);
		PlayerTextDrawSetPreviewVehCol(playerid, TextInvP[playerid][12], 1, 1);

		TextInvP[playerid][13] = CreatePlayerTextDraw(playerid, 285.000000, 262.000000, "Preview_Model");
		PlayerTextDrawFont(playerid, TextInvP[playerid][13], 5);
		PlayerTextDrawLetterSize(playerid, TextInvP[playerid][13], 0.600000, 2.000000);
		PlayerTextDrawTextSize(playerid, TextInvP[playerid][13], 40.000000, 40.500000);
		PlayerTextDrawSetOutline(playerid, TextInvP[playerid][13], 0);
		PlayerTextDrawSetShadow(playerid, TextInvP[playerid][13], 0);
		PlayerTextDrawAlignment(playerid, TextInvP[playerid][13], 1);
		PlayerTextDrawColor(playerid, TextInvP[playerid][13], -1);
		PlayerTextDrawBackgroundColor(playerid, TextInvP[playerid][13], -2071690155);
		PlayerTextDrawBoxColor(playerid, TextInvP[playerid][13], 255);
		PlayerTextDrawUseBox(playerid, TextInvP[playerid][13], 0);
		PlayerTextDrawSetProportional(playerid, TextInvP[playerid][13], 1);
		PlayerTextDrawSetSelectable(playerid, TextInvP[playerid][13], 1);
		PlayerTextDrawSetPreviewModel(playerid, TextInvP[playerid][13], 0);
		PlayerTextDrawSetPreviewRot(playerid, TextInvP[playerid][13], -10.000000, 0.000000, -20.000000, 1.000000);
		PlayerTextDrawSetPreviewVehCol(playerid, TextInvP[playerid][13], 1, 1);

		TextInvP[playerid][14] = CreatePlayerTextDraw(playerid, 326.500000, 262.000000, "Preview_Model");
		PlayerTextDrawFont(playerid, TextInvP[playerid][14], 5);
		PlayerTextDrawLetterSize(playerid, TextInvP[playerid][14], 0.600000, 2.000000);
		PlayerTextDrawTextSize(playerid, TextInvP[playerid][14], 40.000000, 40.500000);
		PlayerTextDrawSetOutline(playerid, TextInvP[playerid][14], 0);
		PlayerTextDrawSetShadow(playerid, TextInvP[playerid][14], 0);
		PlayerTextDrawAlignment(playerid, TextInvP[playerid][14], 1);
		PlayerTextDrawColor(playerid, TextInvP[playerid][14], -1);
		PlayerTextDrawBackgroundColor(playerid, TextInvP[playerid][14], -2071690155);
		PlayerTextDrawBoxColor(playerid, TextInvP[playerid][14], 255);
		PlayerTextDrawUseBox(playerid, TextInvP[playerid][14], 0);
		PlayerTextDrawSetProportional(playerid, TextInvP[playerid][14], 1);
		PlayerTextDrawSetSelectable(playerid, TextInvP[playerid][14], 1);
		PlayerTextDrawSetPreviewModel(playerid, TextInvP[playerid][14], 0);
		PlayerTextDrawSetPreviewRot(playerid, TextInvP[playerid][14], -10.000000, 0.000000, -20.000000, 1.000000);
		PlayerTextDrawSetPreviewVehCol(playerid, TextInvP[playerid][14], 1, 1);

		TextInvP[playerid][15] = CreatePlayerTextDraw(playerid, 368.000000, 262.000000, "Preview_Model");
		PlayerTextDrawFont(playerid, TextInvP[playerid][15], 5);
		PlayerTextDrawLetterSize(playerid, TextInvP[playerid][15], 0.600000, 2.000000);
		PlayerTextDrawTextSize(playerid, TextInvP[playerid][15], 40.000000, 40.500000);
		PlayerTextDrawSetOutline(playerid, TextInvP[playerid][15], 0);
		PlayerTextDrawSetShadow(playerid, TextInvP[playerid][15], 0);
		PlayerTextDrawAlignment(playerid, TextInvP[playerid][15], 1);
		PlayerTextDrawColor(playerid, TextInvP[playerid][15], -1);
		PlayerTextDrawBackgroundColor(playerid, TextInvP[playerid][15], -2071690155);
		PlayerTextDrawBoxColor(playerid, TextInvP[playerid][15], 255);
		PlayerTextDrawUseBox(playerid, TextInvP[playerid][15], 0);
		PlayerTextDrawSetProportional(playerid, TextInvP[playerid][15], 1);
		PlayerTextDrawSetSelectable(playerid, TextInvP[playerid][15], 1);
		PlayerTextDrawSetPreviewModel(playerid, TextInvP[playerid][15], 0);
		PlayerTextDrawSetPreviewRot(playerid, TextInvP[playerid][15], -10.000000, 0.000000, -20.000000, 1.000000);
		PlayerTextDrawSetPreviewVehCol(playerid, TextInvP[playerid][15], 1, 1);

		TextInvP[playerid][16] = CreatePlayerTextDraw(playerid, 409.500000, 262.000000, "Preview_Model");
		PlayerTextDrawFont(playerid, TextInvP[playerid][16], 5);
		PlayerTextDrawLetterSize(playerid, TextInvP[playerid][16], 0.600000, 2.000000);
		PlayerTextDrawTextSize(playerid, TextInvP[playerid][16], 40.000000, 40.500000);
		PlayerTextDrawSetOutline(playerid, TextInvP[playerid][16], 0);
		PlayerTextDrawSetShadow(playerid, TextInvP[playerid][16], 0);
		PlayerTextDrawAlignment(playerid, TextInvP[playerid][16], 1);
		PlayerTextDrawColor(playerid, TextInvP[playerid][16], -1);
		PlayerTextDrawBackgroundColor(playerid, TextInvP[playerid][16], -2071690155);
		PlayerTextDrawBoxColor(playerid, TextInvP[playerid][16], 255);
		PlayerTextDrawUseBox(playerid, TextInvP[playerid][16], 0);
		PlayerTextDrawSetProportional(playerid, TextInvP[playerid][16], 1);
		PlayerTextDrawSetSelectable(playerid, TextInvP[playerid][16], 1);
		PlayerTextDrawSetPreviewModel(playerid, TextInvP[playerid][16], 0);
		PlayerTextDrawSetPreviewRot(playerid, TextInvP[playerid][16], -10.000000, 0.000000, -20.000000, 1.000000);
		PlayerTextDrawSetPreviewVehCol(playerid, TextInvP[playerid][16], 1, 1);

		TextInvP[playerid][17] = CreatePlayerTextDraw(playerid, 451.000000, 262.000000, "Preview_Model");
		PlayerTextDrawFont(playerid, TextInvP[playerid][17], 5);
		PlayerTextDrawLetterSize(playerid, TextInvP[playerid][17], 0.600000, 2.000000);
		PlayerTextDrawTextSize(playerid, TextInvP[playerid][17], 40.000000, 40.500000);
		PlayerTextDrawSetOutline(playerid, TextInvP[playerid][17], 0);
		PlayerTextDrawSetShadow(playerid, TextInvP[playerid][17], 0);
		PlayerTextDrawAlignment(playerid, TextInvP[playerid][17], 1);
		PlayerTextDrawColor(playerid, TextInvP[playerid][17], -1);
		PlayerTextDrawBackgroundColor(playerid, TextInvP[playerid][17], -2071690155);
		PlayerTextDrawBoxColor(playerid, TextInvP[playerid][17], 255);
		PlayerTextDrawUseBox(playerid, TextInvP[playerid][17], 0);
		PlayerTextDrawSetProportional(playerid, TextInvP[playerid][17], 1);
		PlayerTextDrawSetSelectable(playerid, TextInvP[playerid][17], 1);
		PlayerTextDrawSetPreviewModel(playerid, TextInvP[playerid][17], 0);
		PlayerTextDrawSetPreviewRot(playerid, TextInvP[playerid][17], -10.000000, 0.000000, -20.000000, 1.000000);
		PlayerTextDrawSetPreviewVehCol(playerid, TextInvP[playerid][17], 1, 1);

		TextInvP[playerid][18] = CreatePlayerTextDraw(playerid, 209.000000, 180.000000, "Jogador_Inventario");
		PlayerTextDrawFont(playerid, TextInvP[playerid][18], 1);
		PlayerTextDrawLetterSize(playerid, TextInvP[playerid][18], 0.275000, 1.500000);
		PlayerTextDrawTextSize(playerid, TextInvP[playerid][18], 400.000000, 17.000000);
		PlayerTextDrawSetOutline(playerid, TextInvP[playerid][18], 1);
		PlayerTextDrawSetShadow(playerid, TextInvP[playerid][18], 0);
		PlayerTextDrawAlignment(playerid, TextInvP[playerid][18], 2);
		PlayerTextDrawColor(playerid, TextInvP[playerid][18], -1);
		PlayerTextDrawBackgroundColor(playerid, TextInvP[playerid][18], 0);
		PlayerTextDrawBoxColor(playerid, TextInvP[playerid][18], 0);
		PlayerTextDrawUseBox(playerid, TextInvP[playerid][18], 1);
		PlayerTextDrawSetProportional(playerid, TextInvP[playerid][18], 1);
		PlayerTextDrawSetSelectable(playerid, TextInvP[playerid][18], 0);

		TextInvP[playerid][19] = CreatePlayerTextDraw(playerid, 154.000000, 196.000000, "Preview_Model");
		PlayerTextDrawFont(playerid, TextInvP[playerid][19], 5);
		PlayerTextDrawLetterSize(playerid, TextInvP[playerid][19], 0.600000, 2.000000);
		PlayerTextDrawTextSize(playerid, TextInvP[playerid][19], 112.500000, 150.000000);
		PlayerTextDrawSetOutline(playerid, TextInvP[playerid][19], 0);
		PlayerTextDrawSetShadow(playerid, TextInvP[playerid][19], 0);
		PlayerTextDrawAlignment(playerid, TextInvP[playerid][19], 1);
		PlayerTextDrawColor(playerid, TextInvP[playerid][19], -1);
		PlayerTextDrawBackgroundColor(playerid, TextInvP[playerid][19], 0);
		PlayerTextDrawBoxColor(playerid, TextInvP[playerid][19], 0);
		PlayerTextDrawUseBox(playerid, TextInvP[playerid][19], 0);
		PlayerTextDrawSetProportional(playerid, TextInvP[playerid][19], 1);
		PlayerTextDrawSetSelectable(playerid, TextInvP[playerid][19], 0);
		PlayerTextDrawSetPreviewModel(playerid, TextInvP[playerid][19], 5);
		PlayerTextDrawSetPreviewRot(playerid, TextInvP[playerid][19], -10.000000, 0.000000, -20.000000, 1.000000);
		PlayerTextDrawSetPreviewVehCol(playerid, TextInvP[playerid][19], 1, 1);

		TextInvP[playerid][20] = CreatePlayerTextDraw(playerid, 143.000000, 207.000000, "Preview_Model");
		PlayerTextDrawFont(playerid, TextInvP[playerid][20], 5);
		PlayerTextDrawLetterSize(playerid, TextInvP[playerid][20], 0.600000, 2.000000);
		PlayerTextDrawTextSize(playerid, TextInvP[playerid][20], 30.000000, 30.000000);
		PlayerTextDrawSetOutline(playerid, TextInvP[playerid][20], 0);
		PlayerTextDrawSetShadow(playerid, TextInvP[playerid][20], 0);
		PlayerTextDrawAlignment(playerid, TextInvP[playerid][20], 1);
		PlayerTextDrawColor(playerid, TextInvP[playerid][20], -1);
		PlayerTextDrawBackgroundColor(playerid, TextInvP[playerid][20], -2071690155);
		PlayerTextDrawBoxColor(playerid, TextInvP[playerid][20], 255);
		PlayerTextDrawUseBox(playerid, TextInvP[playerid][20], 0);
		PlayerTextDrawSetProportional(playerid, TextInvP[playerid][20], 1);
		PlayerTextDrawSetSelectable(playerid, TextInvP[playerid][20], 1);
		PlayerTextDrawSetPreviewModel(playerid, TextInvP[playerid][20], 0);
		PlayerTextDrawSetPreviewRot(playerid, TextInvP[playerid][20], -10.000000, 0.000000, -20.000000, 1.000000);
		PlayerTextDrawSetPreviewVehCol(playerid, TextInvP[playerid][20], 1, 1);

		TextInvP[playerid][21] = CreatePlayerTextDraw(playerid, 143.000000, 252.000000, "Preview_Model");
		PlayerTextDrawFont(playerid, TextInvP[playerid][21], 5);
		PlayerTextDrawLetterSize(playerid, TextInvP[playerid][21], 0.600000, 2.000000);
		PlayerTextDrawTextSize(playerid, TextInvP[playerid][21], 30.000000, 30.000000);
		PlayerTextDrawSetOutline(playerid, TextInvP[playerid][21], 0);
		PlayerTextDrawSetShadow(playerid, TextInvP[playerid][21], 0);
		PlayerTextDrawAlignment(playerid, TextInvP[playerid][21], 1);
		PlayerTextDrawColor(playerid, TextInvP[playerid][21], -1);
		PlayerTextDrawBackgroundColor(playerid, TextInvP[playerid][21], -2071690155);
		PlayerTextDrawBoxColor(playerid, TextInvP[playerid][21], 255);
		PlayerTextDrawUseBox(playerid, TextInvP[playerid][21], 0);
		PlayerTextDrawSetProportional(playerid, TextInvP[playerid][21], 1);
		PlayerTextDrawSetSelectable(playerid, TextInvP[playerid][21], 1);
		PlayerTextDrawSetPreviewModel(playerid, TextInvP[playerid][21], 0);
		PlayerTextDrawSetPreviewRot(playerid, TextInvP[playerid][21], -10.000000, 0.000000, -20.000000, 1.000000);
		PlayerTextDrawSetPreviewVehCol(playerid, TextInvP[playerid][21], 1, 1);

		TextInvP[playerid][22] = CreatePlayerTextDraw(playerid, 143.000000, 297.000000, "Preview_Model");
		PlayerTextDrawFont(playerid, TextInvP[playerid][22], 5);
		PlayerTextDrawLetterSize(playerid, TextInvP[playerid][22], 0.600000, 2.000000);
		PlayerTextDrawTextSize(playerid, TextInvP[playerid][22], 30.000000, 30.000000);
		PlayerTextDrawSetOutline(playerid, TextInvP[playerid][22], 0);
		PlayerTextDrawSetShadow(playerid, TextInvP[playerid][22], 0);
		PlayerTextDrawAlignment(playerid, TextInvP[playerid][22], 1);
		PlayerTextDrawColor(playerid, TextInvP[playerid][22], -1);
		PlayerTextDrawBackgroundColor(playerid, TextInvP[playerid][22], -2071690155);
		PlayerTextDrawBoxColor(playerid, TextInvP[playerid][22], 255);
		PlayerTextDrawUseBox(playerid, TextInvP[playerid][22], 0);
		PlayerTextDrawSetProportional(playerid, TextInvP[playerid][22], 1);
		PlayerTextDrawSetSelectable(playerid, TextInvP[playerid][22], 1);
		PlayerTextDrawSetPreviewModel(playerid, TextInvP[playerid][22], 0);
		PlayerTextDrawSetPreviewRot(playerid, TextInvP[playerid][22], -10.000000, 0.000000, -20.000000, 1.000000);
		PlayerTextDrawSetPreviewVehCol(playerid, TextInvP[playerid][22], 1, 1);

		TextInvP[playerid][23] = CreatePlayerTextDraw(playerid, 245.000000, 207.000000, "Preview_Model");
		PlayerTextDrawFont(playerid, TextInvP[playerid][23], 5);
		PlayerTextDrawLetterSize(playerid, TextInvP[playerid][23], 0.600000, 2.000000);
		PlayerTextDrawTextSize(playerid, TextInvP[playerid][23], 30.000000, 30.000000);
		PlayerTextDrawSetOutline(playerid, TextInvP[playerid][23], 0);
		PlayerTextDrawSetShadow(playerid, TextInvP[playerid][23], 0);
		PlayerTextDrawAlignment(playerid, TextInvP[playerid][23], 1);
		PlayerTextDrawColor(playerid, TextInvP[playerid][23], -1);
		PlayerTextDrawBackgroundColor(playerid, TextInvP[playerid][23], -2071690155);
		PlayerTextDrawBoxColor(playerid, TextInvP[playerid][23], 255);
		PlayerTextDrawUseBox(playerid, TextInvP[playerid][23], 0);
		PlayerTextDrawSetProportional(playerid, TextInvP[playerid][23], 1);
		PlayerTextDrawSetSelectable(playerid, TextInvP[playerid][23], 1);
		PlayerTextDrawSetPreviewModel(playerid, TextInvP[playerid][23], 0);
		PlayerTextDrawSetPreviewRot(playerid, TextInvP[playerid][23], -10.000000, 0.000000, -20.000000, 1.000000);
		PlayerTextDrawSetPreviewVehCol(playerid, TextInvP[playerid][23], 1, 1);

		TextInvP[playerid][24] = CreatePlayerTextDraw(playerid, 245.000000, 252.000000, "Preview_Model");
		PlayerTextDrawFont(playerid, TextInvP[playerid][24], 5);
		PlayerTextDrawLetterSize(playerid, TextInvP[playerid][24], 0.600000, 2.000000);
		PlayerTextDrawTextSize(playerid, TextInvP[playerid][24], 30.000000, 30.000000);
		PlayerTextDrawSetOutline(playerid, TextInvP[playerid][24], 0);
		PlayerTextDrawSetShadow(playerid, TextInvP[playerid][24], 0);
		PlayerTextDrawAlignment(playerid, TextInvP[playerid][24], 1);
		PlayerTextDrawColor(playerid, TextInvP[playerid][24], -1);
		PlayerTextDrawBackgroundColor(playerid, TextInvP[playerid][24], -2071690155);
		PlayerTextDrawBoxColor(playerid, TextInvP[playerid][24], 255);
		PlayerTextDrawUseBox(playerid, TextInvP[playerid][24], 0);
		PlayerTextDrawSetProportional(playerid, TextInvP[playerid][24], 1);
		PlayerTextDrawSetSelectable(playerid, TextInvP[playerid][24], 1);
		PlayerTextDrawSetPreviewModel(playerid, TextInvP[playerid][24], 0);
		PlayerTextDrawSetPreviewRot(playerid, TextInvP[playerid][24], -10.000000, 0.000000, -20.000000, 1.000000);
		PlayerTextDrawSetPreviewVehCol(playerid, TextInvP[playerid][24], 1, 1);

		TextInvP[playerid][25] = CreatePlayerTextDraw(playerid, 245.000000, 297.000000, "Preview_Model");
		PlayerTextDrawFont(playerid, TextInvP[playerid][25], 5);
		PlayerTextDrawLetterSize(playerid, TextInvP[playerid][25], 0.600000, 2.000000);
		PlayerTextDrawTextSize(playerid, TextInvP[playerid][25], 30.000000, 30.000000);
		PlayerTextDrawSetOutline(playerid, TextInvP[playerid][25], 0);
		PlayerTextDrawSetShadow(playerid, TextInvP[playerid][25], 0);
		PlayerTextDrawAlignment(playerid, TextInvP[playerid][25], 1);
		PlayerTextDrawColor(playerid, TextInvP[playerid][25], -1);
		PlayerTextDrawBackgroundColor(playerid, TextInvP[playerid][25], -2071690155);
		PlayerTextDrawBoxColor(playerid, TextInvP[playerid][25], 255);
		PlayerTextDrawUseBox(playerid, TextInvP[playerid][25], 0);
		PlayerTextDrawSetProportional(playerid, TextInvP[playerid][25], 1);
		PlayerTextDrawSetSelectable(playerid, TextInvP[playerid][25], 1);
		PlayerTextDrawSetPreviewModel(playerid, TextInvP[playerid][25], 0);
		PlayerTextDrawSetPreviewRot(playerid, TextInvP[playerid][25], -10.000000, 0.000000, -20.000000, 1.000000);
		PlayerTextDrawSetPreviewVehCol(playerid, TextInvP[playerid][25], 1, 1);

		TextInvP[playerid][26] = CreatePlayerTextDraw(playerid, 141.000000, 342.000000, "~g~$~w~1.000.000");
		PlayerTextDrawFont(playerid, TextInvP[playerid][26], 1);
		PlayerTextDrawLetterSize(playerid, TextInvP[playerid][26], 0.187500, 1.100000);
		PlayerTextDrawTextSize(playerid, TextInvP[playerid][26], 400.000000, 17.000000);
		PlayerTextDrawSetOutline(playerid, TextInvP[playerid][26], 2);
		PlayerTextDrawSetShadow(playerid, TextInvP[playerid][26], 0);
		PlayerTextDrawAlignment(playerid, TextInvP[playerid][26], 1);
		PlayerTextDrawColor(playerid, TextInvP[playerid][26], -1);
		PlayerTextDrawBackgroundColor(playerid, TextInvP[playerid][26], 0);
		PlayerTextDrawBoxColor(playerid, TextInvP[playerid][26], 0);
		PlayerTextDrawUseBox(playerid, TextInvP[playerid][26], 1);
		PlayerTextDrawSetProportional(playerid, TextInvP[playerid][26], 1);
		PlayerTextDrawSetSelectable(playerid, TextInvP[playerid][26], 0);

		TextInvP[playerid][27] = CreatePlayerTextDraw(playerid, 277.500000, 342.000000, "~y~C ~w~900.000");
		PlayerTextDrawFont(playerid, TextInvP[playerid][27], 1);
		PlayerTextDrawLetterSize(playerid, TextInvP[playerid][27], 0.187500, 1.100000);
		PlayerTextDrawTextSize(playerid, TextInvP[playerid][27], 400.000000, 17.000000);
		PlayerTextDrawSetOutline(playerid, TextInvP[playerid][27], 2);
		PlayerTextDrawSetShadow(playerid, TextInvP[playerid][27], 0);
		PlayerTextDrawAlignment(playerid, TextInvP[playerid][27], 3);
		PlayerTextDrawColor(playerid, TextInvP[playerid][27], -1);
		PlayerTextDrawBackgroundColor(playerid, TextInvP[playerid][27], 0);
		PlayerTextDrawBoxColor(playerid, TextInvP[playerid][27], 0);
		PlayerTextDrawUseBox(playerid, TextInvP[playerid][27], 1);
		PlayerTextDrawSetProportional(playerid, TextInvP[playerid][27], 1);
		PlayerTextDrawSetSelectable(playerid, TextInvP[playerid][27], 0);

		TextInvP[playerid][28] = CreatePlayerTextDraw(playerid, 323.500000, 210.000000, "999");
		PlayerTextDrawFont(playerid, TextInvP[playerid][28], 2);
		PlayerTextDrawLetterSize(playerid, TextInvP[playerid][28], 0.129166, 0.850000);
		PlayerTextDrawTextSize(playerid, TextInvP[playerid][28], 400.000000, 17.000000);
		PlayerTextDrawSetOutline(playerid, TextInvP[playerid][28], 2);
		PlayerTextDrawSetShadow(playerid, TextInvP[playerid][28], 0);
		PlayerTextDrawAlignment(playerid, TextInvP[playerid][28], 3);
		PlayerTextDrawColor(playerid, TextInvP[playerid][28], -1);
		PlayerTextDrawBackgroundColor(playerid, TextInvP[playerid][28], 0);
		PlayerTextDrawBoxColor(playerid, TextInvP[playerid][28], 0);
		PlayerTextDrawUseBox(playerid, TextInvP[playerid][28], 1);
		PlayerTextDrawSetProportional(playerid, TextInvP[playerid][28], 1);
		PlayerTextDrawSetSelectable(playerid, TextInvP[playerid][28], 0);

		TextInvP[playerid][29] = CreatePlayerTextDraw(playerid, 365.500000, 210.000000, "999");
		PlayerTextDrawFont(playerid, TextInvP[playerid][29], 2);
		PlayerTextDrawLetterSize(playerid, TextInvP[playerid][29], 0.129166, 0.850000);
		PlayerTextDrawTextSize(playerid, TextInvP[playerid][29], 400.000000, 17.000000);
		PlayerTextDrawSetOutline(playerid, TextInvP[playerid][29], 2);
		PlayerTextDrawSetShadow(playerid, TextInvP[playerid][29], 0);
		PlayerTextDrawAlignment(playerid, TextInvP[playerid][29], 3);
		PlayerTextDrawColor(playerid, TextInvP[playerid][29], -1);
		PlayerTextDrawBackgroundColor(playerid, TextInvP[playerid][29], 0);
		PlayerTextDrawBoxColor(playerid, TextInvP[playerid][29], 0);
		PlayerTextDrawUseBox(playerid, TextInvP[playerid][29], 1);
		PlayerTextDrawSetProportional(playerid, TextInvP[playerid][29], 1);
		PlayerTextDrawSetSelectable(playerid, TextInvP[playerid][29], 0);

		TextInvP[playerid][30] = CreatePlayerTextDraw(playerid, 406.500000, 210.000000, "999");
		PlayerTextDrawFont(playerid, TextInvP[playerid][30], 2);
		PlayerTextDrawLetterSize(playerid, TextInvP[playerid][30], 0.129166, 0.850000);
		PlayerTextDrawTextSize(playerid, TextInvP[playerid][30], 400.000000, 17.000000);
		PlayerTextDrawSetOutline(playerid, TextInvP[playerid][30], 2);
		PlayerTextDrawSetShadow(playerid, TextInvP[playerid][30], 0);
		PlayerTextDrawAlignment(playerid, TextInvP[playerid][30], 3);
		PlayerTextDrawColor(playerid, TextInvP[playerid][30], -1);
		PlayerTextDrawBackgroundColor(playerid, TextInvP[playerid][30], 0);
		PlayerTextDrawBoxColor(playerid, TextInvP[playerid][30], 0);
		PlayerTextDrawUseBox(playerid, TextInvP[playerid][30], 1);
		PlayerTextDrawSetProportional(playerid, TextInvP[playerid][30], 1);
		PlayerTextDrawSetSelectable(playerid, TextInvP[playerid][30], 0);

		TextInvP[playerid][31] = CreatePlayerTextDraw(playerid, 447.500000, 210.000000, "999");
		PlayerTextDrawFont(playerid, TextInvP[playerid][31], 2);
		PlayerTextDrawLetterSize(playerid, TextInvP[playerid][31], 0.129166, 0.850000);
		PlayerTextDrawTextSize(playerid, TextInvP[playerid][31], 400.000000, 17.000000);
		PlayerTextDrawSetOutline(playerid, TextInvP[playerid][31], 2);
		PlayerTextDrawSetShadow(playerid, TextInvP[playerid][31], 0);
		PlayerTextDrawAlignment(playerid, TextInvP[playerid][31], 3);
		PlayerTextDrawColor(playerid, TextInvP[playerid][31], -1);
		PlayerTextDrawBackgroundColor(playerid, TextInvP[playerid][31], 0);
		PlayerTextDrawBoxColor(playerid, TextInvP[playerid][31], 0);
		PlayerTextDrawUseBox(playerid, TextInvP[playerid][31], 1);
		PlayerTextDrawSetProportional(playerid, TextInvP[playerid][31], 1);
		PlayerTextDrawSetSelectable(playerid, TextInvP[playerid][31], 0);

		TextInvP[playerid][32] = CreatePlayerTextDraw(playerid, 489.500000, 210.000000, "999");
		PlayerTextDrawFont(playerid, TextInvP[playerid][32], 2);
		PlayerTextDrawLetterSize(playerid, TextInvP[playerid][32], 0.129166, 0.850000);
		PlayerTextDrawTextSize(playerid, TextInvP[playerid][32], 400.000000, 17.000000);
		PlayerTextDrawSetOutline(playerid, TextInvP[playerid][32], 2);
		PlayerTextDrawSetShadow(playerid, TextInvP[playerid][32], 0);
		PlayerTextDrawAlignment(playerid, TextInvP[playerid][32], 3);
		PlayerTextDrawColor(playerid, TextInvP[playerid][32], -1);
		PlayerTextDrawBackgroundColor(playerid, TextInvP[playerid][32], 0);
		PlayerTextDrawBoxColor(playerid, TextInvP[playerid][32], 0);
		PlayerTextDrawUseBox(playerid, TextInvP[playerid][32], 1);
		PlayerTextDrawSetProportional(playerid, TextInvP[playerid][32], 1);
		PlayerTextDrawSetSelectable(playerid, TextInvP[playerid][32], 0);

		TextInvP[playerid][33] = CreatePlayerTextDraw(playerid, 323.500000, 252.000000, "999");
		PlayerTextDrawFont(playerid, TextInvP[playerid][33], 2);
		PlayerTextDrawLetterSize(playerid, TextInvP[playerid][33], 0.129166, 0.850000);
		PlayerTextDrawTextSize(playerid, TextInvP[playerid][33], 400.000000, 17.000000);
		PlayerTextDrawSetOutline(playerid, TextInvP[playerid][33], 2);
		PlayerTextDrawSetShadow(playerid, TextInvP[playerid][33], 0);
		PlayerTextDrawAlignment(playerid, TextInvP[playerid][33], 3);
		PlayerTextDrawColor(playerid, TextInvP[playerid][33], -1);
		PlayerTextDrawBackgroundColor(playerid, TextInvP[playerid][33], 0);
		PlayerTextDrawBoxColor(playerid, TextInvP[playerid][33], 0);
		PlayerTextDrawUseBox(playerid, TextInvP[playerid][33], 1);
		PlayerTextDrawSetProportional(playerid, TextInvP[playerid][33], 1);
		PlayerTextDrawSetSelectable(playerid, TextInvP[playerid][33], 0);

		TextInvP[playerid][34] = CreatePlayerTextDraw(playerid, 365.500000, 252.000000, "999");
		PlayerTextDrawFont(playerid, TextInvP[playerid][34], 2);
		PlayerTextDrawLetterSize(playerid, TextInvP[playerid][34], 0.129166, 0.850000);
		PlayerTextDrawTextSize(playerid, TextInvP[playerid][34], 400.000000, 17.000000);
		PlayerTextDrawSetOutline(playerid, TextInvP[playerid][34], 2);
		PlayerTextDrawSetShadow(playerid, TextInvP[playerid][34], 0);
		PlayerTextDrawAlignment(playerid, TextInvP[playerid][34], 3);
		PlayerTextDrawColor(playerid, TextInvP[playerid][34], -1);
		PlayerTextDrawBackgroundColor(playerid, TextInvP[playerid][34], 0);
		PlayerTextDrawBoxColor(playerid, TextInvP[playerid][34], 0);
		PlayerTextDrawUseBox(playerid, TextInvP[playerid][34], 1);
		PlayerTextDrawSetProportional(playerid, TextInvP[playerid][34], 1);
		PlayerTextDrawSetSelectable(playerid, TextInvP[playerid][34], 0);

		TextInvP[playerid][35] = CreatePlayerTextDraw(playerid, 406.500000, 252.000000, "999");
		PlayerTextDrawFont(playerid, TextInvP[playerid][35], 2);
		PlayerTextDrawLetterSize(playerid, TextInvP[playerid][35], 0.129166, 0.850000);
		PlayerTextDrawTextSize(playerid, TextInvP[playerid][35], 400.000000, 17.000000);
		PlayerTextDrawSetOutline(playerid, TextInvP[playerid][35], 2);
		PlayerTextDrawSetShadow(playerid, TextInvP[playerid][35], 0);
		PlayerTextDrawAlignment(playerid, TextInvP[playerid][35], 3);
		PlayerTextDrawColor(playerid, TextInvP[playerid][35], -1);
		PlayerTextDrawBackgroundColor(playerid, TextInvP[playerid][35], 0);
		PlayerTextDrawBoxColor(playerid, TextInvP[playerid][35], 0);
		PlayerTextDrawUseBox(playerid, TextInvP[playerid][35], 1);
		PlayerTextDrawSetProportional(playerid, TextInvP[playerid][35], 1);
		PlayerTextDrawSetSelectable(playerid, TextInvP[playerid][35], 0);

		TextInvP[playerid][36] = CreatePlayerTextDraw(playerid, 447.500000, 252.000000, "999");
		PlayerTextDrawFont(playerid, TextInvP[playerid][36], 2);
		PlayerTextDrawLetterSize(playerid, TextInvP[playerid][36], 0.129166, 0.850000);
		PlayerTextDrawTextSize(playerid, TextInvP[playerid][36], 400.000000, 17.000000);
		PlayerTextDrawSetOutline(playerid, TextInvP[playerid][36], 2);
		PlayerTextDrawSetShadow(playerid, TextInvP[playerid][36], 0);
		PlayerTextDrawAlignment(playerid, TextInvP[playerid][36], 3);
		PlayerTextDrawColor(playerid, TextInvP[playerid][36], -1);
		PlayerTextDrawBackgroundColor(playerid, TextInvP[playerid][36], 0);
		PlayerTextDrawBoxColor(playerid, TextInvP[playerid][36], 0);
		PlayerTextDrawUseBox(playerid, TextInvP[playerid][36], 1);
		PlayerTextDrawSetProportional(playerid, TextInvP[playerid][36], 1);
		PlayerTextDrawSetSelectable(playerid, TextInvP[playerid][36], 0);

		TextInvP[playerid][37] = CreatePlayerTextDraw(playerid, 489.500000, 252.000000, "999");
		PlayerTextDrawFont(playerid, TextInvP[playerid][37], 2);
		PlayerTextDrawLetterSize(playerid, TextInvP[playerid][37], 0.129166, 0.850000);
		PlayerTextDrawTextSize(playerid, TextInvP[playerid][37], 400.000000, 17.000000);
		PlayerTextDrawSetOutline(playerid, TextInvP[playerid][37], 2);
		PlayerTextDrawSetShadow(playerid, TextInvP[playerid][37], 0);
		PlayerTextDrawAlignment(playerid, TextInvP[playerid][37], 3);
		PlayerTextDrawColor(playerid, TextInvP[playerid][37], -1);
		PlayerTextDrawBackgroundColor(playerid, TextInvP[playerid][37], 0);
		PlayerTextDrawBoxColor(playerid, TextInvP[playerid][37], 0);
		PlayerTextDrawUseBox(playerid, TextInvP[playerid][37], 1);
		PlayerTextDrawSetProportional(playerid, TextInvP[playerid][37], 1);
		PlayerTextDrawSetSelectable(playerid, TextInvP[playerid][37], 0);

		TextInvP[playerid][38] = CreatePlayerTextDraw(playerid, 323.500000, 294.000000, "999");
		PlayerTextDrawFont(playerid, TextInvP[playerid][38], 2);
		PlayerTextDrawLetterSize(playerid, TextInvP[playerid][38], 0.129166, 0.850000);
		PlayerTextDrawTextSize(playerid, TextInvP[playerid][38], 400.000000, 17.000000);
		PlayerTextDrawSetOutline(playerid, TextInvP[playerid][38], 2);
		PlayerTextDrawSetShadow(playerid, TextInvP[playerid][38], 0);
		PlayerTextDrawAlignment(playerid, TextInvP[playerid][38], 3);
		PlayerTextDrawColor(playerid, TextInvP[playerid][38], -1);
		PlayerTextDrawBackgroundColor(playerid, TextInvP[playerid][38], 0);
		PlayerTextDrawBoxColor(playerid, TextInvP[playerid][38], 0);
		PlayerTextDrawUseBox(playerid, TextInvP[playerid][38], 1);
		PlayerTextDrawSetProportional(playerid, TextInvP[playerid][38], 1);
		PlayerTextDrawSetSelectable(playerid, TextInvP[playerid][38], 0);

		TextInvP[playerid][39] = CreatePlayerTextDraw(playerid, 365.500000, 294.000000, "999");
		PlayerTextDrawFont(playerid, TextInvP[playerid][39], 2);
		PlayerTextDrawLetterSize(playerid, TextInvP[playerid][39], 0.129166, 0.850000);
		PlayerTextDrawTextSize(playerid, TextInvP[playerid][39], 400.000000, 17.000000);
		PlayerTextDrawSetOutline(playerid, TextInvP[playerid][39], 2);
		PlayerTextDrawSetShadow(playerid, TextInvP[playerid][39], 0);
		PlayerTextDrawAlignment(playerid, TextInvP[playerid][39], 3);
		PlayerTextDrawColor(playerid, TextInvP[playerid][39], -1);
		PlayerTextDrawBackgroundColor(playerid, TextInvP[playerid][39], 0);
		PlayerTextDrawBoxColor(playerid, TextInvP[playerid][39], 0);
		PlayerTextDrawUseBox(playerid, TextInvP[playerid][39], 1);
		PlayerTextDrawSetProportional(playerid, TextInvP[playerid][39], 1);
		PlayerTextDrawSetSelectable(playerid, TextInvP[playerid][39], 0);

		TextInvP[playerid][40] = CreatePlayerTextDraw(playerid, 406.500000, 294.000000, "999");
		PlayerTextDrawFont(playerid, TextInvP[playerid][40], 2);
		PlayerTextDrawLetterSize(playerid, TextInvP[playerid][40], 0.129166, 0.850000);
		PlayerTextDrawTextSize(playerid, TextInvP[playerid][40], 400.000000, 17.000000);
		PlayerTextDrawSetOutline(playerid, TextInvP[playerid][40], 2);
		PlayerTextDrawSetShadow(playerid, TextInvP[playerid][40], 0);
		PlayerTextDrawAlignment(playerid, TextInvP[playerid][40], 3);
		PlayerTextDrawColor(playerid, TextInvP[playerid][40], -1);
		PlayerTextDrawBackgroundColor(playerid, TextInvP[playerid][40], 0);
		PlayerTextDrawBoxColor(playerid, TextInvP[playerid][40], 0);
		PlayerTextDrawUseBox(playerid, TextInvP[playerid][40], 1);
		PlayerTextDrawSetProportional(playerid, TextInvP[playerid][40], 1);
		PlayerTextDrawSetSelectable(playerid, TextInvP[playerid][40], 0);

		TextInvP[playerid][41] = CreatePlayerTextDraw(playerid, 447.500000, 294.000000, "999");
		PlayerTextDrawFont(playerid, TextInvP[playerid][41], 2);
		PlayerTextDrawLetterSize(playerid, TextInvP[playerid][41], 0.129166, 0.850000);
		PlayerTextDrawTextSize(playerid, TextInvP[playerid][41], 400.000000, 17.000000);
		PlayerTextDrawSetOutline(playerid, TextInvP[playerid][41], 2);
		PlayerTextDrawSetShadow(playerid, TextInvP[playerid][41], 0);
		PlayerTextDrawAlignment(playerid, TextInvP[playerid][41], 3);
		PlayerTextDrawColor(playerid, TextInvP[playerid][41], -1);
		PlayerTextDrawBackgroundColor(playerid, TextInvP[playerid][41], 0);
		PlayerTextDrawBoxColor(playerid, TextInvP[playerid][41], 0);
		PlayerTextDrawUseBox(playerid, TextInvP[playerid][41], 1);
		PlayerTextDrawSetProportional(playerid, TextInvP[playerid][41], 1);
		PlayerTextDrawSetSelectable(playerid, TextInvP[playerid][41], 0);

		TextInvP[playerid][42] = CreatePlayerTextDraw(playerid, 489.500000, 294.000000, "999");
		PlayerTextDrawFont(playerid, TextInvP[playerid][42], 2);
		PlayerTextDrawLetterSize(playerid, TextInvP[playerid][42], 0.129166, 0.850000);
		PlayerTextDrawTextSize(playerid, TextInvP[playerid][42], 400.000000, 17.000000);
		PlayerTextDrawSetOutline(playerid, TextInvP[playerid][42], 2);
		PlayerTextDrawSetShadow(playerid, TextInvP[playerid][42], 0);
		PlayerTextDrawAlignment(playerid, TextInvP[playerid][42], 3);
		PlayerTextDrawColor(playerid, TextInvP[playerid][42], -1);
		PlayerTextDrawBackgroundColor(playerid, TextInvP[playerid][42], 0);
		PlayerTextDrawBoxColor(playerid, TextInvP[playerid][42], 0);
		PlayerTextDrawUseBox(playerid, TextInvP[playerid][42], 1);
		PlayerTextDrawSetProportional(playerid, TextInvP[playerid][42], 1);
		PlayerTextDrawSetSelectable(playerid, TextInvP[playerid][42], 0);

		TextInvP[playerid][43] = CreatePlayerTextDraw(playerid, 122.000000, 217.000000, "");//<<
		PlayerTextDrawFont(playerid, TextInvP[playerid][43], 3);
		PlayerTextDrawLetterSize(playerid, TextInvP[playerid][43], 0.320833, 6.049998);
		PlayerTextDrawTextSize(playerid, TextInvP[playerid][43], 50.000000, 30.0);
		PlayerTextDrawSetOutline(playerid, TextInvP[playerid][43], 0);
		PlayerTextDrawSetShadow(playerid, TextInvP[playerid][43], 0);
		PlayerTextDrawAlignment(playerid, TextInvP[playerid][43], 2);
		
		PlayerTextDrawBackgroundColor(playerid, TextInvP[playerid][43], -171);
		PlayerTextDrawBoxColor(playerid, TextInvP[playerid][43], 50);
		PlayerTextDrawUseBox(playerid, TextInvP[playerid][43], 0);
		PlayerTextDrawSetProportional(playerid, TextInvP[playerid][43], 1);
		PlayerTextDrawSetSelectable(playerid, TextInvP[playerid][43], 1);

		TextInvP[playerid][44] = CreatePlayerTextDraw(playerid, 57.000000, 145.000000, "_");
		PlayerTextDrawFont(playerid, TextInvP[playerid][44], 0);
		PlayerTextDrawLetterSize(playerid, TextInvP[playerid][44], 0.649999, 23.000011);
		PlayerTextDrawTextSize(playerid, TextInvP[playerid][44], 301.500000, 95.000000);
		PlayerTextDrawSetOutline(playerid, TextInvP[playerid][44], 1);
		PlayerTextDrawSetShadow(playerid, TextInvP[playerid][44], 0);
		PlayerTextDrawAlignment(playerid, TextInvP[playerid][44], 2);
		PlayerTextDrawColor(playerid, TextInvP[playerid][44], -1);
		PlayerTextDrawBackgroundColor(playerid, TextInvP[playerid][44], 255);
		PlayerTextDrawBoxColor(playerid, TextInvP[playerid][44], 353703423);
		PlayerTextDrawUseBox(playerid, TextInvP[playerid][44], 1);
		PlayerTextDrawSetProportional(playerid, TextInvP[playerid][44], 1);
		PlayerTextDrawSetSelectable(playerid, TextInvP[playerid][44], 0);

		TextInvP[playerid][45] = CreatePlayerTextDraw(playerid, 61.000000, 147.000000, "Recompensa Diaria");
		PlayerTextDrawFont(playerid, TextInvP[playerid][45], 3);
		PlayerTextDrawLetterSize(playerid, TextInvP[playerid][45], 0.424999, 2.299992);
		PlayerTextDrawTextSize(playerid, TextInvP[playerid][45], 400.000000, 16.500000);
		PlayerTextDrawSetOutline(playerid, TextInvP[playerid][45], 1);
		PlayerTextDrawSetShadow(playerid, TextInvP[playerid][45], 0);
		PlayerTextDrawAlignment(playerid, TextInvP[playerid][45], 2);
		PlayerTextDrawColor(playerid, TextInvP[playerid][45], 255);

		PlayerTextDrawBoxColor(playerid, TextInvP[playerid][45], 65330);
		PlayerTextDrawUseBox(playerid, TextInvP[playerid][45], 0);
		PlayerTextDrawSetProportional(playerid, TextInvP[playerid][45], 1);
		PlayerTextDrawSetSelectable(playerid, TextInvP[playerid][45], 0);

		TextInvP[playerid][46] = CreatePlayerTextDraw(playerid, 13.000000, 225.000000, "Preview_Model");
		PlayerTextDrawFont(playerid, TextInvP[playerid][46], 5);
		PlayerTextDrawLetterSize(playerid, TextInvP[playerid][46], 0.600000, 2.000000);
		PlayerTextDrawTextSize(playerid, TextInvP[playerid][46], 87.500000, 90.000000);
		PlayerTextDrawSetOutline(playerid, TextInvP[playerid][46], 0);
		PlayerTextDrawSetShadow(playerid, TextInvP[playerid][46], 0);
		PlayerTextDrawAlignment(playerid, TextInvP[playerid][46], 1);
		PlayerTextDrawColor(playerid, TextInvP[playerid][46], -1);
		PlayerTextDrawBackgroundColor(playerid, TextInvP[playerid][46], 100);
		PlayerTextDrawBoxColor(playerid, TextInvP[playerid][46], 255);
		PlayerTextDrawUseBox(playerid, TextInvP[playerid][46], 0);
		PlayerTextDrawSetProportional(playerid, TextInvP[playerid][46], 1);
		PlayerTextDrawSetSelectable(playerid, TextInvP[playerid][46], 0);
		PlayerTextDrawSetPreviewModel(playerid, TextInvP[playerid][46], 19058);
		PlayerTextDrawSetPreviewRot(playerid, TextInvP[playerid][46], -29.000000, 0.000000, 40.000000, 1.000000);
		PlayerTextDrawSetPreviewVehCol(playerid, TextInvP[playerid][46], 1, 1);

		TextInvP[playerid][47] = CreatePlayerTextDraw(playerid, 13.000000, 321.000000, "Preview_Model");
		PlayerTextDrawFont(playerid, TextInvP[playerid][47], 5);
		PlayerTextDrawLetterSize(playerid, TextInvP[playerid][47], 0.600000, 2.000000);
		PlayerTextDrawTextSize(playerid, TextInvP[playerid][47], 87.500000, 27.000000);
		PlayerTextDrawSetOutline(playerid, TextInvP[playerid][47], 0);
		PlayerTextDrawSetShadow(playerid, TextInvP[playerid][47], 0);
		PlayerTextDrawAlignment(playerid, TextInvP[playerid][47], 1);
		PlayerTextDrawColor(playerid, TextInvP[playerid][47], -1);

		PlayerTextDrawUseBox(playerid, TextInvP[playerid][47], 0);
		PlayerTextDrawSetProportional(playerid, TextInvP[playerid][47], 1);
		PlayerTextDrawSetSelectable(playerid, TextInvP[playerid][47], 1);
		PlayerTextDrawSetPreviewModel(playerid, TextInvP[playerid][47], 0);
		PlayerTextDrawSetPreviewRot(playerid, TextInvP[playerid][47], -29.000000, 0.000000, 40.000000, 111.000000);
		PlayerTextDrawSetPreviewVehCol(playerid, TextInvP[playerid][47], 1, 1);

		TextInvP[playerid][48] = CreatePlayerTextDraw(playerid, 56.000000, 325.000000, "ABRIR");
		PlayerTextDrawFont(playerid, TextInvP[playerid][48], 1);
		PlayerTextDrawLetterSize(playerid, TextInvP[playerid][48], 0.516667, 1.999998);
		PlayerTextDrawTextSize(playerid, TextInvP[playerid][48], 400.000000, 19.500000);
		PlayerTextDrawSetOutline(playerid, TextInvP[playerid][48], 0);
		PlayerTextDrawSetShadow(playerid, TextInvP[playerid][48], 0);
		PlayerTextDrawAlignment(playerid, TextInvP[playerid][48], 2);
		PlayerTextDrawColor(playerid, TextInvP[playerid][48], -1);
		PlayerTextDrawBackgroundColor(playerid, TextInvP[playerid][48], -171);
		PlayerTextDrawBoxColor(playerid, TextInvP[playerid][48], 50);
		PlayerTextDrawUseBox(playerid, TextInvP[playerid][48], 0);
		PlayerTextDrawSetProportional(playerid, TextInvP[playerid][48], 1);
		PlayerTextDrawSetSelectable(playerid, TextInvP[playerid][48], 0);

		TextInvP[playerid][49] = CreatePlayerTextDraw(playerid, 56.000000, 204.000000, "Ah!~n~voce_ja_recebeu_seu_presente!");
		PlayerTextDrawFont(playerid, TextInvP[playerid][49], 1);
		PlayerTextDrawLetterSize(playerid, TextInvP[playerid][49], 0.166667, 1.049998);
		PlayerTextDrawTextSize(playerid, TextInvP[playerid][49], 400.000000, 19.500000);
		PlayerTextDrawSetOutline(playerid, TextInvP[playerid][49], 0);
		PlayerTextDrawSetShadow(playerid, TextInvP[playerid][49], 0);
		PlayerTextDrawAlignment(playerid, TextInvP[playerid][49], 2);
		PlayerTextDrawColor(playerid, TextInvP[playerid][49], -1);
		PlayerTextDrawBackgroundColor(playerid, TextInvP[playerid][49], -171);
		PlayerTextDrawBoxColor(playerid, TextInvP[playerid][49], 50);
		PlayerTextDrawUseBox(playerid, TextInvP[playerid][49], 0);
		PlayerTextDrawSetProportional(playerid, TextInvP[playerid][49], 1);
		PlayerTextDrawSetSelectable(playerid, TextInvP[playerid][49], 0);


        switch(PlayerData[playerid][pInventoryMode])
        {
            case 1:
            {
                PlayerTextDrawColor(playerid, TextInvP[playerid][43], 0xDE1987FF);
                PlayerTextDrawBackgroundColor(playerid, TextInvP[playerid][45], 0xDE1987FF);
                PlayerTextDrawBackgroundColor(playerid, TextInvP[playerid][47], 0xDE1987FF);
                PlayerTextDrawBoxColor(playerid, TextInvP[playerid][47], 0xDE1987FF);
            }
            case 2:
            {
                PlayerTextDrawColor(playerid, TextInvP[playerid][43], 0xF75394FF);
                PlayerTextDrawBackgroundColor(playerid, TextInvP[playerid][45], 0xF75394FF);
                PlayerTextDrawBackgroundColor(playerid, TextInvP[playerid][47], 0xF75394FF);
                PlayerTextDrawBoxColor(playerid, TextInvP[playerid][47], 0xF75394FF);
            }
            case 3:
            {
                PlayerTextDrawColor(playerid, TextInvP[playerid][43], 0x78BE21FF);
                PlayerTextDrawBackgroundColor(playerid, TextInvP[playerid][45], 0x78BE21FF);
                PlayerTextDrawBackgroundColor(playerid, TextInvP[playerid][47], 0x78BE21FF);
                PlayerTextDrawBoxColor(playerid, TextInvP[playerid][47], 0x78BE21FF);
            }
            case 4:
            {
                PlayerTextDrawColor(playerid, TextInvP[playerid][43], 0x6B54B6FF);
                PlayerTextDrawBackgroundColor(playerid, TextInvP[playerid][45], 0x6B54B6FF);
                PlayerTextDrawBackgroundColor(playerid, TextInvP[playerid][47], 0x6B54B6FF);
                PlayerTextDrawBoxColor(playerid, TextInvP[playerid][47], 0x6B54B6FF);
            }
        }
        
		OpenedInventory[playerid] = 1;
	}
	else 
	{
		OpenedInventory[playerid] = 0;
		CancelSelectTextDraw(playerid);
	 	for(new t; t < 50; t++)
	    {
		    DestroyPlayerTD(playerid, TextInvP[playerid][t]);
	    }
	}
	return 1;
}	

stock ItemPreviewRot(playerid, item, PlayerText:textdraw)
{
    PlayerTextDrawSetPreviewRot(playerid, textdraw, 0.000000, 0.000000, 0.000000, 1.000000);
    PlayerTextDrawSetPreviewModel(playerid, textdraw, item);
	switch(item)
    {
        case 8, 339:
        PlayerTextDrawSetPreviewRot(playerid, textdraw, 43.0, 32.0, -31.0, 1.0),
        PlayerTextDrawSetPreviewModel(playerid, textdraw, 339);

        case 9, 341:
        PlayerTextDrawSetPreviewRot(playerid, textdraw, 349.0, 3.0, 76.0, 2.0),
        PlayerTextDrawSetPreviewModel(playerid, textdraw, 341);

        case 22, 346:
        PlayerTextDrawSetPreviewRot(playerid, textdraw, -6.0, 0.0, 56.0, 1.0),
        PlayerTextDrawSetPreviewModel(playerid, textdraw, 346);

        case 23, 347:
        PlayerTextDrawSetPreviewRot(playerid, textdraw, -12.0, 0.0, 66.0, 1.0),
        PlayerTextDrawSetPreviewModel(playerid, textdraw, 347);

        case 24, 348:
        PlayerTextDrawSetPreviewRot(playerid, textdraw, -2.0, 0.0, 70.0, 1.0),
        PlayerTextDrawSetPreviewModel(playerid, textdraw, 348);

        case 25, 349:
        PlayerTextDrawSetPreviewRot(playerid, textdraw, 0.0, 0.0, -35.0, 1.6),
        PlayerTextDrawSetPreviewModel(playerid, textdraw, 349);

        case 26, 350:
        PlayerTextDrawSetPreviewRot(playerid, textdraw, -10.0, 4.0, 78.0, 1.28),
        PlayerTextDrawSetPreviewModel(playerid, textdraw, 350);

        case 27, 351:
        PlayerTextDrawSetPreviewRot(playerid, textdraw, -9.0, 4.0, 74.0, 2.0),
        PlayerTextDrawSetPreviewModel(playerid, textdraw, 351);

        case 28, 352:
        PlayerTextDrawSetPreviewModel(playerid, textdraw, 352);

        case 29, 353:
        PlayerTextDrawSetPreviewRot(playerid, textdraw, -10.0, 0.0, 65.0, 1.7),
        PlayerTextDrawSetPreviewModel(playerid, textdraw, 353);

        case 30, 355:
        PlayerTextDrawSetPreviewRot(playerid, textdraw, 0.0, -35.0, 0.0, 1.7),
        PlayerTextDrawSetPreviewModel(playerid, textdraw, 355);

        case 31, 356:
        PlayerTextDrawSetPreviewRot(playerid, textdraw, 0.0, -35.0, 0.0, 1.7),
        PlayerTextDrawSetPreviewModel(playerid, textdraw, 356);

        case 34, 358:
        PlayerTextDrawSetPreviewRot(playerid, textdraw, 0.0, -35.0, 0.0, 1.7),
        PlayerTextDrawSetPreviewModel(playerid, textdraw, 358);
		//
        case 0:
	 	PlayerTextDrawSetPreviewRot(playerid, textdraw, -10.000000, 0.000000, -20.000000, 111.000000);

		case 18875:
	 	PlayerTextDrawSetPreviewRot(playerid, textdraw, -88.000000, 0.000000, -1.000000, 1.000000);

        case 2703:
        PlayerTextDrawSetPreviewRot(playerid, textdraw, -98.000000, -46.000000, -19.000000, 1.169999);

        case 2702:
        PlayerTextDrawSetPreviewRot(playerid, textdraw, 80.000000, -40.000000, 181.000000, 1.000000);

        case 2814:
        PlayerTextDrawSetPreviewRot(playerid, textdraw, -91.000000, 0.000000, 92.000000, 1.000000);

        case 18868:
        PlayerTextDrawSetPreviewRot(playerid, textdraw, -98.000000, 0.000000, -180.000000, 1.249999);

        case 330:
        PlayerTextDrawSetPreviewRot(playerid, textdraw, -20.000000, 0.000000, 0.000000, 0.830000);

        case 18634:
        PlayerTextDrawSetPreviewRot(playerid, textdraw, -349.000000, -2.000000, 34.000000, 1.070000);

        case 11748:
        PlayerTextDrawSetPreviewRot(playerid, textdraw, -100.000000, 0.000000, 1.000000, 1.000000);

        case 2806:
        PlayerTextDrawSetPreviewRot(playerid, textdraw, -61.000000, 0.000000, -46.000000, 1.169999);

        case 2804:
        PlayerTextDrawSetPreviewRot(playerid, textdraw, -92.000000, 0.000000, 78.000000, 1.000000);

        case 19627:
        PlayerTextDrawSetPreviewRot(playerid, textdraw, -102.000000, -29.000000, -5.000000, 1.000000);

        case 373:
        PlayerTextDrawSetPreviewRot(playerid, textdraw, 66.000000, 0.000000, 120.000000, 1.730000);

        case 19896:
        PlayerTextDrawSetPreviewRot(playerid, textdraw, 106.000000, 0.000000, -1.000000, 0.780000);

        case 2647:
        PlayerTextDrawSetPreviewRot(playerid, textdraw, -10.000000, 0.000000, -20.000000, 1.000000);

        case 19893:
        PlayerTextDrawSetPreviewRot(playerid, textdraw, -34.000000, 0.000000, 181.000000, 1.000000);
	}
}

CMD:inventory(playerid, params[])
{
	if(PlayerData[playerid][pHospital] != -1 || !IsPlayerSpawned(playerid) || OpenedInventory[playerid] != 0)
        return SendErrorMessage(playerid, "You can't open your inventory right now.");

    if(!PlayerData[playerid][pInventoryMode])
        return OpenInventory(playerid);

    InventoryGlobalGUI(playerid, true);
    InventoryGUI(playerid, true);

    SlotItemSelected[playerid] = -1; ItemSelected[playerid] = -1; CurrentPage[playerid] = 0; SelectedPage[playerid] = -1; MenuSelected[playerid] = 0;
    AccSelected[playerid] = -1; SlotAccSelected[playerid] = -1;

    new str[25]; format(str, sizeof(str), "%s", ReturnName(playerid));
    PlayerTextDrawSetString(playerid, TextInvP[playerid][18], str);

    format(str, sizeof(str), "~g~$~w~%s", FormatNumber(PlayerData[playerid][pMoney], ""));
    PlayerTextDrawSetString(playerid, TextInvP[playerid][26], str);

    format(str, sizeof(str), "~y~C~w~ %s", GetPlayerCoin(playerid) ? (sprintf("%d", GetPlayerCoin(playerid))) : ("0"));
    PlayerTextDrawSetString(playerid, TextInvP[playerid][27], str);

    PlayerTextDrawSetPreviewModel(playerid, TextInvP[playerid][19], GetPlayerSkin(playerid));

    PlayerTextDrawColor(playerid, TextInvP[playerid][0], 0x6B54B6FF);
    PlayerTextDrawColor(playerid, TextInvP[playerid][1], -2071690138);
    PlayerTextDrawColor(playerid, TextInvP[playerid][2], -2071690206);

    for(new t; t < 3; t++)
    {
    	PlayerTextDrawSetSelectable(playerid, TextInvP[playerid][t], 1); PlayerTextDrawShow(playerid, TextInvP[playerid][t]);
	}

	for(new t = 20; t < 26; t++)
	{
	    PlayerTextDrawBackgroundColor(playerid, TextInvP[playerid][t], -2071690155);
	    ItemPreviewRot(playerid, AccData[playerid][t-20][accModel], TextInvP[playerid][t]);
	}

	for(new i; i < 15; i++)
	{
	    PlayerTextDrawBackgroundColor(playerid, TextInvP[playerid][i+3], -2071690155);
	    if(InventoryData[playerid][i][invModel] > 0)
	    {
	        ItemPreviewRot(playerid, InventoryData[playerid][i][invModel], TextInvP[playerid][i+3]);
			if(InventoryData[playerid][i][invQuantity] == 0)
			{
	        	InventoryData[playerid][i][invQuantity] = 1;
			}
	    }
	    else if(InventoryData[playerid][i][invModel] == 0)
	    {
	        InventoryData[playerid][i][invQuantity] = 0;
	        PlayerTextDrawSetPreviewRot(playerid, TextInvP[playerid][i+3], -10.000000, 0.000000, -20.000000, 111.000000);
	    }
	    new Quantity[4];
		if(InventoryData[playerid][i][invQuantity] > 0) format(Quantity, sizeof(Quantity), "%d", InventoryData[playerid][i][invQuantity]);
		else Quantity = "";
	   	PlayerTextDrawSetString(playerid, TextInvP[playerid][i+28], Quantity);
    }
    for(new t; t < 44; t++)
	{
	    PlayerTextDrawShow(playerid, TextInvP[playerid][t]);
    }
    //SelectTextDraw(playerid, 0x6B54B6AA);
    SelectTextDrawColor(playerid);
    return 1;
}

SelectTextDrawColor(playerid)
{
    switch(PlayerData[playerid][pInventoryMode])
    {
        case 1:
        {
            SelectTextDraw(playerid, 0xDE1987AA);
        }
        case 2:
        {
            SelectTextDraw(playerid, 0xF75394AA);
        }
        case 3:
        {
            SelectTextDraw(playerid, 0x78BE21AA);
        }
        case 4:
        {
            SelectTextDraw(playerid, 0x6B54B6AA);
        }
    }
    return 1;
}

SetInventoryColor(playerid)
{
    switch(PlayerData[playerid][pInventoryMode])
    {
        case 1:
        {
            PlayerTextDrawColor(playerid, TextInvP[playerid][0], 0xDE1987FF); PlayerTextDrawShow(playerid, TextInvP[playerid][0]);
        }
        case 2:
        {
            PlayerTextDrawColor(playerid, TextInvP[playerid][0], 0xF75394FF); PlayerTextDrawShow(playerid, TextInvP[playerid][0]);
        }
        case 3:
        {
            PlayerTextDrawColor(playerid, TextInvP[playerid][0], 0x78BE21FF); PlayerTextDrawShow(playerid, TextInvP[playerid][0]);
        }
        case 4:
        {
            PlayerTextDrawColor(playerid, TextInvP[playerid][0], 0x6B54B6FF); PlayerTextDrawShow(playerid, TextInvP[playerid][0]);
        }
    }
    return 1;
}