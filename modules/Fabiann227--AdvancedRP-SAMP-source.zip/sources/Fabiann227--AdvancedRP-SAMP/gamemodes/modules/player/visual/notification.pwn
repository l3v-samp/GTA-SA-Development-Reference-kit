new PlayerText:NotificationTD[MAX_PLAYERS][5];
new PlayerText:TextBox[MAX_PLAYERS];
new PlayerText:TDTimer[MAX_PLAYERS];
new PlayerText:TextType[MAX_PLAYERS];
new PlayerText:Text[MAX_PLAYERS];

NotificationTD2(playerid)
{
	NotificationTD[playerid][0] = CreatePlayerTextDraw(playerid, 6.000000, 211.000000, "ld_beat:chit");
	PlayerTextDrawFont(playerid, NotificationTD[playerid][0], 4);
	PlayerTextDrawLetterSize(playerid, NotificationTD[playerid][0], 0.600000, 2.000000);
	PlayerTextDrawTextSize(playerid, NotificationTD[playerid][0], 7.000000, 9.000000);
	PlayerTextDrawSetOutline(playerid, NotificationTD[playerid][0], 1);
	PlayerTextDrawSetShadow(playerid, NotificationTD[playerid][0], 0);
	PlayerTextDrawAlignment(playerid, NotificationTD[playerid][0], 1);
	PlayerTextDrawColor(playerid, NotificationTD[playerid][0], 847509247);
	PlayerTextDrawBackgroundColor(playerid, NotificationTD[playerid][0], 255);
	PlayerTextDrawBoxColor(playerid, NotificationTD[playerid][0], 50);
	PlayerTextDrawUseBox(playerid, NotificationTD[playerid][0], 1);
	PlayerTextDrawSetProportional(playerid, NotificationTD[playerid][0], 1);
	PlayerTextDrawSetSelectable(playerid, NotificationTD[playerid][0], 0);

	NotificationTD[playerid][1] = CreatePlayerTextDraw(playerid, 6.000000, 228.000000, "ld_beat:chit");
	PlayerTextDrawFont(playerid, NotificationTD[playerid][1], 4);
	PlayerTextDrawLetterSize(playerid, NotificationTD[playerid][1], 0.600000, 2.000000);
	PlayerTextDrawTextSize(playerid, NotificationTD[playerid][1], 7.000000, 9.000000);
	PlayerTextDrawSetOutline(playerid, NotificationTD[playerid][1], 1);
	PlayerTextDrawSetShadow(playerid, NotificationTD[playerid][1], 0);
	PlayerTextDrawAlignment(playerid, NotificationTD[playerid][1], 1);
	PlayerTextDrawColor(playerid, NotificationTD[playerid][1], 847509247);
	PlayerTextDrawBackgroundColor(playerid, NotificationTD[playerid][1], 255);
	PlayerTextDrawBoxColor(playerid, NotificationTD[playerid][1], 50);
	PlayerTextDrawUseBox(playerid, NotificationTD[playerid][1], 1);
	PlayerTextDrawSetProportional(playerid, NotificationTD[playerid][1], 1);
	PlayerTextDrawSetSelectable(playerid, NotificationTD[playerid][1], 0);

	TextBox[playerid] = CreatePlayerTextDraw(playerid, 10.000000, 213.000000, "ld_bum:blkdot");
	PlayerTextDrawFont(playerid, TextBox[playerid], 4);
	PlayerTextDrawLetterSize(playerid, TextBox[playerid], 0.600000, 2.000000);
	PlayerTextDrawTextSize(playerid, TextBox[playerid], 108.000000, 22.500000);
	PlayerTextDrawSetOutline(playerid, TextBox[playerid], 1);
	PlayerTextDrawSetShadow(playerid, TextBox[playerid], 0);
	PlayerTextDrawAlignment(playerid, TextBox[playerid], 1);
	PlayerTextDrawColor(playerid, TextBox[playerid], 673390847);
	PlayerTextDrawBackgroundColor(playerid, TextBox[playerid], 255);
	PlayerTextDrawBoxColor(playerid, TextBox[playerid], 50);
	PlayerTextDrawUseBox(playerid, TextBox[playerid], 1);
	PlayerTextDrawSetProportional(playerid, TextBox[playerid], 1);
	PlayerTextDrawSetSelectable(playerid, TextBox[playerid], 0);

	TDTimer[playerid] = CreatePlayerTextDraw(playerid, 10.000000, 235.000000, "ld_bum:blkdot");
	PlayerTextDrawFont(playerid, TDTimer[playerid], 4);
	PlayerTextDrawLetterSize(playerid, TDTimer[playerid], 0.600000, 2.000000);
	PlayerTextDrawTextSize(playerid, TDTimer[playerid], 107.500000, 0.500000);
	PlayerTextDrawSetOutline(playerid, TDTimer[playerid], 1);
	PlayerTextDrawSetShadow(playerid, TDTimer[playerid], 0);
	PlayerTextDrawAlignment(playerid, TDTimer[playerid], 1);
	PlayerTextDrawColor(playerid, TDTimer[playerid], 1097458175);
	PlayerTextDrawBackgroundColor(playerid, TDTimer[playerid], 255);
	PlayerTextDrawBoxColor(playerid, TDTimer[playerid], 50);
	PlayerTextDrawUseBox(playerid, TDTimer[playerid], 1);
	PlayerTextDrawSetProportional(playerid, TDTimer[playerid], 1);
	PlayerTextDrawSetSelectable(playerid, TDTimer[playerid], 0);

	NotificationTD[playerid][2] = CreatePlayerTextDraw(playerid, 7.000000, 214.000000, "ld_bum:blkdot");
	PlayerTextDrawFont(playerid, NotificationTD[playerid][2], 4);
	PlayerTextDrawLetterSize(playerid, NotificationTD[playerid][2], 0.600000, 2.000000);
	PlayerTextDrawTextSize(playerid, NotificationTD[playerid][2], 3.000000, 19.000000);
	PlayerTextDrawSetOutline(playerid, NotificationTD[playerid][2], 1);
	PlayerTextDrawSetShadow(playerid, NotificationTD[playerid][2], 0);
	PlayerTextDrawAlignment(playerid, NotificationTD[playerid][2], 1);
	PlayerTextDrawColor(playerid, NotificationTD[playerid][2], 847509247);
	PlayerTextDrawBackgroundColor(playerid, NotificationTD[playerid][2], 255);
	PlayerTextDrawBoxColor(playerid, NotificationTD[playerid][2], 50);
	PlayerTextDrawUseBox(playerid, NotificationTD[playerid][2], 1);
	PlayerTextDrawSetProportional(playerid, NotificationTD[playerid][2], 1);
	PlayerTextDrawSetSelectable(playerid, NotificationTD[playerid][2], 0);

	NotificationTD[playerid][3] = CreatePlayerTextDraw(playerid, 10.000000, 215.000000, "ld_beat:chit");
	PlayerTextDrawFont(playerid, NotificationTD[playerid][3], 4);
	PlayerTextDrawLetterSize(playerid, NotificationTD[playerid][3], 0.600000, 2.000000);
	PlayerTextDrawTextSize(playerid, NotificationTD[playerid][3], 13.500000, 17.000000);
	PlayerTextDrawSetOutline(playerid, NotificationTD[playerid][3], 1);
	PlayerTextDrawSetShadow(playerid, NotificationTD[playerid][3], 0);
	PlayerTextDrawAlignment(playerid, NotificationTD[playerid][3], 1);
	PlayerTextDrawColor(playerid, NotificationTD[playerid][3], 847509247);
	PlayerTextDrawBackgroundColor(playerid, NotificationTD[playerid][3], 255);
	PlayerTextDrawBoxColor(playerid, NotificationTD[playerid][3], 50);
	PlayerTextDrawUseBox(playerid, NotificationTD[playerid][3], 1);
	PlayerTextDrawSetProportional(playerid, NotificationTD[playerid][3], 1);
	PlayerTextDrawSetSelectable(playerid, NotificationTD[playerid][3], 0);

	NotificationTD[playerid][4] = CreatePlayerTextDraw(playerid, 15.000000, 217.000000, "i");
	PlayerTextDrawFont(playerid, NotificationTD[playerid][4], 1);
	PlayerTextDrawLetterSize(playerid, NotificationTD[playerid][4], 0.345833, 1.299999);
	PlayerTextDrawTextSize(playerid, NotificationTD[playerid][4], 400.000000, 17.000000);
	PlayerTextDrawSetOutline(playerid, NotificationTD[playerid][4], 0);
	PlayerTextDrawSetShadow(playerid, NotificationTD[playerid][4], 0);
	PlayerTextDrawAlignment(playerid, NotificationTD[playerid][4], 1);
	PlayerTextDrawColor(playerid, NotificationTD[playerid][4], 119820543);
	PlayerTextDrawBackgroundColor(playerid, NotificationTD[playerid][4], 255);
	PlayerTextDrawBoxColor(playerid, NotificationTD[playerid][4], 50);
	PlayerTextDrawUseBox(playerid, NotificationTD[playerid][4], 0);
	PlayerTextDrawSetProportional(playerid, NotificationTD[playerid][4], 1);
	PlayerTextDrawSetSelectable(playerid, NotificationTD[playerid][4], 0);

	TextType[playerid] = CreatePlayerTextDraw(playerid, 24.000000, 216.000000, "INFO");
	PlayerTextDrawFont(playerid, TextType[playerid], 1);
	PlayerTextDrawLetterSize(playerid, TextType[playerid], 0.166666, 0.850000);
	PlayerTextDrawTextSize(playerid, TextType[playerid], 400.000000, 17.000000);
	PlayerTextDrawSetOutline(playerid, TextType[playerid], 0);
	PlayerTextDrawSetShadow(playerid, TextType[playerid], 0);
	PlayerTextDrawAlignment(playerid, TextType[playerid], 1);
	PlayerTextDrawColor(playerid, TextType[playerid], -1);
	PlayerTextDrawBackgroundColor(playerid, TextType[playerid], 255);
	PlayerTextDrawBoxColor(playerid, TextType[playerid], 50);
	PlayerTextDrawUseBox(playerid, TextType[playerid], 0);
	PlayerTextDrawSetProportional(playerid, TextType[playerid], 1);
	PlayerTextDrawSetSelectable(playerid, TextType[playerid], 0);

	Text[playerid] = CreatePlayerTextDraw(playerid, 24.000000, 223.000000, "Your first aid kit has been used up");
	PlayerTextDrawFont(playerid, Text[playerid], 1);
	PlayerTextDrawLetterSize(playerid, Text[playerid], 0.158333, 0.900000);
	PlayerTextDrawTextSize(playerid, Text[playerid], 648.500000, 17.000000);
	PlayerTextDrawSetOutline(playerid, Text[playerid], 0);
	PlayerTextDrawSetShadow(playerid, Text[playerid], 0);
	PlayerTextDrawAlignment(playerid, Text[playerid], 1);
	PlayerTextDrawColor(playerid, Text[playerid], -1);
	PlayerTextDrawBackgroundColor(playerid, Text[playerid], 255);
	PlayerTextDrawBoxColor(playerid, Text[playerid], 0);
	PlayerTextDrawUseBox(playerid, Text[playerid], 1);
	PlayerTextDrawSetProportional(playerid, Text[playerid], 1);
	PlayerTextDrawSetSelectable(playerid, Text[playerid], 0);

	return 1;
}

ShowInfo(playerid, text[])
{
	NotificationTD2(playerid);

	PlayerTextDrawSetString(playerid, Text[playerid], text);

	new Float:lebar;
    lebar = strlen(text) * 308.0/100;
    PlayerTextDrawTextSize(playerid, TextBox[playerid], lebar, 22.5);

    printf("%f", strlen(text) * 300.0/100);

	PlayerTextDrawShow(playerid, NotificationTD[playerid][0]);
	PlayerTextDrawShow(playerid, NotificationTD[playerid][1]);
	PlayerTextDrawShow(playerid, NotificationTD[playerid][2]);
	PlayerTextDrawShow(playerid, NotificationTD[playerid][3]);
	PlayerTextDrawShow(playerid, NotificationTD[playerid][4]);
	PlayerTextDrawShow(playerid, TextBox[playerid]);
	PlayerTextDrawShow(playerid, TDTimer[playerid]);
	PlayerTextDrawShow(playerid, TextType[playerid]);
	PlayerTextDrawShow(playerid, Text[playerid]);
	return 1;
}

CMD:infos(playerid, params[])
{
	ShowInfo(playerid, "Anda mendapatkan ikan Tuna dengan berat 30 lbs. (/myfish untuk melihat ikan yang di dapat).");
	//notification.show(playerid, "Anda mendapatkan ikan Tuna dengan berat 30 lbs. (/myfish untuk melihat ikan yang di dapat)");
	return 1;
}