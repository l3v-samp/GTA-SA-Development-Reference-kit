new PlayerText:AdvancedSpeedo[MAX_PLAYERS][15];
new PlayerText:Speed[MAX_PLAYERS];
new PlayerText:Health[MAX_PLAYERS];
new PlayerText:Fuel[MAX_PLAYERS];

SpeedometerPC(playerid)
{
	AdvancedSpeedo[playerid][0] = CreatePlayerTextDraw(playerid, 267.000000, 391.000000, "ld_beat:chit");
	PlayerTextDrawFont(playerid, AdvancedSpeedo[playerid][0], 4);
	PlayerTextDrawLetterSize(playerid, AdvancedSpeedo[playerid][0], 0.600000, 2.000000);
	PlayerTextDrawTextSize(playerid, AdvancedSpeedo[playerid][0], 27.000000, 27.500000);
	PlayerTextDrawSetOutline(playerid, AdvancedSpeedo[playerid][0], 1);
	PlayerTextDrawSetShadow(playerid, AdvancedSpeedo[playerid][0], 0);
	PlayerTextDrawAlignment(playerid, AdvancedSpeedo[playerid][0], 1);
	PlayerTextDrawColor(playerid, AdvancedSpeedo[playerid][0], -2147429377);
	PlayerTextDrawBackgroundColor(playerid, AdvancedSpeedo[playerid][0], 255);
	PlayerTextDrawBoxColor(playerid, AdvancedSpeedo[playerid][0], 50);
	PlayerTextDrawUseBox(playerid, AdvancedSpeedo[playerid][0], 1);
	PlayerTextDrawSetProportional(playerid, AdvancedSpeedo[playerid][0], 1);
	PlayerTextDrawSetSelectable(playerid, AdvancedSpeedo[playerid][0], 0);

	AdvancedSpeedo[playerid][1] = CreatePlayerTextDraw(playerid, 269.000000, 393.000000, "ld_beat:chit");
	PlayerTextDrawFont(playerid, AdvancedSpeedo[playerid][1], 4);
	PlayerTextDrawLetterSize(playerid, AdvancedSpeedo[playerid][1], 0.600000, 2.000000);
	PlayerTextDrawTextSize(playerid, AdvancedSpeedo[playerid][1], 23.000000, 23.500000);
	PlayerTextDrawSetOutline(playerid, AdvancedSpeedo[playerid][1], 1);
	PlayerTextDrawSetShadow(playerid, AdvancedSpeedo[playerid][1], 0);
	PlayerTextDrawAlignment(playerid, AdvancedSpeedo[playerid][1], 1);
	PlayerTextDrawColor(playerid, AdvancedSpeedo[playerid][1], 336860415);
	PlayerTextDrawBackgroundColor(playerid, AdvancedSpeedo[playerid][1], 255);
	PlayerTextDrawBoxColor(playerid, AdvancedSpeedo[playerid][1], 50);
	PlayerTextDrawUseBox(playerid, AdvancedSpeedo[playerid][1], 1);
	PlayerTextDrawSetProportional(playerid, AdvancedSpeedo[playerid][1], 1);
	PlayerTextDrawSetSelectable(playerid, AdvancedSpeedo[playerid][1], 0);

	AdvancedSpeedo[playerid][2] = CreatePlayerTextDraw(playerid, 335.000000, 391.000000, "ld_beat:chit");
	PlayerTextDrawFont(playerid, AdvancedSpeedo[playerid][2], 4);
	PlayerTextDrawLetterSize(playerid, AdvancedSpeedo[playerid][2], 0.600000, 2.000000);
	PlayerTextDrawTextSize(playerid, AdvancedSpeedo[playerid][2], 27.000000, 27.500000);
	PlayerTextDrawSetOutline(playerid, AdvancedSpeedo[playerid][2], 1);
	PlayerTextDrawSetShadow(playerid, AdvancedSpeedo[playerid][2], 0);
	PlayerTextDrawAlignment(playerid, AdvancedSpeedo[playerid][2], 1);
	PlayerTextDrawColor(playerid, AdvancedSpeedo[playerid][2], -2147429377);
	PlayerTextDrawBackgroundColor(playerid, AdvancedSpeedo[playerid][2], 255);
	PlayerTextDrawBoxColor(playerid, AdvancedSpeedo[playerid][2], 50);
	PlayerTextDrawUseBox(playerid, AdvancedSpeedo[playerid][2], 1);
	PlayerTextDrawSetProportional(playerid, AdvancedSpeedo[playerid][2], 1);
	PlayerTextDrawSetSelectable(playerid, AdvancedSpeedo[playerid][2], 0);

	AdvancedSpeedo[playerid][3] = CreatePlayerTextDraw(playerid, 337.000000, 393.000000, "ld_beat:chit");
	PlayerTextDrawFont(playerid, AdvancedSpeedo[playerid][3], 4);
	PlayerTextDrawLetterSize(playerid, AdvancedSpeedo[playerid][3], 0.600000, 2.000000);
	PlayerTextDrawTextSize(playerid, AdvancedSpeedo[playerid][3], 23.000000, 23.500000);
	PlayerTextDrawSetOutline(playerid, AdvancedSpeedo[playerid][3], 1);
	PlayerTextDrawSetShadow(playerid, AdvancedSpeedo[playerid][3], 0);
	PlayerTextDrawAlignment(playerid, AdvancedSpeedo[playerid][3], 1);
	PlayerTextDrawColor(playerid, AdvancedSpeedo[playerid][3], 336860415);
	PlayerTextDrawBackgroundColor(playerid, AdvancedSpeedo[playerid][3], 255);
	PlayerTextDrawBoxColor(playerid, AdvancedSpeedo[playerid][3], 50);
	PlayerTextDrawUseBox(playerid, AdvancedSpeedo[playerid][3], 1);
	PlayerTextDrawSetProportional(playerid, AdvancedSpeedo[playerid][3], 1);
	PlayerTextDrawSetSelectable(playerid, AdvancedSpeedo[playerid][3], 0);

	AdvancedSpeedo[playerid][4] = CreatePlayerTextDraw(playerid, 296.000000, 388.000000, "(");
	PlayerTextDrawFont(playerid, AdvancedSpeedo[playerid][4], 1);
	PlayerTextDrawLetterSize(playerid, AdvancedSpeedo[playerid][4], 0.600000, 3.599997);
	PlayerTextDrawTextSize(playerid, AdvancedSpeedo[playerid][4], 400.000000, 17.000000);
	PlayerTextDrawSetOutline(playerid, AdvancedSpeedo[playerid][4], 0);
	PlayerTextDrawSetShadow(playerid, AdvancedSpeedo[playerid][4], 0);
	PlayerTextDrawAlignment(playerid, AdvancedSpeedo[playerid][4], 1);
	PlayerTextDrawColor(playerid, AdvancedSpeedo[playerid][4], -2147429377);
	PlayerTextDrawBackgroundColor(playerid, AdvancedSpeedo[playerid][4], 255);
	PlayerTextDrawBoxColor(playerid, AdvancedSpeedo[playerid][4], 50);
	PlayerTextDrawUseBox(playerid, AdvancedSpeedo[playerid][4], 0);
	PlayerTextDrawSetProportional(playerid, AdvancedSpeedo[playerid][4], 1);
	PlayerTextDrawSetSelectable(playerid, AdvancedSpeedo[playerid][4], 0);

	AdvancedSpeedo[playerid][5] = CreatePlayerTextDraw(playerid, 324.000000, 388.000000, ")");
	PlayerTextDrawFont(playerid, AdvancedSpeedo[playerid][5], 1);
	PlayerTextDrawLetterSize(playerid, AdvancedSpeedo[playerid][5], 0.600000, 3.599997);
	PlayerTextDrawTextSize(playerid, AdvancedSpeedo[playerid][5], 400.000000, 17.000000);
	PlayerTextDrawSetOutline(playerid, AdvancedSpeedo[playerid][5], 0);
	PlayerTextDrawSetShadow(playerid, AdvancedSpeedo[playerid][5], 0);
	PlayerTextDrawAlignment(playerid, AdvancedSpeedo[playerid][5], 1);
	PlayerTextDrawColor(playerid, AdvancedSpeedo[playerid][5], -2147429377);
	PlayerTextDrawBackgroundColor(playerid, AdvancedSpeedo[playerid][5], 255);
	PlayerTextDrawBoxColor(playerid, AdvancedSpeedo[playerid][5], 50);
	PlayerTextDrawUseBox(playerid, AdvancedSpeedo[playerid][5], 0);
	PlayerTextDrawSetProportional(playerid, AdvancedSpeedo[playerid][5], 1);
	PlayerTextDrawSetSelectable(playerid, AdvancedSpeedo[playerid][5], 0);

	Speed[playerid] = CreatePlayerTextDraw(playerid, 314.000000, 401.000000, "100");
	PlayerTextDrawFont(playerid, Speed[playerid], 1);
	PlayerTextDrawLetterSize(playerid, Speed[playerid], 0.341666, 1.500000);
	PlayerTextDrawTextSize(playerid, Speed[playerid], 400.000000, 17.000000);
	PlayerTextDrawSetOutline(playerid, Speed[playerid], 0);
	PlayerTextDrawSetShadow(playerid, Speed[playerid], 0);
	PlayerTextDrawAlignment(playerid, Speed[playerid], 2);
	PlayerTextDrawColor(playerid, Speed[playerid], -1);
	PlayerTextDrawBackgroundColor(playerid, Speed[playerid], 255);
	PlayerTextDrawBoxColor(playerid, Speed[playerid], 50);
	PlayerTextDrawUseBox(playerid, Speed[playerid], 0);
	PlayerTextDrawSetProportional(playerid, Speed[playerid], 1);
	PlayerTextDrawSetSelectable(playerid, Speed[playerid], 0);

	AdvancedSpeedo[playerid][6] = CreatePlayerTextDraw(playerid, 314.000000, 413.000000, "Km/h");
	PlayerTextDrawFont(playerid, AdvancedSpeedo[playerid][6], 1);
	PlayerTextDrawLetterSize(playerid, AdvancedSpeedo[playerid][6], 0.212500, 1.000000);
	PlayerTextDrawTextSize(playerid, AdvancedSpeedo[playerid][6], 400.000000, 17.000000);
	PlayerTextDrawSetOutline(playerid, AdvancedSpeedo[playerid][6], 0);
	PlayerTextDrawSetShadow(playerid, AdvancedSpeedo[playerid][6], 0);
	PlayerTextDrawAlignment(playerid, AdvancedSpeedo[playerid][6], 2);
	PlayerTextDrawColor(playerid, AdvancedSpeedo[playerid][6], -1);
	PlayerTextDrawBackgroundColor(playerid, AdvancedSpeedo[playerid][6], 255);
	PlayerTextDrawBoxColor(playerid, AdvancedSpeedo[playerid][6], 50);
	PlayerTextDrawUseBox(playerid, AdvancedSpeedo[playerid][6], 0);
	PlayerTextDrawSetProportional(playerid, AdvancedSpeedo[playerid][6], 1);
	PlayerTextDrawSetSelectable(playerid, AdvancedSpeedo[playerid][6], 0);

	Health[playerid] = CreatePlayerTextDraw(playerid, 281.000000, 415.000000, "1000.0");
	PlayerTextDrawFont(playerid, Health[playerid], 1);
	PlayerTextDrawLetterSize(playerid, Health[playerid], 0.191666, 0.850000);
	PlayerTextDrawTextSize(playerid, Health[playerid], 400.000000, 17.000000);
	PlayerTextDrawSetOutline(playerid, Health[playerid], 0);
	PlayerTextDrawSetShadow(playerid, Health[playerid], 0);
	PlayerTextDrawAlignment(playerid, Health[playerid], 2);
	PlayerTextDrawColor(playerid, Health[playerid], -1);
	PlayerTextDrawBackgroundColor(playerid, Health[playerid], 255);
	PlayerTextDrawBoxColor(playerid, Health[playerid], 50);
	PlayerTextDrawUseBox(playerid, Health[playerid], 0);
	PlayerTextDrawSetProportional(playerid, Health[playerid], 1);
	PlayerTextDrawSetSelectable(playerid, Health[playerid], 0);

	Fuel[playerid] = CreatePlayerTextDraw(playerid, 349.000000, 414.000000, "100.0");
	PlayerTextDrawFont(playerid, Fuel[playerid], 1);
	PlayerTextDrawLetterSize(playerid, Fuel[playerid], 0.170833, 0.750000);
	PlayerTextDrawTextSize(playerid, Fuel[playerid], 400.000000, 17.000000);
	PlayerTextDrawSetOutline(playerid, Fuel[playerid], 0);
	PlayerTextDrawSetShadow(playerid, Fuel[playerid], 0);
	PlayerTextDrawAlignment(playerid, Fuel[playerid], 2);
	PlayerTextDrawColor(playerid, Fuel[playerid], -1);
	PlayerTextDrawBackgroundColor(playerid, Fuel[playerid], 255);
	PlayerTextDrawBoxColor(playerid, Fuel[playerid], 50);
	PlayerTextDrawUseBox(playerid, Fuel[playerid], 0);
	PlayerTextDrawSetProportional(playerid, Fuel[playerid], 1);
	PlayerTextDrawSetSelectable(playerid, Fuel[playerid], 0);

	AdvancedSpeedo[playerid][7] = CreatePlayerTextDraw(playerid, 343.000000, 399.000000, "mdl-2007:fuel_logo");
	PlayerTextDrawFont(playerid, AdvancedSpeedo[playerid][7], 4);
	PlayerTextDrawLetterSize(playerid, AdvancedSpeedo[playerid][7], 0.600000, 2.000000);
	PlayerTextDrawTextSize(playerid, AdvancedSpeedo[playerid][7], 11.000000, 11.500000);
	PlayerTextDrawSetOutline(playerid, AdvancedSpeedo[playerid][7], 1);
	PlayerTextDrawSetShadow(playerid, AdvancedSpeedo[playerid][7], 0);
	PlayerTextDrawAlignment(playerid, AdvancedSpeedo[playerid][7], 1);
	PlayerTextDrawColor(playerid, AdvancedSpeedo[playerid][7], -1);
	PlayerTextDrawBackgroundColor(playerid, AdvancedSpeedo[playerid][7], 255);
	PlayerTextDrawBoxColor(playerid, AdvancedSpeedo[playerid][7], 50);
	PlayerTextDrawUseBox(playerid, AdvancedSpeedo[playerid][7], 1);
	PlayerTextDrawSetProportional(playerid, AdvancedSpeedo[playerid][7], 1);
	PlayerTextDrawSetSelectable(playerid, AdvancedSpeedo[playerid][7], 0);

	AdvancedSpeedo[playerid][8] = CreatePlayerTextDraw(playerid, 270.000000, 395.000000, "mdl-2003:health_logo");
	PlayerTextDrawFont(playerid, AdvancedSpeedo[playerid][8], 4);
	PlayerTextDrawLetterSize(playerid, AdvancedSpeedo[playerid][8], 0.600000, 2.000000);
	PlayerTextDrawTextSize(playerid, AdvancedSpeedo[playerid][8], 20.500000, 20.000000);
	PlayerTextDrawSetOutline(playerid, AdvancedSpeedo[playerid][8], 1);
	PlayerTextDrawSetShadow(playerid, AdvancedSpeedo[playerid][8], 0);
	PlayerTextDrawAlignment(playerid, AdvancedSpeedo[playerid][8], 1);
	PlayerTextDrawColor(playerid, AdvancedSpeedo[playerid][8], -1);
	PlayerTextDrawBackgroundColor(playerid, AdvancedSpeedo[playerid][8], 255);
	PlayerTextDrawBoxColor(playerid, AdvancedSpeedo[playerid][8], 50);
	PlayerTextDrawUseBox(playerid, AdvancedSpeedo[playerid][8], 1);
	PlayerTextDrawSetProportional(playerid, AdvancedSpeedo[playerid][8], 1);
	PlayerTextDrawSetSelectable(playerid, AdvancedSpeedo[playerid][8], 0);
	return 1;
}
SpeedometerAndroid(playerid)
{
	AdvancedSpeedo[playerid][0] = CreatePlayerTextDraw(playerid, 267.000000, 391.000000, "ld_beat:chit");
	PlayerTextDrawFont(playerid, AdvancedSpeedo[playerid][0], 4);
	PlayerTextDrawLetterSize(playerid, AdvancedSpeedo[playerid][0], 0.600000, 2.000000);
	PlayerTextDrawTextSize(playerid, AdvancedSpeedo[playerid][0], 27.000000, 27.500000);
	PlayerTextDrawSetOutline(playerid, AdvancedSpeedo[playerid][0], 1);
	PlayerTextDrawSetShadow(playerid, AdvancedSpeedo[playerid][0], 0);
	PlayerTextDrawAlignment(playerid, AdvancedSpeedo[playerid][0], 1);
	PlayerTextDrawColor(playerid, AdvancedSpeedo[playerid][0], -2147429377);
	PlayerTextDrawBackgroundColor(playerid, AdvancedSpeedo[playerid][0], 255);
	PlayerTextDrawBoxColor(playerid, AdvancedSpeedo[playerid][0], 50);
	PlayerTextDrawUseBox(playerid, AdvancedSpeedo[playerid][0], 1);
	PlayerTextDrawSetProportional(playerid, AdvancedSpeedo[playerid][0], 1);
	PlayerTextDrawSetSelectable(playerid, AdvancedSpeedo[playerid][0], 0);

	AdvancedSpeedo[playerid][1] = CreatePlayerTextDraw(playerid, 269.000000, 393.000000, "ld_beat:chit");
	PlayerTextDrawFont(playerid, AdvancedSpeedo[playerid][1], 4);
	PlayerTextDrawLetterSize(playerid, AdvancedSpeedo[playerid][1], 0.600000, 2.000000);
	PlayerTextDrawTextSize(playerid, AdvancedSpeedo[playerid][1], 23.000000, 23.500000);
	PlayerTextDrawSetOutline(playerid, AdvancedSpeedo[playerid][1], 1);
	PlayerTextDrawSetShadow(playerid, AdvancedSpeedo[playerid][1], 0);
	PlayerTextDrawAlignment(playerid, AdvancedSpeedo[playerid][1], 1);
	PlayerTextDrawColor(playerid, AdvancedSpeedo[playerid][1], 336860415);
	PlayerTextDrawBackgroundColor(playerid, AdvancedSpeedo[playerid][1], 255);
	PlayerTextDrawBoxColor(playerid, AdvancedSpeedo[playerid][1], 50);
	PlayerTextDrawUseBox(playerid, AdvancedSpeedo[playerid][1], 1);
	PlayerTextDrawSetProportional(playerid, AdvancedSpeedo[playerid][1], 1);
	PlayerTextDrawSetSelectable(playerid, AdvancedSpeedo[playerid][1], 0);

	AdvancedSpeedo[playerid][2] = CreatePlayerTextDraw(playerid, 335.000000, 391.000000, "ld_beat:chit");
	PlayerTextDrawFont(playerid, AdvancedSpeedo[playerid][2], 4);
	PlayerTextDrawLetterSize(playerid, AdvancedSpeedo[playerid][2], 0.600000, 2.000000);
	PlayerTextDrawTextSize(playerid, AdvancedSpeedo[playerid][2], 27.000000, 27.500000);
	PlayerTextDrawSetOutline(playerid, AdvancedSpeedo[playerid][2], 1);
	PlayerTextDrawSetShadow(playerid, AdvancedSpeedo[playerid][2], 0);
	PlayerTextDrawAlignment(playerid, AdvancedSpeedo[playerid][2], 1);
	PlayerTextDrawColor(playerid, AdvancedSpeedo[playerid][2], -2147429377);
	PlayerTextDrawBackgroundColor(playerid, AdvancedSpeedo[playerid][2], 255);
	PlayerTextDrawBoxColor(playerid, AdvancedSpeedo[playerid][2], 50);
	PlayerTextDrawUseBox(playerid, AdvancedSpeedo[playerid][2], 1);
	PlayerTextDrawSetProportional(playerid, AdvancedSpeedo[playerid][2], 1);
	PlayerTextDrawSetSelectable(playerid, AdvancedSpeedo[playerid][2], 0);

	AdvancedSpeedo[playerid][3] = CreatePlayerTextDraw(playerid, 337.000000, 393.000000, "ld_beat:chit");
	PlayerTextDrawFont(playerid, AdvancedSpeedo[playerid][3], 4);
	PlayerTextDrawLetterSize(playerid, AdvancedSpeedo[playerid][3], 0.600000, 2.000000);
	PlayerTextDrawTextSize(playerid, AdvancedSpeedo[playerid][3], 23.000000, 23.500000);
	PlayerTextDrawSetOutline(playerid, AdvancedSpeedo[playerid][3], 1);
	PlayerTextDrawSetShadow(playerid, AdvancedSpeedo[playerid][3], 0);
	PlayerTextDrawAlignment(playerid, AdvancedSpeedo[playerid][3], 1);
	PlayerTextDrawColor(playerid, AdvancedSpeedo[playerid][3], 336860415);
	PlayerTextDrawBackgroundColor(playerid, AdvancedSpeedo[playerid][3], 255);
	PlayerTextDrawBoxColor(playerid, AdvancedSpeedo[playerid][3], 50);
	PlayerTextDrawUseBox(playerid, AdvancedSpeedo[playerid][3], 1);
	PlayerTextDrawSetProportional(playerid, AdvancedSpeedo[playerid][3], 1);
	PlayerTextDrawSetSelectable(playerid, AdvancedSpeedo[playerid][3], 0);

	AdvancedSpeedo[playerid][4] = CreatePlayerTextDraw(playerid, 296.000000, 388.000000, "(");
	PlayerTextDrawFont(playerid, AdvancedSpeedo[playerid][4], 1);
	PlayerTextDrawLetterSize(playerid, AdvancedSpeedo[playerid][4], 0.600000, 3.599997);
	PlayerTextDrawTextSize(playerid, AdvancedSpeedo[playerid][4], 400.000000, 17.000000);
	PlayerTextDrawSetOutline(playerid, AdvancedSpeedo[playerid][4], 0);
	PlayerTextDrawSetShadow(playerid, AdvancedSpeedo[playerid][4], 0);
	PlayerTextDrawAlignment(playerid, AdvancedSpeedo[playerid][4], 1);
	PlayerTextDrawColor(playerid, AdvancedSpeedo[playerid][4], -2147429377);
	PlayerTextDrawBackgroundColor(playerid, AdvancedSpeedo[playerid][4], 255);
	PlayerTextDrawBoxColor(playerid, AdvancedSpeedo[playerid][4], 50);
	PlayerTextDrawUseBox(playerid, AdvancedSpeedo[playerid][4], 0);
	PlayerTextDrawSetProportional(playerid, AdvancedSpeedo[playerid][4], 1);
	PlayerTextDrawSetSelectable(playerid, AdvancedSpeedo[playerid][4], 0);

	AdvancedSpeedo[playerid][5] = CreatePlayerTextDraw(playerid, 324.000000, 388.000000, ")");
	PlayerTextDrawFont(playerid, AdvancedSpeedo[playerid][5], 1);
	PlayerTextDrawLetterSize(playerid, AdvancedSpeedo[playerid][5], 0.600000, 3.599997);
	PlayerTextDrawTextSize(playerid, AdvancedSpeedo[playerid][5], 400.000000, 17.000000);
	PlayerTextDrawSetOutline(playerid, AdvancedSpeedo[playerid][5], 0);
	PlayerTextDrawSetShadow(playerid, AdvancedSpeedo[playerid][5], 0);
	PlayerTextDrawAlignment(playerid, AdvancedSpeedo[playerid][5], 1);
	PlayerTextDrawColor(playerid, AdvancedSpeedo[playerid][5], -2147429377);
	PlayerTextDrawBackgroundColor(playerid, AdvancedSpeedo[playerid][5], 255);
	PlayerTextDrawBoxColor(playerid, AdvancedSpeedo[playerid][5], 50);
	PlayerTextDrawUseBox(playerid, AdvancedSpeedo[playerid][5], 0);
	PlayerTextDrawSetProportional(playerid, AdvancedSpeedo[playerid][5], 1);
	PlayerTextDrawSetSelectable(playerid, AdvancedSpeedo[playerid][5], 0);

	Speed[playerid] = CreatePlayerTextDraw(playerid, 314.000000, 401.000000, "100");
	PlayerTextDrawFont(playerid, Speed[playerid], 1);
	PlayerTextDrawLetterSize(playerid, Speed[playerid], 0.341666, 1.500000);
	PlayerTextDrawTextSize(playerid, Speed[playerid], 400.000000, 17.000000);
	PlayerTextDrawSetOutline(playerid, Speed[playerid], 0);
	PlayerTextDrawSetShadow(playerid, Speed[playerid], 0);
	PlayerTextDrawAlignment(playerid, Speed[playerid], 2);
	PlayerTextDrawColor(playerid, Speed[playerid], -1);
	PlayerTextDrawBackgroundColor(playerid, Speed[playerid], 255);
	PlayerTextDrawBoxColor(playerid, Speed[playerid], 50);
	PlayerTextDrawUseBox(playerid, Speed[playerid], 0);
	PlayerTextDrawSetProportional(playerid, Speed[playerid], 1);
	PlayerTextDrawSetSelectable(playerid, Speed[playerid], 0);

	AdvancedSpeedo[playerid][6] = CreatePlayerTextDraw(playerid, 314.000000, 413.000000, "Km/h");
	PlayerTextDrawFont(playerid, AdvancedSpeedo[playerid][6], 1);
	PlayerTextDrawLetterSize(playerid, AdvancedSpeedo[playerid][6], 0.212500, 1.000000);
	PlayerTextDrawTextSize(playerid, AdvancedSpeedo[playerid][6], 400.000000, 17.000000);
	PlayerTextDrawSetOutline(playerid, AdvancedSpeedo[playerid][6], 0);
	PlayerTextDrawSetShadow(playerid, AdvancedSpeedo[playerid][6], 0);
	PlayerTextDrawAlignment(playerid, AdvancedSpeedo[playerid][6], 2);
	PlayerTextDrawColor(playerid, AdvancedSpeedo[playerid][6], -1);
	PlayerTextDrawBackgroundColor(playerid, AdvancedSpeedo[playerid][6], 255);
	PlayerTextDrawBoxColor(playerid, AdvancedSpeedo[playerid][6], 50);
	PlayerTextDrawUseBox(playerid, AdvancedSpeedo[playerid][6], 0);
	PlayerTextDrawSetProportional(playerid, AdvancedSpeedo[playerid][6], 1);
	PlayerTextDrawSetSelectable(playerid, AdvancedSpeedo[playerid][6], 0);

	Health[playerid] = CreatePlayerTextDraw(playerid, 281.000000, 415.000000, "1000.0");
	PlayerTextDrawFont(playerid, Health[playerid], 1);
	PlayerTextDrawLetterSize(playerid, Health[playerid], 0.191666, 0.850000);
	PlayerTextDrawTextSize(playerid, Health[playerid], 400.000000, 17.000000);
	PlayerTextDrawSetOutline(playerid, Health[playerid], 0);
	PlayerTextDrawSetShadow(playerid, Health[playerid], 0);
	PlayerTextDrawAlignment(playerid, Health[playerid], 2);
	PlayerTextDrawColor(playerid, Health[playerid], -1);
	PlayerTextDrawBackgroundColor(playerid, Health[playerid], 255);
	PlayerTextDrawBoxColor(playerid, Health[playerid], 50);
	PlayerTextDrawUseBox(playerid, Health[playerid], 0);
	PlayerTextDrawSetProportional(playerid, Health[playerid], 1);
	PlayerTextDrawSetSelectable(playerid, Health[playerid], 0);

	Fuel[playerid] = CreatePlayerTextDraw(playerid, 349.000000, 414.000000, "100.0");
	PlayerTextDrawFont(playerid, Fuel[playerid], 1);
	PlayerTextDrawLetterSize(playerid, Fuel[playerid], 0.170833, 0.750000);
	PlayerTextDrawTextSize(playerid, Fuel[playerid], 400.000000, 17.000000);
	PlayerTextDrawSetOutline(playerid, Fuel[playerid], 0);
	PlayerTextDrawSetShadow(playerid, Fuel[playerid], 0);
	PlayerTextDrawAlignment(playerid, Fuel[playerid], 2);
	PlayerTextDrawColor(playerid, Fuel[playerid], -1);
	PlayerTextDrawBackgroundColor(playerid, Fuel[playerid], 255);
	PlayerTextDrawBoxColor(playerid, Fuel[playerid], 50);
	PlayerTextDrawUseBox(playerid, Fuel[playerid], 0);
	PlayerTextDrawSetProportional(playerid, Fuel[playerid], 1);
	PlayerTextDrawSetSelectable(playerid, Fuel[playerid], 0);

	AdvancedSpeedo[playerid][7] = CreatePlayerTextDraw(playerid, 288.000000, 415.000000, "");
	PlayerTextDrawFont(playerid, AdvancedSpeedo[playerid][7], 1);
	PlayerTextDrawLetterSize(playerid, AdvancedSpeedo[playerid][7], 0.191666, 0.850000);
	PlayerTextDrawTextSize(playerid, AdvancedSpeedo[playerid][7], 400.000000, 17.000000);
	PlayerTextDrawSetOutline(playerid, AdvancedSpeedo[playerid][7], 0);
	PlayerTextDrawSetShadow(playerid, AdvancedSpeedo[playerid][7], 0);
	PlayerTextDrawAlignment(playerid, AdvancedSpeedo[playerid][7], 2);
	PlayerTextDrawColor(playerid, AdvancedSpeedo[playerid][7], -1);
	PlayerTextDrawBackgroundColor(playerid, AdvancedSpeedo[playerid][7], 255);
	PlayerTextDrawBoxColor(playerid, AdvancedSpeedo[playerid][7], 50);
	PlayerTextDrawUseBox(playerid, AdvancedSpeedo[playerid][7], 0);
	PlayerTextDrawSetProportional(playerid, AdvancedSpeedo[playerid][7], 1);
	PlayerTextDrawSetSelectable(playerid, AdvancedSpeedo[playerid][7], 0);

	AdvancedSpeedo[playerid][8] = CreatePlayerTextDraw(playerid, 346.000000, 402.000000, "ld_dual:white");
	PlayerTextDrawFont(playerid, AdvancedSpeedo[playerid][8], 4);
	PlayerTextDrawLetterSize(playerid, AdvancedSpeedo[playerid][8], 0.600000, 2.000000);
	PlayerTextDrawTextSize(playerid, AdvancedSpeedo[playerid][8], 1.000000, 7.000000);
	PlayerTextDrawSetOutline(playerid, AdvancedSpeedo[playerid][8], 1);
	PlayerTextDrawSetShadow(playerid, AdvancedSpeedo[playerid][8], 0);
	PlayerTextDrawAlignment(playerid, AdvancedSpeedo[playerid][8], 1);
	PlayerTextDrawColor(playerid, AdvancedSpeedo[playerid][8], -16775681);
	PlayerTextDrawBackgroundColor(playerid, AdvancedSpeedo[playerid][8], 255);
	PlayerTextDrawBoxColor(playerid, AdvancedSpeedo[playerid][8], 50);
	PlayerTextDrawUseBox(playerid, AdvancedSpeedo[playerid][8], 1);
	PlayerTextDrawSetProportional(playerid, AdvancedSpeedo[playerid][8], 1);
	PlayerTextDrawSetSelectable(playerid, AdvancedSpeedo[playerid][8], 0);

	AdvancedSpeedo[playerid][9] = CreatePlayerTextDraw(playerid, 351.000000, 402.000000, "ld_dual:white");
	PlayerTextDrawFont(playerid, AdvancedSpeedo[playerid][9], 4);
	PlayerTextDrawLetterSize(playerid, AdvancedSpeedo[playerid][9], 0.600000, 2.000000);
	PlayerTextDrawTextSize(playerid, AdvancedSpeedo[playerid][9], 1.000000, 7.000000);
	PlayerTextDrawSetOutline(playerid, AdvancedSpeedo[playerid][9], 1);
	PlayerTextDrawSetShadow(playerid, AdvancedSpeedo[playerid][9], 0);
	PlayerTextDrawAlignment(playerid, AdvancedSpeedo[playerid][9], 1);
	PlayerTextDrawColor(playerid, AdvancedSpeedo[playerid][9], -16775681);
	PlayerTextDrawBackgroundColor(playerid, AdvancedSpeedo[playerid][9], 255);
	PlayerTextDrawBoxColor(playerid, AdvancedSpeedo[playerid][9], 50);
	PlayerTextDrawUseBox(playerid, AdvancedSpeedo[playerid][9], 1);
	PlayerTextDrawSetProportional(playerid, AdvancedSpeedo[playerid][9], 1);
	PlayerTextDrawSetSelectable(playerid, AdvancedSpeedo[playerid][9], 0);

	AdvancedSpeedo[playerid][10] = CreatePlayerTextDraw(playerid, 345.000000, 408.000000, "ld_dual:white");
	PlayerTextDrawFont(playerid, AdvancedSpeedo[playerid][10], 4);
	PlayerTextDrawLetterSize(playerid, AdvancedSpeedo[playerid][10], 0.600000, 2.000000);
	PlayerTextDrawTextSize(playerid, AdvancedSpeedo[playerid][10], 7.500000, 1.000000);
	PlayerTextDrawSetOutline(playerid, AdvancedSpeedo[playerid][10], 1);
	PlayerTextDrawSetShadow(playerid, AdvancedSpeedo[playerid][10], 0);
	PlayerTextDrawAlignment(playerid, AdvancedSpeedo[playerid][10], 1);
	PlayerTextDrawColor(playerid, AdvancedSpeedo[playerid][10], -16775681);
	PlayerTextDrawBackgroundColor(playerid, AdvancedSpeedo[playerid][10], 255);
	PlayerTextDrawBoxColor(playerid, AdvancedSpeedo[playerid][10], 50);
	PlayerTextDrawUseBox(playerid, AdvancedSpeedo[playerid][10], 1);
	PlayerTextDrawSetProportional(playerid, AdvancedSpeedo[playerid][10], 1);
	PlayerTextDrawSetSelectable(playerid, AdvancedSpeedo[playerid][10], 0);

	AdvancedSpeedo[playerid][11] = CreatePlayerTextDraw(playerid, 351.000000, 401.000000, "]");
	PlayerTextDrawFont(playerid, AdvancedSpeedo[playerid][11], 1);
	PlayerTextDrawLetterSize(playerid, AdvancedSpeedo[playerid][11], 0.224996, 0.599995);
	PlayerTextDrawTextSize(playerid, AdvancedSpeedo[playerid][11], 400.000000, 17.000000);
	PlayerTextDrawSetOutline(playerid, AdvancedSpeedo[playerid][11], 0);
	PlayerTextDrawSetShadow(playerid, AdvancedSpeedo[playerid][11], 0);
	PlayerTextDrawAlignment(playerid, AdvancedSpeedo[playerid][11], 1);
	PlayerTextDrawColor(playerid, AdvancedSpeedo[playerid][11], -16775681);
	PlayerTextDrawBackgroundColor(playerid, AdvancedSpeedo[playerid][11], 255);
	PlayerTextDrawBoxColor(playerid, AdvancedSpeedo[playerid][11], 50);
	PlayerTextDrawUseBox(playerid, AdvancedSpeedo[playerid][11], 0);
	PlayerTextDrawSetProportional(playerid, AdvancedSpeedo[playerid][11], 1);
	PlayerTextDrawSetSelectable(playerid, AdvancedSpeedo[playerid][11], 0);

	AdvancedSpeedo[playerid][12] = CreatePlayerTextDraw(playerid, 346.000000, 401.000000, "ld_dual:white");
	PlayerTextDrawFont(playerid, AdvancedSpeedo[playerid][12], 4);
	PlayerTextDrawLetterSize(playerid, AdvancedSpeedo[playerid][12], 0.600000, 2.000000);
	PlayerTextDrawTextSize(playerid, AdvancedSpeedo[playerid][12], 6.000000, 1.500000);
	PlayerTextDrawSetOutline(playerid, AdvancedSpeedo[playerid][12], 1);
	PlayerTextDrawSetShadow(playerid, AdvancedSpeedo[playerid][12], 0);
	PlayerTextDrawAlignment(playerid, AdvancedSpeedo[playerid][12], 1);
	PlayerTextDrawColor(playerid, AdvancedSpeedo[playerid][12], -16775681);
	PlayerTextDrawBackgroundColor(playerid, AdvancedSpeedo[playerid][12], 255);
	PlayerTextDrawBoxColor(playerid, AdvancedSpeedo[playerid][12], 50);
	PlayerTextDrawUseBox(playerid, AdvancedSpeedo[playerid][12], 1);
	PlayerTextDrawSetProportional(playerid, AdvancedSpeedo[playerid][12], 1);
	PlayerTextDrawSetSelectable(playerid, AdvancedSpeedo[playerid][12], 0);

	AdvancedSpeedo[playerid][13] = CreatePlayerTextDraw(playerid, 262.000000, 387.000000, "Preview_Model");
	PlayerTextDrawFont(playerid, AdvancedSpeedo[playerid][13], 5);
	PlayerTextDrawLetterSize(playerid, AdvancedSpeedo[playerid][13], 0.600000, 2.000000);
	PlayerTextDrawTextSize(playerid, AdvancedSpeedo[playerid][13], 37.500000, 35.500000);
	PlayerTextDrawSetOutline(playerid, AdvancedSpeedo[playerid][13], 0);
	PlayerTextDrawSetShadow(playerid, AdvancedSpeedo[playerid][13], 0);
	PlayerTextDrawAlignment(playerid, AdvancedSpeedo[playerid][13], 1);
	PlayerTextDrawColor(playerid, AdvancedSpeedo[playerid][13], -421070081);
	PlayerTextDrawBackgroundColor(playerid, AdvancedSpeedo[playerid][13], 0);
	PlayerTextDrawBoxColor(playerid, AdvancedSpeedo[playerid][13], 255);
	PlayerTextDrawUseBox(playerid, AdvancedSpeedo[playerid][13], 0);
	PlayerTextDrawSetProportional(playerid, AdvancedSpeedo[playerid][13], 1);
	PlayerTextDrawSetSelectable(playerid, AdvancedSpeedo[playerid][13], 0);
	PlayerTextDrawSetPreviewModel(playerid, AdvancedSpeedo[playerid][13], 1240);
	PlayerTextDrawSetPreviewRot(playerid, AdvancedSpeedo[playerid][13], -10.000000, 0.000000, 2.000000, 2.689996);
	PlayerTextDrawSetPreviewVehCol(playerid, AdvancedSpeedo[playerid][13], 1, 1);

	AdvancedSpeedo[playerid][14] = CreatePlayerTextDraw(playerid, 347.000000, 405.000000, "ld_dual:white");
	PlayerTextDrawFont(playerid, AdvancedSpeedo[playerid][14], 4);
	PlayerTextDrawLetterSize(playerid, AdvancedSpeedo[playerid][14], 0.600000, 2.000000);
	PlayerTextDrawTextSize(playerid, AdvancedSpeedo[playerid][14], 4.000000, 4.000000);
	PlayerTextDrawSetOutline(playerid, AdvancedSpeedo[playerid][14], 1);
	PlayerTextDrawSetShadow(playerid, AdvancedSpeedo[playerid][14], 0);
	PlayerTextDrawAlignment(playerid, AdvancedSpeedo[playerid][14], 1);
	PlayerTextDrawColor(playerid, AdvancedSpeedo[playerid][14], -1090189057);
	PlayerTextDrawBackgroundColor(playerid, AdvancedSpeedo[playerid][14], 255);
	PlayerTextDrawBoxColor(playerid, AdvancedSpeedo[playerid][14], 50);
	PlayerTextDrawUseBox(playerid, AdvancedSpeedo[playerid][14], 1);
	PlayerTextDrawSetProportional(playerid, AdvancedSpeedo[playerid][14], 1);
	PlayerTextDrawSetSelectable(playerid, AdvancedSpeedo[playerid][14], 0);

	return 1;
}

SpeedometerAndroidHide(playerid)
{
	for(new i = 0; i < 15; i++ )
	{
		PlayerTextDrawHide(playerid, AdvancedSpeedo[playerid][i]);
	}
	PlayerTextDrawHide(playerid, Speed[playerid]);
	PlayerTextDrawHide(playerid, Health[playerid]);
	PlayerTextDrawHide(playerid, Fuel[playerid]);
}

SpeedometerAndroidShow(playerid)
{
	for(new i = 0; i < 15; i++)
	{
		PlayerTextDrawShow(playerid, AdvancedSpeedo[playerid][i]);
	}
	PlayerTextDrawShow(playerid, Speed[playerid]);
	PlayerTextDrawShow(playerid, Health[playerid]);
	PlayerTextDrawShow(playerid, Fuel[playerid]);
	return 1;
}

//PC
SpeedometerPCHide(playerid)
{
	for(new i = 0; i < 9; i++ )
	{
		PlayerTextDrawHide(playerid, AdvancedSpeedo[playerid][i]);
	}
	PlayerTextDrawHide(playerid, Speed[playerid]);
	PlayerTextDrawHide(playerid, Health[playerid]);
	PlayerTextDrawHide(playerid, Fuel[playerid]);
}

SpeedometerPCShow(playerid)
{
	for(new i = 0; i < 9; i++)
	{
		PlayerTextDrawShow(playerid, AdvancedSpeedo[playerid][i]);
	}
	PlayerTextDrawShow(playerid, Speed[playerid]);
	PlayerTextDrawShow(playerid, Health[playerid]);
	PlayerTextDrawShow(playerid, Fuel[playerid]);
	return 1;
}

Speedometer_Update(playerid)
{
  // Mendapatkan ID kendaraan player.
  new vehicleid = GetPlayerVehicleID(playerid);

  // Abaikan jika kendaraannya tidak valid.
  if (vehicleid == INVALID_VEHICLE_ID)
  {
    return 1;
  }

  // Abaikan jika kendaraannya tidak memiliki speedometer.
  if (!IsSpeedoVehicle(vehicleid))
  {
    return 1;
  }

  new
    speed = floatround(GetVehicleSpeed(vehicleid)),
    // transmission[40],
    //Float:max_health = 1000.0,
    Float:health,
    Float:fuel = Vehicle_GetFuel(vehicleid)
  ;

  // Mendapatkan health kendaraan.
  GetVehicleHealth(vehicleid, health);

  // Mendapatkan state transmisi kendaraan,
  // Speedometer_GetTransmission(vehicleid, transmission);

  // Memeriksa upgrade engine kendaraan.
  // Fungsinya untuk mencocokkan health kendaraan dengan engine upgrade-nya.
  if (VehicleData[Vehicle_ReturnID(vehicleid)][vehEngineUpgrade] == 1)
  {
    if (health > 2000.0)
    {
      health = 2000.0;
    }
    //max_health = 2000.0;
  }
  else
  {
    if (health > 1000.0)
    {
      health = 1000.0;
    }
  }
  if(PlayerData[playerid][pHudStyle] == 0)
  {
    PlayerTextDrawSetString(playerid, Speed[playerid], sprintf("%d", speed));
    PlayerTextDrawSetString(playerid, Health[playerid], sprintf("%.1f", health));
    PlayerTextDrawSetString(playerid, Fuel[playerid], sprintf("%.1fL", fuel));
  }

  return 1;
}

/**
 *
 * Callbacks
 *
 */

ptask Player_SpeedoUpdate[1000](playerid)
{
    if((!PlayerData[playerid][pLogged]) || !PlayerData[playerid][pCreated] || PlayerData[playerid][pKicked])
        return 0;
    
    // Abaikan jika state player bukan pengemudi.
    // Abaikan jika opsi speedomter dimatikan.
    if(GetPlayerState(playerid) == PLAYER_STATE_DRIVER && !PlayerData[playerid][pDisableSpeedo])
    {
        Speedometer_Update(playerid);
    }
    return 1;
}