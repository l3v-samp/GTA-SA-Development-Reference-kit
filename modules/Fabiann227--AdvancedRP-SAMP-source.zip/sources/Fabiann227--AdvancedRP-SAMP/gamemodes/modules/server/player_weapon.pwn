/*	 Weapon system module	*/

