# Modular mta starter

Copy reference_kit into the server resources directory and start it. meta.xml defines load order. Server/client modules remain separate. Commands: /kithello and /kitclient. Add server validation for future remote events. Shutdown removes command handlers.

Source scaffold only. Runtime/target builds have not been tested.
