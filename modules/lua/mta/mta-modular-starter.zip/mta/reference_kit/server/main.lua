addEventHandler('onResourceStart', resourceRoot, KitServer.start)
addEventHandler('onResourceStop', resourceRoot, KitServer.stop)
