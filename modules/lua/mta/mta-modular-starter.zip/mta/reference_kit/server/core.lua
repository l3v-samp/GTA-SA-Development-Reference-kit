KitServer = { features = {} }
function KitServer.register(feature)
    KitServer.features[#KitServer.features + 1] = feature
end
function KitServer.start()
    for _, feature in ipairs(KitServer.features) do feature.init() end
end
function KitServer.stop()
    for i = #KitServer.features, 1, -1 do
        local feature = KitServer.features[i]
        if feature.shutdown then feature.shutdown() end
    end
end
