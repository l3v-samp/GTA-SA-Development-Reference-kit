local function hello(player)
    if isElement(player) and getElementType(player) == 'player' then
        outputChatBox('Hello from a server module!', player, 100, 220, 140)
    end
end
KitServer.register({
    init = function() addCommandHandler('kithello', hello) end,
    shutdown = function() removeCommandHandler('kithello', hello) end
})
