KitClient = { features = {} }
function KitClient.register(feature)
    KitClient.features[#KitClient.features + 1] = feature
end
function KitClient.start()
    for _, feature in ipairs(KitClient.features) do feature.init() end
end
function KitClient.stop()
    for i = #KitClient.features, 1, -1 do
        local feature = KitClient.features[i]
        if feature.shutdown then feature.shutdown() end
    end
end
