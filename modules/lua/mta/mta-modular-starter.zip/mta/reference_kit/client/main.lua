addEventHandler('onClientResourceStart', resourceRoot, KitClient.start)
addEventHandler('onClientResourceStop', resourceRoot, KitClient.stop)
