local function hello()
    outputChatBox('Hello from a client module!', 100, 180, 255)
end
KitClient.register({
    init = function() addCommandHandler('kitclient', hello) end,
    shutdown = function() removeCommandHandler('kitclient', hello) end
})
