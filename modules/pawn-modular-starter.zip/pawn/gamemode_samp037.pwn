#include <a_samp>
#include "core/config.inc"
#include "features/hello.inc"
#include "core/callbacks.inc"
