#define FILTERSCRIPT
#include <open.mp>
#include "core/config.inc"
#include "features/hello.inc"
#include "core/callbacks.inc"
