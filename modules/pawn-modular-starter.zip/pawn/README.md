# Modular pawn starter

Compile exactly one gamemode or filterscript entrypoint using its matching stdlib. core/config.inc owns config; features/hello.inc owns the feature API; core/callbacks.inc owns callback dispatch. Add feature-specific data/domain/storage/ui modules as a feature grows. Never flatten includes or mix server profiles. No external plugins required for this hello example.

Source scaffold only. Runtime/target builds have not been tested.
