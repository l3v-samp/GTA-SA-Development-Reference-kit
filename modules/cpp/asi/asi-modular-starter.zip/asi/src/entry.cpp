#include <windows.h>
#include "kit/version.hpp"
extern "C" __declspec(dllexport) int ReferenceKitVersion()
{
    return kit::version();
}
BOOL WINAPI DllMain(HINSTANCE module, DWORD reason, LPVOID)
{
    if (reason == DLL_PROCESS_ATTACH) DisableThreadLibraryCalls(module);
    return TRUE;
}
