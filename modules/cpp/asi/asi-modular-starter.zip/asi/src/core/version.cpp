#include "kit/version.hpp"
namespace kit { int version() noexcept { return 1; } }
