#pragma once
namespace kit { int version() noexcept; }
