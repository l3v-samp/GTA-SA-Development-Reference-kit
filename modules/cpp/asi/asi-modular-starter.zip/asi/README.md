# Modular asi starter

Build using CMake and a Windows x86 toolchain. entry.cpp remains minimal under loader lock; core/version.cpp is a separate module. This starter has no hooks and no visible in-game effects. Add revision-specific game adapters separately and verify addresses.

Source scaffold only. Runtime/target builds have not been tested.
