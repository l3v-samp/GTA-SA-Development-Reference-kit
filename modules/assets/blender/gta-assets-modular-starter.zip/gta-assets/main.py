# Run with Blender: blender --background --python /absolute/path/main.py
from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parent))
from kit_assets.config import MODEL_NAME, SIZE
from kit_assets.geometry import create_cube
from kit_assets.materials import add_gray_material
obj = create_cube(MODEL_NAME, SIZE)
add_gray_material(obj)
print("Created:", obj.name)
