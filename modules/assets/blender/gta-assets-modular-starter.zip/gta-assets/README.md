# Modular gta-assets starter

Run main.py in Blender with its kit_assets folder alongside it. Geometry, materials and config are separated. No DFF/TXD/COL export is performed. Follow the installed INU/DragonFF API and version documentation for an exporter adapter; Ariane bridge must be configured separately.

Source scaffold only. Runtime/target builds have not been tested.
