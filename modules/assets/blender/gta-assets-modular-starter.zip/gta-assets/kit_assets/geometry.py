import bpy
def create_cube(name, size):
    bpy.ops.mesh.primitive_cube_add(size=size, location=(0, 0, size / 2))
    obj = bpy.context.active_object
    obj.name = name
    return obj
