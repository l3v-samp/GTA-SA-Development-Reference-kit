import bpy
def add_gray_material(obj):
    material = bpy.data.materials.new(name="ReferenceKit_Gray")
    material.diffuse_color = (0.45, 0.45, 0.45, 1)
    obj.data.materials.append(material)
