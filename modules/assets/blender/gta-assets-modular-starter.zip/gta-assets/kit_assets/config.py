MODEL_NAME = "ReferenceKit_TestCube"
SIZE = 2.0
