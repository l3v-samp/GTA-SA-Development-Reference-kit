<p align="center">
	<img src="https://images-ext-1.discordapp.net/external/9bnqMJR8BELEgIBP8pyZzXRt2WJ0NmIWpsNjwcvtdMs/https/i.ibb.co/SRLzzcn/gtaopen-reddaddy.png" alt="Logo">
</p>

##### A Cops and robbers mode based in Los Santos with features including...
- Robbing stores and players
- Attachments (a.k.a clothing system)
- Houses with different interiors that can be customised with an array of furnitures.
- Be a drug dealer, get the skill to plant cannabis and make cocaine.
- Casino where you can play on slot machine and gamble.
- Become a good citizen, do legal missions such as pizza delivery, trucking and so much more!
- Per player vehicle system, customize your car, cutomize your plate and everything will be saved.
- Gangs, competitive gang system that competes with other gangs kills, deaths and zone captures.

## Discord server
<p align="center">
	<a href="https://discord.gg/GeRn7nC9WJ">
		<img src="https://discord.com/assets/e4923594e694a21542a489471ecffa50.svg" alt="Logo" height="128">
	</a>
</p>

# Running & Compiling

    Running this gamemode might be a little tricky because we recently migrated to open.mp
    take note that you need compiler 3.10.11 to compile this gamemode (sampctl has 3.10.10).
    replace the compiler at sampctl's AppData with 3.10.11 which can be downloaded in open.mp's files and make the folder named `pawn` inside the `sampctl` folder to read only access so it won't be replaced with 3.10.10 again every time you compile.

## Step 1 — Compile the Gamemode

```bash
sampctl ensure
sampctl build
```

If successful, the compiled `gamemodes/main.amx` will be created.

---

## Step 2 — Set Up MySQL

### 2a. Create the database

```sql
CREATE DATABASE gtaopen;
```

### 2b. Import the table schemas

The SQL table definitions are located in the `scriptfiles/` directory. Import them **in order** (the `players` table must be created first since other tables reference it):

```bash
mysql -u root -p gtaopen < scriptfiles/players.sql
mysql -u root -p gtaopen < scriptfiles/player_stats.sql
mysql -u root -p gtaopen < scriptfiles/player_bank.sql
mysql -u root -p gtaopen < scriptfiles/player_items.sql
mysql -u root -p gtaopen < scriptfiles/player_shots.sql
mysql -u root -p gtaopen < scriptfiles/weapons.sql
mysql -u root -p gtaopen < scriptfiles/vips.sql
mysql -u root -p gtaopen < scriptfiles/jail.sql
mysql -u root -p gtaopen < scriptfiles/armys.sql
mysql -u root -p gtaopen < scriptfiles/admins.sql
mysql -u root -p gtaopen < scriptfiles/bans.sql
mysql -u root -p gtaopen < scriptfiles/houses.sql
mysql -u root -p gtaopen < scriptfiles/gangs.sql
mysql -u root -p gtaopen < scriptfiles/atms.sql
```

Alternatively, the gamemode can create all tables automatically. In `gamemodes/core/constants.inc`, set:

```pawn
#define SETUP_TABLE     (true)
```

Run the server once. After all tables are created, change it back to `false` and recompile:

```pawn
#define SETUP_TABLE     (false)
```

### 2c. Create the MySQL connection file

Create a file named **`mysql.ini`** in the **project root directory** (next to `config.json`):

```ini
hostname=localhost
username=root
password=yourpassword
database=gtaopen
```

> **Note:** If your MySQL server has no password, remove the `password=` line entirely. This file is already in `.gitignore`.

---

## Step 3 — Run the Server

**Windows:**
```bash
omp-server.exe
```

**Linux:**
```bash
chmod +x omp-server  # first time only
./omp-server
```

The server starts on **port 7777** (configurable in `config.json`). Connect with a SA-MP or open.mp client to `localhost:7777`.

---


# How to contribute.

#### Contributing

Contributions are what make the open source community such an amazing place to be learn, inspire, and create.

Any contributions you make are **greatly appreciated**.

- 1. Fork the Project
- 2. Create your Feature Branch (`git checkout -b feature/`)
- 3. Commit your Changes (`git commit -m 'Add some AmazingFeature'`)
- 4. Push to the Branch (`git push origin feature/AmazingFeature`)
- 5. Open a Pull Request

#### Style Guide
```c
// Constants and macros in "UPPER_CASE", with underscores separating words.
#define MAX_PASSWORD    (16)

const INVALID_ARENA_ID = -1;

// 'static' Globals as much as possible to avoid conflict
// with other module that may have the same variable name
static
    // Globals `g` prefixed and camel case.
    gPlayerPassword[MAX_PASSWORD],
    gArenaID[MAX_PLAYERS] = INVALID_ARENA_ID;

// ------------------------------------------------------------------------
// Brace style
// ------------------------------------------------------------------------
// Both style are acceptable but please NOTE!
// make the indentation style consistent depending on the
// module you are working on.

// K & R
if(condition == true)
    condition == false;

// Allman
if(condition == true)
{
    condition == false;
}

// ------------------------------------------------------------------------
// Function Name
// ------------------------------------------------------------------------
// Functions in PascalCase - all words start with an upper-case letter.
// Each Function must be prefixed with the name of the module

// For example we have a module called 'level.inc'
// the module will be an API so we don't have to access the variables anywhere other than the module.
// Functional Programming!!

Level_Get(playerid) {
    if(!IsPlayerConnected(playerid)) {
        return -1; // notice how we used -1, because 0 is a valid level.
    }

    return gPlayerLevel[playerid];
}

Level_GivePlayer(playerid, level) {
    // Braces even for single statements.
    if(!IsPlayerConnected(playerid)) {
        return 0;
    }

    // Single declaration for multiple variables, with each on a new indented line.
    new
        // Variables/parameters in "lowerCamelCase" - as above, except the first word.
        playerLevel = Level_Get(playerid);

    // Module names come first before an underscore.
    Level_Set(playerid, playerLevel + level);
    return 1;
}

Level_Set(playerid, level, bool:save = false) {
    if(!IsPlayerConnected(playerid)) {
        return 0;
    }

    gPlayerLevel[playerid] = level;

    if(save) {
        // mock update the database.
        // UPDATE player_statistics SET level = level + ?
        // ? = level
        // execute statement.
    }
    return 1;
}

// ------------------------------------------------------------------------
// Credentials
// ------------------------------------------------------------------------
// Delicate information such as discord_token & mysql credentials
// must be stored in environment variables to avoid rouge scripter who will tamper with the database
// NOTE:
// USE https://github.com/dakyskye/pawn-env

public OnGameModeInit() {
     new
        MySQLOpt: option_id = mysql_init_options();
	mysql_set_option(option_id, AUTO_RECONNECT, true); // it automatically reconnects when loosing connection to mysql server

    new
        username[24],
        host[24],
        password[24],
        database[24];

    // it's important to add a fallback if first statement fails.
    // like shown below.
    if(Env_Has("MYSQL_USERNAME")) {
        Env_Get("MYSQL_USERNAME", username);
    }
    else {
        print("Could not find environment variable for MYSQL_USERNAME");
    }

    if(Env_Has("MYSQL_PASSWORD")) {
        Env_Get("MYSQL_PASSWORD", password);
    }
    else {
        print("Could not find env ironment variable for MYSQL_PASSWORD");
    }

    if(Env_Has("MYSQL_HOST")) {
        Env_Get("MYSQL_HOST", host);
    }
    else {
        print("Could not find environment variable for MYSQL_HOST");
    }

    if(Env_Has("MYSQL_DATABASE")) {
        Env_Get("MYSQL_DATABASE", database);
    }
    else {
        print("Could not find environment variable for MYSQL_DATABASE");
    }

    MySQL_ConHandle = mysql_connect(host, username, password, database);

    if(MySQL_ConHandle == MYSQL_INVALID_HANDLE || mysql_errno(MySQL_ConHandle) != 0) {
        print("MySQL failed to connect. Server shutting down...");
        exit();
        return 1;
    }

    print("MySQL connection is successful.");
    return 1;
}


// ------------------------------------------------------------------------
// MySQL Prepared Statements
// ------------------------------------------------------------------------
// Each statement declaration must have stmt_ prefix.
// after the prefix, naming must be CamelCase.
static
    stmt_CamelCase;

// long queries must be seperated into different lines
// for better readability.
// it also should be stored in an array with no fixed size
// declared as 'static const'
static const query_LoadAttachments[] = "\
    SELECT \
        slot, \
        model, \
        bone, \
        offset_x, \
        offset_y, \
        offset_z, \
        rotation_x,\
        rotation_y, \
        rotation_z, \
        scale_x, \
        scale_y, \
        scale_z \
    FROM \
        attachments \
    WHERE \
        u_id = ?"
; // this is only acceptable for queries.
```

# Thanks to
Name | Message
--- | --- |
[Southclaws] | Includes, snippets from Scavenge Survive, sampctl.
[maddinat0r] | MySQL
[Y_Less]     | for YSI Library, used a lot throughout the code.
[Zeex]       | amx_assembly, crashdetect, indirection
[Slice]      | formatex
[Lorenc]     | SFCNR, snippets & data from sfcnr

Very special thanks to
**SA:MP Team past, present and future - SA:MP.**

