# Modular moonloader starter

Copy main.lua into moonloader/ and kit/ into moonloader/lib/kit/. The entrypoint waits for SA-MP availability; bootstrap injects context into features. No MTA APIs. New modules must own and destroy timers/audio/fonts/UI resources on unload according to installed MoonLoader APIs. This hello module allocates no such resources.

Source scaffold only. Runtime/target builds have not been tested.
