local config = require 'kit.config'
local M = {}
function M.start()
    local modules = {}
    local context = { config = config, notify = function(message)
        sampAddChatMessage('[Kit] ' .. message, -1)
    end }
    for _, name in ipairs(config.modules) do
        local feature = require('kit.features.' .. name)
        if feature.init then feature.init(context) end
        modules[#modules + 1] = feature
    end
    return { update = function()
        for _, feature in ipairs(modules) do
            if feature.update then feature.update(context) end
        end
    end }
end
return M
