return { modules = { 'hello' }, command = 'kithello' }
