local M = {}
function M.init(context)
    sampRegisterChatCommand(context.config.command, function()
        context.notify('Hello from a MoonLoader feature module!')
    end)
end
return M
