script_name('Modular MoonLoader Starter')
script_author('Development Reference kit')
local bootstrap = require 'kit.core.bootstrap'
function main()
    repeat wait(100) until isSampAvailable()
    local app = bootstrap.start()
    while true do
        wait(100)
        app.update()
    end
end
