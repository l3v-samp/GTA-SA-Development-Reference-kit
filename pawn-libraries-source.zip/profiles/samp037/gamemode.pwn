#include <a_samp>
main() {}
public OnGameModeInit()
{
    SetGameModeText("Pawn Reference Kit");
    AddPlayerClass(0, 1958.3783, 1343.1572, 15.3746, 270.0, 0,0,0,0,0,0);
    return 1;
}
